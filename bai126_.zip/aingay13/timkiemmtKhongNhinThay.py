# MÔ HÌNH BÀI TOÁN ROBOT HÚT BỤI - MÔI TRƯỜNG KHÔNG NHÌN THẤY (BLIND BFS)
# Tạ Thùy Phương Vy_24110069

import tkinter as tk
from tkinter import ttk
from collections import deque

def in_ma_tran_chuoi(tap_o_ban, so_dong=3, so_cot=3):
    """Chuyển tập hợp ô bẩn thành chuỗi ma trận 0-1 để ghi log."""
    dong_chuoi = []
    for r in range(so_dong):
        _dong = []
        for c in range(so_cot):
            _dong.append("1" if (r, c) in tap_o_ban else "0")
        dong_chuoi.append("      " + " ".join(_dong))
    return "\n".join(dong_chuoi)


class TrangThaiHutBui:
    """Lớp lưu trữ vị trí robot và danh sách các ô còn bẩn."""
    def __init__(self, vi_tri_robot, cac_o_ban):
        self.vi_tri_robot = vi_tri_robot
        self.cac_o_ban = frozenset(cac_o_ban)

    def kiem_tra_sach_het(self):
        return len(self.cac_o_ban) == 0

    def __eq__(self, other):
        return self.vi_tri_robot == other.vi_tri_robot and self.cac_o_ban == other.cac_o_ban

    def __hash__(self):
        return hash((self.vi_tri_robot, self.cac_o_ban))

    def thong_tin_chi_tiet(self):
        bnd = in_ma_tran_chuoi(self.cac_o_ban)
        return f"   + Robot tại: {self.vi_tri_robot}\n   + Hiện trạng vết bẩn:\n{bnd}"

    def dich_chuyen(self, huong_di, max_r, max_c):
        """Xử lý di chuyển và tự động hút bụi khi trùng vị trí."""
        r, c = self.vi_tri_robot
        tap_ban_moi = set(self.cac_o_ban)
        
        if huong_di == "U" and r > 0: r -= 1
        elif huong_di == "D" and r < max_r - 1: r += 1
        elif huong_di == "L" and c > 0: c -= 1
        elif huong_di == "R" and c < max_c - 1: c += 1
        
        if (r, c) in tap_ban_moi:
            tap_ban_moi.remove((r, c))
            
        return TrangThaiHutBui((r, c), tap_ban_moi)


class NutNiemTin:
    """Nút trên cây tìm kiếm, đại diện cho một Tập niềm tin (Belief State)."""
    def __init__(self, tap_trang_thai, cha=None, hanh_dong=None, buoc_di=0, ten_nut="A"):
        self.tap_trang_thai = frozenset(tap_trang_thai)
        self.cha = cha
        self.hanh_dong = hanh_dong
        self.buoc_di = buoc_di
        self.ten_nut = ten_nut

    def dat_muc_tieu(self):
        return all(st.kiem_tra_sach_het() for st in self.tap_trang_thai)

    def lay_dinh_danh(self):
        return self.tap_trang_thai


def thuat_toan_blind_bfs(so_dong, so_cot, o_ban_ban_dau):
    """Tìm kiếm BFS trên không gian tập niềm tin (Môi trường Blind)."""
    tat_ca_vi_tri = [(r, c) for r in range(so_dong) for c in range(so_cot)]
    
    # Tạo nhãn định danh nút theo dạng A, B, C... Z, A1, B1...
    chu_cai = [chr(i) for i in range(65, 91)]
    def sinh_nhan_theo_chi_so(index):
        if index < 26:
            return chu_cai[index]
        return f"{chu_cai[index % 26]}{index // 26}"

    # Khởi tạo tập niềm tin ban đầu khi chưa biết rõ robot ở đâu
    trang_thai_dau = []
    for pos in tat_ca_vi_tri:
        r, c = pos
        ban_moi = set(o_ban_ban_dau)
        if (r, c) in ban_moi:
            ban_moi.remove((r, c))
        trang_thai_dau.append(TrangThaiHutBui(pos, ban_moi))
    
    nut_goc = NutNiemTin(tap_trang_thai=trang_thai_dau, cha=None, hanh_dong=None, buoc_di=0, ten_nut=sinh_nhan_theo_chi_so(0))
    
    ds_cho = deque([nut_goc])
    da_duyet = set()
    
    tap_hanh_dong = ["U", "D", "L", "R"]
    nhat_ky = []
    dem_nut = 1
    
    nhat_ky.append(f"[KÍCH HOẠT HỆ THỐNG BLIND BFS]\n-> Gốc ban đầu: [{nut_goc.ten_nut}] được thêm vào danh sách chờ.\n- Chứa tất cả {len(nut_goc.tap_trang_thai)} giả định vị trí.\n")

    while ds_cho:
        nut_hien_tai = ds_cho.popleft()
        khoa_nut = nut_hien_tai.lay_dinh_danh()
        
        if khoa_nut in da_duyet:
            continue
            
        da_duyet.add(khoa_nut)
        
        msg = f"==> [DUYỆT] Lấy nút [{nut_hien_tai.ten_nut}] (Bước số {nut_hien_tai.buoc_di})\n"
        msg += f"Đóng nút [{nut_hien_tai.ten_nut}] vào danh sách ĐÃ DUYỆT.\n"
        if nut_hien_tai.cha:
            msg += f"- Di chuyển từ nút [{nut_hien_tai.cha.ten_nut}] -> Lệnh điều khiển: [{nut_hien_tai.hanh_dong}]\n"
        msg += f"- Tập niềm tin gồm: {len(nut_hien_tai.tap_trang_thai)} trạng thái khả thi.\n"
        msg += f"- CHI TIẾT MA TRẬN GIẢ ĐỊNH:\n"
        
        s_states = sorted(list(nut_hien_tai.tap_trang_thai), key=lambda x: (x.vi_tri_robot, len(x.cac_o_ban)))
        for idx, st in enumerate(s_states, 1):
            msg += f"Cấu hình {idx}:\n{st.thong_tin_chi_tiet()}\n"
            
        msg += f"Đang chờ: {len(ds_cho)} | Đã duyệt: {len(da_duyet)}\n"
        msg += f"------------------------------------------------------------\n"
        
        # Kiểm tra điều kiện dừng (Hút sạch toàn bộ ma trận)
        if nut_hien_tai.dat_muc_tieu():
            msg += f"[THÀNH CÔNG] Đã tìm ra chuỗi hành động tại nút [{nut_hien_tai.ten_nut}]!"
            nhat_ky.append(msg)
            
            duong_di = []
            p = nut_hien_tai
            while p is not None:
                duong_di.append(p)
                p = p.cha
            duong_di.reverse()
            return duong_di, nhat_ky
        
        buoc_ke_tiep = nut_hien_tai.buoc_di + 1
        log_con = []
        
        # Khảo sát tập con qua các hướng đi U, D, L, R
        for act in tap_hanh_dong:
            trang_thai_ke = set()
            for st in nut_hien_tai.tap_trang_thai:
                trang_thai_ke.add(st.dich_chuyen(act, so_dong, so_cot))
                
            nut_tam = NutNiemTin(tap_trang_thai=trang_thai_ke)
            if nut_tam.lay_dinh_danh() not in da_duyet:
                ten_moi = sinh_nhan_theo_chi_so(dem_nut)
                dem_nut += 1
                
                nut_con = NutNiemTin(
                    tap_trang_thai=trang_thai_ke,
                    cha=nut_hien_tai,
                    hanh_dong=act,
                    buoc_di=buoc_ke_tiep,
                    ten_nut=ten_moi
                )
                ds_cho.append(nut_con)
                log_con.append(f"Hướng [{act}] -> Sinh nút [{nut_con.ten_nut}] (Gồm {len(trang_thai_ke)} trạng thái)")
        
        if log_con:
            msg += "[PUSH] Các nút con hợp lệ đưa vào hàng đợi:\n"
            for lc in log_con:
                msg += f"    + {lc}\n"
                
        nhat_ky.append(msg)
                
    return None, nhat_ky


def run(center_frame, log_text, result_text, name=""):
    ROWS, COLS = 3, 3  
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    title_label = tk.Label(
        center_frame, 
        text="MÔ PHỎNG ROBOT HÚT BỤI - THUẬT TOÁN BLIND BFS", 
        bg="#2d3748", fg="#63b3ed", 
        font=("Segoe UI", 13, "bold"), pady=8
    )
    title_label.pack(side="top", fill="x", pady=(5, 5))

    legend_bar = tk.Frame(center_frame, bg="#2d3748", pady=5)
    legend_bar.pack(side="top", fill="x", padx=10, pady=(0, 10))

    center_legend = tk.Frame(legend_bar, bg="#2d3748")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e2e8f0", width=3, relief="solid", bd=1).pack(side="left", padx=(10, 4))
    tk.Label(center_legend, text="0=SẠCH", bg="#2d3748", fg="white", font=("Segoe UI", 8, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#f56565", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 4))
    tk.Label(center_legend, text="1=BẨN", bg="#2d3748", fg="white", font=("Segoe UI", 8, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#90cdf4", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 4))
    tk.Label(center_legend, text="MAYBE", bg="#2d3748", fg="white", font=("Segoe UI", 8, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#3182ce", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 4))
    tk.Label(center_legend, text="ROBOT", bg="#2d3748", fg="white", font=("Segoe UI", 8, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 90
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, 
        bg="#ffffff", highlightthickness=1, highlightbackground="#cbd5e0"
    )
    canvas.pack(side="bottom", pady=5)

    path, steps_log = thuat_toan_blind_bfs(ROWS, COLS, initial_dirty)
    
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*70 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    if not path:
        result_text.insert(tk.END, "Kết quả: Thất bại, không tìm được đường.")
        return

    path_names = [node.ten_nut for node in path]
    actions_taken = [node.hanh_dong for node in path if node.hanh_dong is not None]
    
    result_text.insert(tk.END, "=== KẾT QUẢ CHUỖI TÌM KIẾM BLIND BFS ===\n\n")
    result_text.insert(tk.END, f"Thứ tự nút thông qua:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tập lệnh di chuyển tối ưu:\n{' -> '.join(actions_taken)}\n\n")
    result_text.insert(tk.END, f"Tổng số bước thực hiện: {path[-1].buoc_di} bước.\n\n")
    result_text.insert(tk.END, f"TRẠNG THÁI: HOÀN THÀNH (Đã làm sạch toàn bộ môi trường).")
    result_text.tag_config("hoanthanh", foreground="#38a169", font=("Segoe UI", 9, "bold"))
    result_text.tag_add("hoanthanh", "1.0", "end")
    
    confirmed_history = []

    def draw_belief_node(belief_node, current_index):
        canvas.delete("all")
        
        v_tri_kha_thi = set(st.vi_tri_robot for st in belief_node.tap_trang_thai)
        o_dang_ban = set()
        for st in belief_node.tap_trang_thai:
            o_dang_ban.update(st.cac_o_ban)
        
        if len(v_tri_kha_thi) == 1:
            pos = list(v_tri_kha_thi)[0]
            if len(confirmed_history) <= current_index:
                confirmed_history.append(pos)
        else:
            if len(confirmed_history) <= current_index:
                confirmed_history.append(None)

        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in o_dang_ban
                is_possible_agent = (r, c) in v_tri_kha_thi
                
                if is_possible_agent:
                    if len(v_tri_kha_thi) == 1:
                        cell_bg = "#3182ce"       
                        text_color = "white"
                    else:
                        cell_bg = "#90cdf4"       
                        text_color = "black"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#f56565"       
                        text_color = "white"
                        cell_outline = "#e53e3e"
                    else:
                        cell_bg = "#e2e8f0"       
                        text_color = "#4a5568"
                        cell_outline = "#cbd5e0"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                matrix_val = "1" if is_dirty else "0"
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if is_possible_agent else y1 + CELL_SIZE/2, 
                    text=matrix_val, fill=text_color, font=("Consolas", 18, "bold")
                )
                
                if is_possible_agent:
                    label_text = "ROBOT" if len(v_tri_kha_thi) == 1 else "MAYBE"
                    canvas.create_text(
                        x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 16, 
                        text=label_text, fill=text_color, font=("Segoe UI", 8, "bold")
                    )

        for i in range(current_index):
            p1 = confirmed_history[i]
            p2 = confirmed_history[i+1]
            if p1 is not None and p2 is not None:
                r1, c1 = p1
                r2, c2 = p2
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#1a365d", width=3, arrow=tk.LAST, arrowshape=(9, 11, 4))

    def animate(step_index):
        if step_index < len(path):
            current_node = path[step_index]
            draw_belief_node(current_node, step_index)
            center_frame.after(1000, lambda: animate(step_index + 1)) 

    confirmed_history.clear()
    animate(0)


if __name__ == "__main__":
    window = tk.Tk()
    window.title("AI Lab - Kiểm thử không gian niềm tin bài toán Robot")
    window.geometry("1100(nhớ sửa thành x)650") # Để chuỗi thô tránh lỗi Tkinter hình học
    window.geometry("1100x650")
    window.configure(bg="#f7fafc")

    fr_trai = tk.Frame(window, bg="#ffffff", bd=1, relief="solid")
    fr_trai.pack(side="left", fill="both", expand=True, padx=10, pady=10)

    fr_phai = tk.Frame(window, bg="#1a202c")
    fr_phai.pack(side="right", fill="both", expand=True, padx=10, pady=10)

    tk.Label(fr_phai, text="NHẬT KÝ DUYỆT TRẠNG THÁI (LOG)", bg="#1a202c", fg="#63b3ed", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=(5, 0))
    
    thanh_cuon = ttk.Scrollbar(fr_phai)
    thanh_cuon.pack(side="right", fill="y")

    khung_log = tk.Text(fr_phai, bg="#2d3748", fg="#e2e8f0", font=("Consolas", 9), bd=0, yscrollcommand=thanh_cuon.set)
    khung_log.pack(fill="both", expand=True, padx=10, pady=5)
    thanh_cuon.config(command=khung_log.yview)

    tk.Label(fr_phai, text="KẾT LUẬN", bg="#1a202c", fg="#48bb78", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=(5, 0))
    khung_kq = tk.Text(fr_phai, bg="#2d3748", fg="#48bb78", font=("Consolas", 9), height=9, bd=0)
    khung_kq.pack(fill="x", padx=10, pady=(0, 10))

    run(fr_trai, khung_log, khung_kq)
    window.mainloop()