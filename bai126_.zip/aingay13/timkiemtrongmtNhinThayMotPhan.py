#Tạ Thùy Phương Vy_24110069
#THUẬT TOÁN TÌM KIẾM TRONG MÔI TRƯỜNG NHÌN THẤY MỘT PHẦN (ÁP DỤNG BFS)
#https://github.com/tathuyphuongvy-lgtm

import tkinter as tk
from tkinter import ttk
from collections import deque

# =========================================================
# 1. MÔ HÌNH HÓA TOÁN HỌC & LOGIC KHÔNG GIAN NIỀM TIN
# =========================================================
class VacuumEnvironment:
    """Quản lý logic dịch chuyển trạng thái vật lý và niềm tin."""
    def __init__(self, rows=3, cols=3):
        self.rows = rows
        self.cols = cols
        self.actions = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}

    def transition_state(self, state, action):
        """Dịch chuyển 1 trạng thái cụ thể: state = (pos_r, pos_c, frozenset_dirty)"""
        r, c, dirty_cells = state
        dr, dc = self.actions[action]
        
        # Tính toán vị trí mới trong biên ma trận
        nr = max(0, min(self.rows - 1, r + dr))
        nc = max(0, min(self.cols - 1, c + dc))
        
        # Tự động dọn dẹp nếu ô mới là ô bẩn
        new_dirty = set(dirty_cells)
        if (nr, nc) in new_dirty:
            new_dirty.remove((nr, nc))
            
        return (nr, nc, frozenset(new_dirty))

    def transition_belief(self, belief_set, action, percept):
        """Cập nhật tập niềm tin dựa trên Hành động + Tri giác cảm biến (AND-OR Layer)"""
        next_belief = set()
        for state in belief_set:
            # Bước OR: Thực hiện hành động
            moved_state = self.transition_state(state, action)
            # Bước AND: Lọc theo cảm biến (ô hiện tại bẩn=1, sạch=0)
            agent_r, agent_c, dirty_cells = moved_state
            actual_percept = 1 if (agent_r, agent_c) in dirty_cells else 0
            
            if actual_percept == percept:
                next_belief.add(moved_state)
                
        return frozenset(next_belief)


# =========================================================
# 2. CẤU TRÚC DỮ LIỆU NÚT TRÊN CÂY TÌM KIẾM (SEARCH NODE)
# =========================================================
class SearchNode:
    def __init__(self, belief_state, parent=None, action=None, percept=None, depth=0, identifier="Root"):
        self.belief = belief_state  # Frozenset của các tuple (r, c, dirty_frozenset)
        self.parent = parent
        self.action = action
        self.percept = percept
        self.depth = depth
        self.id = identifier

    def get_path(self):
        """Truy vết ngược từ nút đích về nút gốc."""
        path = []
        curr = self
        while curr:
            path.append(curr)
            curr = curr.parent
        return path[::-1]


# =========================================================
# 3. THUẬT TOÁN TÌM KIẾM KHÔNG GIAN NIỀM TIN TỐI ƯU (BFS)
# =========================================================
def solve_partial_observable_bfs(rows, cols, initial_dirty):
    env = VacuumEnvironment(rows, cols)
    logs = []
    
    # Tạo tập niềm tin ban đầu: Robot có thể ở bất kỳ vị trí nào trong 9 ô
    start_belief = []
    for r in range(rows):
        for c in range(cols):
            init_d = set(initial_dirty)
            if (r, c) in init_d:
                init_d.remove((r, c)) # Nếu đứng trúng ô bẩn thì ô đó sạch ngay
            start_belief.append((r, c, frozenset(init_d)))
            
    root = SearchNode(belief_state=frozenset(start_belief))
    
    frontier = deque([root])
    reached = {root.belief}
    
    logs.append(f"[KHỞI CHẠY HỆ THỐNG]\nKhởi tạo thành công nút Gốc [{root.id}] với {len(root.belief)} giả định vị trí.\n" + "="*60)
    
    node_counter = 0
    
    while frontier:
        curr_node = frontier.popleft()
        
        # KIỂM TRA ĐÍCH: Mục tiêu là làm sạch hoàn toàn ô (1,0) và (1,1)
        # Định nghĩa đích: Trong MỌI trạng thái thuộc tập niềm tin, (1,0) và (1,1) ĐỀU KHÔNG còn bẩn
        is_goal = True
        for _, _, dirty in curr_node.belief:
            if (1, 0) in dirty or (1, 1) in dirty:
                is_goal = False
                break
                
        if is_goal:
            logs.append(f"==> [THÀNH CÔNG] Tìm thấy nút đích [{curr_node.id}] tại tầng thứ {curr_node.depth}!")
            return curr_node.get_path(), logs
            
        # SINH CON PHÂN NHÁNH
        current_log = f"Duyệt nút [{curr_node.id}] (Tầng {curr_node.depth}) | Kích thước niềm tin: {len(curr_node.belief)}\n"
        child_branches = []
        
        for act in ["U", "D", "L", "R"]:
            for pcp in [0, 1]: # 0: Sạch, 1: Bẩn
                next_b = env.transition_belief(curr_node.belief, act, pcp)
                
                if next_b and (next_b not in reached):
                    reached.add(next_b)
                    node_counter += 1
                    child_id = f"N-{curr_node.depth + 1}.{node_counter}"
                    
                    child_node = SearchNode(
                        belief_state=next_b,
                        parent=curr_node,
                        action=act,
                        percept=pcp,
                        depth=curr_node.depth + 1,
                        identifier=child_id
                    )
                    frontier.append(child_node)
                    p_str = "SẠCH(0)" if pcp == 0 else "BẨN(1)"
                    child_branches.append(f"  + [{act} + {p_str}] -> Sinh nút [{child_id}] ({len(next_b)} trạng thái)")
                    
        if child_branches:
            current_log += "Các nhánh rẽ khả thi tiếp theo:\n" + "\n".join(child_branches)
        else:
            current_log += " -> Nhánh cụt hoặc trạng thái trùng lặp!"
            
        logs.append(current_log + "\n" + "-"*60)
        
    return None, logs


# =========================================================
# 4. GIAO DIỆN ĐỒ HỌA ỨNG DỤNG (TKINTER MODERN UI)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)]
    CELL_SIZE = 90

    # Khởi tạo lại bố cục giao diện mới (Phong cách Cyberpunk / Dark Mode nhẹ)
    center_frame.configure(bg="#0F172A")
    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # Tiêu đề ứng dụng nghệ thuật
    header = tk.Label(
        center_frame, 
        text="AI AGENT - BELIEF STATE SEARCH VISUALIZER", 
        bg="#1E293B", fg="#38BDF8", 
        font=("Consolas", 14, "bold"), pady=10
    )
    header.pack(fill="x", pady=(0, 10))

    # Thanh chú giải thiết kế lại dạng bảng gọn
    legend = tk.Frame(center_frame, bg="#1E293B", bd=1, relief="groove")
    legend.pack(fill="x", padx=20, pady=5)
    
    def add_item(lbl, color, txt):
        tk.Frame(legend, bg=color, width=15, height=15).pack(side="left", padx=(15, 5), pady=5)
        tk.Label(legend, text=txt, bg="#1E293B", fg="#94A3B8", font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 10))

    add_item(legend, "#1E293B", "0 = SẠCH")
    add_item(legend, "#EF4444", "1 = BẨN")
    add_item(legend, "#F59E0B", "MAYBE ROBOT")
    add_item(legend, "#10B981", "ROBOT CHẮC CHẮN")

    # Khu vực chứa bảng Canvas đồ họa
    canvas_panel = tk.Frame(center_frame, bg="#0F172A")
    canvas_panel.pack(expand=True, pady=10)

    canvas = tk.Canvas(
        canvas_panel, 
        width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, 
        bg="#1E293B", highlightthickness=2, highlightbackground="#334155"
    )
    canvas.pack()

    # Thực thi giải thuật tìm kiếm
    path, logs = solve_partial_observable_bfs(ROWS, COLS, initial_dirty)

    # Ghi nhật ký tiến trình tìm kiếm
    for block in logs:
        log_text.insert(tk.END, block + "\n")
    log_text.see(tk.END)

    if not path:
        result_text.insert(tk.END, ">>> THẤT BẠI: Không tìm thấy đường đi khả thi.")
        return

    # Kết xuất báo cáo kết quả đồ họa cuối cùng
    result_text.insert(tk.END, ">>> HÀNH TRÌNH TÌM KIẾM KHÔNG GIAN NIỀM TIN THÀNH CÔNG <<<\n\n")
    result_text.insert(tk.END, f"Chuỗi tiến trình nút: " + " -> ".join([n.id for n in path]) + "\n\n")
    
    act_sequences = [f"[{n.action} | Cảm biến: {n.percept}]" for n in path if n.action]
    result_text.insert(tk.END, f"Kịch bản điều khiển hành động:\n" + " => ".join(act_sequences) + "\n\n")
    result_text.insert(tk.END, f"Tổng chi phí đường đi: {path[-1].depth} bước di chuyển.")
    result_text.tag_config("sucess_style", foreground="#10B981", font=("Segoe UI", 10, "bold"))
    result_text.tag_add("sucess_style", "1.0", "end")

    robot_trace = []

    # =========================================================
    # HÀM REDRAW: CẬP NHẬT GIAO DIỆN HOẠT HÌNH
    # =========================================================
    def render_belief_node(node, idx):
        canvas.delete("all")
        
        # Phân tích tập niềm tin hiện tại của nút
        possible_positions = set((r, c) for r, c, _ in node.belief)
        union_dirty = set()
        for _, _, dirty in node.belief:
            union_dirty.update(dirty)

        # Lưu vết vị trí để vẽ đường line chuyển động
        if len(possible_positions) == 1:
            robot_trace.append(list(possible_positions)[0])
        else:
            robot_trace.append(None)

        # Vẽ lưới ma trận nền
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_agent = (r, c) in possible_positions
                is_dirty = (r, c) in union_dirty
                is_target = (r, c) in [(1, 0), (1, 1)]

                # Thiết lập màu sắc trực quan hóa hiện đại
                if is_agent:
                    cell_color = "#10B981" if len(possible_positions) == 1 else "#F59E0B"
                    txt_color = "#FFFFFF"
                elif is_dirty:
                    cell_color = "#EF4444"
                    txt_color = "#FFFFFF"
                else:
                    cell_color = "#334155"
                    txt_color = "#94A3B8"

                border_color = "#38BDF8" if is_target else "#475569"
                border_width = 3 if is_target else 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_color, outline=border_color, width=border_width)

                # Vẽ văn bản ký hiệu trạng thái ô
                val_text = "1" if is_dirty else "0"
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/3, text=val_text, fill=txt_color, font=("Consolas", 18, "bold"))

                # Gắn nhãn Robot định vị
                if is_agent:
                    role_lbl = "ROBOT" if len(possible_positions) == 1 else "MAYBE"
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + 2*CELL_SIZE/3 + 5, text=role_lbl, fill=txt_color, font=("Segoe UI", 8, "bold"))
                
                if is_target:
                    canvas.create_text(x1 + 25, y1 + 12, text="GOAL", fill="#38BDF8", font=("Segoe UI", 7, "bold"))

        # Vẽ đường nối hành trình dịch chuyển của tác tử thực tế (Màu neon huyền ảo)
        for i in range(idx):
            p1, p2 = robot_trace[i], robot_trace[i+1]
            if p1 and p2:
                lx1, ly1 = p1[1] * CELL_SIZE + CELL_SIZE/2, p1[0] * CELL_SIZE + CELL_SIZE/2
                lx2, ly2 = p2[1] * CELL_SIZE + CELL_SIZE/2, p2[0] * CELL_SIZE + CELL_SIZE/2
                canvas.create_line(lx1, ly1, lx2, ly2, fill="#06B6D4", width=3, arrow=tk.LAST, arrowshape=(8, 10, 3))

    # Điều khiển luồng hoạt ảnh thời gian thực
    def play_animation(step):
        if step < len(path):
            render_belief_node(path[step], step)
            center_frame.after(1200, lambda: play_animation(step + 1))

    robot_trace.clear()
    play_animation(0)