# ĐỒ ÁN MÔN HỌC: TRÍ TUỆ NHÂN TẠO
# ĐỀ TÀI: GIẢI QUYẾT BÀI TOÁN TÔ MÀU BẢN ĐỒ TP.HCM BẰNG CSP (AC-3 & BACKTRACKING)
# Sinh viên thực hiện: Tạ Thùy Phương Vy - 24110069

import tkinter as tk
import random

# ==========================================
# 1. CƠ SỞ DỮ LIỆU BẢN ĐỒ PHÂN TÁCH CHUẨN ĐỊA LÝ
# ==========================================
HCM_MAP_COORDINATES = {
    "Thành phố Thủ Đức": [390, 240, 420, 310, 450, 370, 490, 450, 520, 440, 560, 350, 600, 260, 590, 190, 490, 120, 410, 160],
    "Quận Bình Thạnh":   [330, 220, 390, 240, 420, 310, 350, 330, 320, 280],
    "Quận Phú Nhuận":    [270, 245, 330, 220, 320, 280, 265, 275],
    "Quận Tân Bình":     [150, 235, 270, 245, 265, 275, 250, 345, 210, 325],
    "Quận 10":          [210, 325, 250, 345, 240, 375, 200, 365],
    "Quận 11":          [145, 335, 210, 325, 200, 365, 135, 375],
    "Quận 3":           [250, 345, 265, 275, 320, 280, 290, 355],
    "Quận 1":           [290, 355, 320, 280, 350, 330, 390, 340, 420, 310, 415, 350, 380, 380, 320, 385],
    "Quận 5":           [200, 365, 240, 375, 290, 355, 320, 385, 260, 425, 190, 415],
    "Quận 4":           [320, 385, 380, 380, 415, 350, 420, 310, 450, 370, 340, 430],
    "Quận 7":           [340, 430, 450, 370, 490, 450, 520, 440, 500, 530, 460, 540, 340, 520],
    "Quận 8":           [90,  425, 140, 425, 190, 415, 260, 425, 320, 385, 340, 430, 340, 520, 290, 485, 210, 465, 130, 465, 95, 455]
}

DISTRICT_LABELS = {
    "Thành phố Thủ Đức": [500, 240, "TP.Thủ Đức"],
    "Quận Bình Thạnh":   [370, 270, "B.Thạnh"],
    "Quận Phú Nhuận":    [300, 250, "P.Nhuận"],
    "Quận Tân Bình":     [205, 275, "T.Bình"],
    "Quận 10":          [223, 348, "Q.10"],
    "Quận 11":          [170, 352, "Q.11"],
    "Quận 3":           [283, 310, "Q.3"],
    "Quận 1":           [345, 345, "Q.1"],
    "Quận 5":           [245, 395, "Q.5"],
    "Quận 4":           [365, 380, "Q.4"],
    "Quận 7":           [415, 475, "Q.7"],
    "Quận 8":           [180, 442, "Q.8"]
}

# ĐÃ BỔ SUNG QUAN HỆ KỀ NHAU GIỮA TÂN BÌNH VÀ QUẬN 3 ĐỂ TRÁNH TRÙNG MÀU
HCM_ADJACENCY_LIST = {
    "Quận 1": ["Quận 3", "Quận 4", "Quận 5", "Quận Bình Thạnh", "Thành phố Thủ Đức"],
    "Quận 3": ["Quận 1", "Quận 5", "Quận 10", "Quận Phú Nhuận", "Quận Tân Bình"],
    "Quận 4": ["Quận 1", "Quận 7", "Quận 8", "Thành phố Thủ Đức"],
    "Quận 5": ["Quận 1", "Quận 3", "Quận 8", "Quận 10", "Quận 11"],
    "Quận 7": ["Quận 4", "Quận 8", "Thành phố Thủ Đức"],
    "Quận 8": ["Quận 4", "Quận 5", "Quận 7", "Quận 11"],
    "Quận 10": ["Quận 3", "Quận 5", "Quận 11", "Quận Tân Bình"],
    "Quận 11": ["Quận 5", "Quận 8", "Quận 10", "Quận Tân Bình"],
    "Quận Phú Nhuận": ["Quận 3", "Quận Bình Thạnh", "Quận Tân Bình"],
    "Quận Bình Thạnh": ["Quận 1", "Quận Phú Nhuận", "Thành phố Thủ Đức"],
    "Quận Tân Bình": ["Quận 3", "Quận 10", "Quận 11", "Quận Phú Nhuận"],
    "Thành phố Thủ Đức": ["Quận 1", "Quận 4", "Quận 7", "Quận Bình Thạnh"]
}

PALETTE_HEX = {
    "Đỏ Đô": "#E74C3C", 
    "Xanh Lục": "#2ECC71", 
    "Xanh Biển": "#3498DB", 
    "Vàng Chanh": "#F1C40F"
}

# ==========================================
# 2. LỚP XỬ LÝ TOÁN CSP (AC-3 + BACKTRACKING)
# ==========================================
class AdvancedArcConsistencyCSP:
    def __init__(self, nodes, adjacency, colors, logger_func):
        self.nodes = nodes
        self.adjacency = adjacency
        self.colors = list(colors)
        self.print_log = logger_func
        self.domains = {node: list(self.colors) for node in self.nodes}
        self.assignment = {}

    def run_ac3(self):
        self.print_log("=== BẮT ĐẦU KIỂM TRA NHẤT QUÁN CUNG (AC-3) ===")
        arc_queue = [(u, v) for u in self.adjacency for v in self.adjacency[u]]
        self.print_log(f"-> Tạo thành công hàng đợi chứa {len(arc_queue)} cung logic.")

        while arc_queue:
            u, v = arc_queue.pop(0)
            if self.check_and_revise(u, v):
                self.print_log(f"   [Cập nhật] Domain({u}) rút gọn còn: {self.domains[u]}")
                if not self.domains[u]:
                    self.print_log(f"   [Lỗi] Miền giá trị của {u} bị rỗng! Không tìm thấy lời giải.")
                    return False
                for w in self.adjacency[u]:
                    if w != v:
                        arc_queue.append((w, u))
        
        self.print_log("=== KẾT THÚC TIỀN XỬ LÝ AC-3: CÁC MIỀN GIÁ TRỊ ĐÃ NHẤT QUÁN ===\n")
        return True

    def check_and_revise(self, u, v):
        is_revised = False
        for color_u in list(self.domains[u]):
            if len(self.domains[v]) == 1 and color_u == self.domains[v][0]:
                self.domains[u].remove(color_u)
                is_revised = True
        return is_revised

    def solve_with_backtracking(self, animation_callback):
        if not self.run_ac3():
            return None
        self.print_log("=== BẮT ĐẦU QUÁ TRÌNH BACKTRACKING ===")
        return self._recursive_backtrack(animation_callback)

    def _recursive_backtrack(self, animation_callback):
        if len(self.assignment) == len(self.nodes):
            return self.assignment

        unassigned_nodes = [node for node in self.nodes if node not in self.assignment]
        current_node = min(unassigned_nodes, key=lambda n: len(self.domains[n]))

        for chosen_color in self.domains[current_node]:
            if all(self.assignment.get(neighbor) != chosen_color for neighbor in self.adjacency[current_node]):
                
                animation_callback(current_node, chosen_color, "ADVANCE")
                self.assignment[current_node] = chosen_color

                search_result = self._recursive_backtrack(animation_callback)
                if search_result is not None:
                    return search_result

                animation_callback(current_node, chosen_color, "BACKTRACK")
                del self.assignment[current_node]
                
        return None

# ==========================================
# 3. GIAO DIỆN CHÍNH VÀ ĐIỀU KHIỂN HOẠT HÌNH
# ==========================================
class MainApplication:
    def __init__(self, root_window):
        self.root = root_window
        self.root.title("MAP COLORING - CSP AC-3 & BACKTRACKING (TP.HCM)")
        self.root.geometry("1250x750")
        self.root.configure(bg="#141923")

        self.animation_history = []
        self.polygon_ids = {}

        self.build_gui_layout()
        
        self.csp_solver = AdvancedArcConsistencyCSP(
            list(HCM_MAP_COORDINATES.keys()),
            HCM_ADJACENCY_LIST,
            PALETTE_HEX.keys(),
            self.insert_terminal_log
        )

        self.draw_administrative_map()
        self.start_processing()

    def build_gui_layout(self):
        container = tk.Frame(self.root, bg="#141923")
        container.pack(fill="both", expand=True, padx=15, pady=15)

        self.map_canvas = tk.Canvas(container, width=720, height=580, bg="#192030", highlightthickness=1, highlightbackground="#2c3e50")
        self.map_canvas.pack(side="left", fill="both", expand=True)
        self.map_canvas.create_text(360, 30, text="BẢN ĐỒ ĐỊA LÝ HÀNH CHÍNH TP.HCM (AC-3 CHUẨN ĐỊA HÌNH)", font=("Helvetica", 14, "bold"), fill="#E4F1FE")

        sidebar = tk.Frame(container, bg="#141923")
        sidebar.pack(side="right", fill="y", padx=(15, 0))

        tk.Label(sidebar, text="NHẬT KÝ THUẬT TOÁN", font=("Helvetica", 11, "bold"), bg="#141923", fg="#5DADE2").pack(anchor="w", pady=(0, 5))
        
        self.log_widget = tk.Text(sidebar, width=52, height=33, bg="#0B0F19", fg="#85929E", font=("Courier New", 10), bd=0, padx=8, pady=8)
        self.log_widget.pack(fill="both", expand=True)

        self.results_banner = tk.Text(self.root, height=3, bg="#0B0F19", fg="#FFFFFF", font=("Courier New", 10), bd=0, padx=10, pady=5)
        self.results_banner.pack(fill="x", padx=15, pady=(0, 15))

    def insert_terminal_log(self, text):
        self.log_widget.insert("end", text + "\n")
        self.log_widget.see("end")

    def draw_administrative_map(self):
        xs = [p for poly in HCM_MAP_COORDINATES.values() for i, p in enumerate(poly) if i % 2 == 0]
        ys = [p for poly in HCM_MAP_COORDINATES.values() for i, p in enumerate(poly) if i % 2 != 0]
        dx = 360 - (sum(xs) / len(xs))
        dy = 290 - (sum(ys) / len(ys))

        for node, vertices in HCM_MAP_COORDINATES.items():
            adapted_coords = [coord + dx if idx % 2 == 0 else coord + dy for idx, coord in enumerate(vertices)]
            shape_id = self.map_canvas.create_polygon(
                adapted_coords, 
                fill="#E0E0E0", 
                outline="#FFFFFF", 
                width=1.5
            )
            self.polygon_ids[node] = shape_id

        for node, (lx, ly, txt) in DISTRICT_LABELS.items():
            self.map_canvas.create_text(lx + dx, ly + dy, text=txt, font=("Arial", 9, "bold"), fill="#141923")

    def record_animation_history(self, node, color, state_type):
        self.animation_history.append((node, color, state_type))
        self.insert_terminal_log(f"Backtracking: [{state_type}] -> Đặt {node} = {color}")

    def start_processing(self):
        final_solution = self.csp_solver.solve_with_backtracking(self.record_animation_history)
        self.results_banner.insert("end", f"KẾT QUẢ TÔ MÀU CUỐI CÙNG:\n{final_solution}")
        self.root.after(1000, lambda: self.play_visual_animation(0))

    def play_visual_animation(self, step_index):
        if step_index < len(self.animation_history):
            node, color, state_type = self.animation_history[step_index]
            
            if state_type == "ADVANCE":
                self.map_canvas.itemconfig(self.polygon_ids[node], fill=PALETTE_HEX[color])
            elif state_type == "BACKTRACK":
                self.map_canvas.itemconfig(self.polygon_ids[node], fill="#E0E0E0")
                
            self.root.after(150, lambda: self.play_visual_animation(step_index + 1))

if __name__ == "__main__":
    app_window = tk.Tk()
    app_instance = MainApplication(app_window)
    app_window.mainloop()