# ĐỒ ÁN MÔN HỌC: TRÍ TUỆ NHÂN TẠO
# ĐỀ TÀI: GIẢI QUYẾT BÀI TOÁN TÔ MÀU BẢN ĐỒ CÁC QUẬN/HUYỆN TP.HCM BẰNG CSP MIN-CONFLICTS
# Sinh viên thực hiện: Tạ Thùy Phương Vy - 24110069
# https://github.com/tathuyphuongvy-lgtm/Tri_Tue_Nhan_Tao

import tkinter as tk
import random

# ==========================================
# 1. CƠ SỞ DỮ LIỆU BẢN ĐỒ PHÂN TÁCH CHUẨN ĐỊA LÝ
# ==========================================
HCM_MAP_COORDINATES = {
    "Thành phố Thủ Đức": [390, 240, 420, 310, 450, 370, 490, 450, 520, 440, 560, 350, 600, 260, 590, 190, 490, 120, 410, 160],
    "Quận Bình Thạnh":   [330, 220, 390, 240, 420, 310, 350, 330, 320, 280],
    "Quận Phú Nhuận":    [270, 245, 330, 220, 320, 280, 265, 275],
    "Quận Tân Bình":     [150, 235, 270, 245, 265, 275, 250, 345, 210, 325],
    "Quận 10":          [210, 325, 250, 345, 240, 375, 200, 365],
    "Quận 11":          [145, 335, 210, 325, 200, 365, 135, 375],
    "Quận 3":           [250, 345, 265, 275, 320, 280, 290, 355],
    # Co rút nhẹ Quận 1 để chừa khoảng không cho Quận 4 tiếp giáp trực tiếp TP. Thủ Đức và ngăn cách Quận 7
    "Quận 1":           [290, 355, 320, 280, 350, 330, 390, 340, 420, 310, 415, 360, 380, 385, 320, 385],
    "Quận 5":           [200, 365, 240, 375, 290, 355, 320, 385, 260, 425, 190, 415],
    # Kéo rộng Quận 4 sang sườn phải để ôm lấy Quận 1, chạm Thủ Đức và đè lên chặn hoàn toàn Quận 7
    "Quận 4":           [320, 385, 380, 385, 415, 360, 420, 310, 450, 370, 340, 430],
    "Quận 7":           [340, 430, 450, 370, 490, 450, 520, 440, 500, 530, 460, 540, 340, 520],
    "Quận 8":           [90,  425, 140, 425, 190, 415, 260, 425, 320, 385, 340, 430, 340, 520, 290, 485, 210, 465, 130, 465, 95, 455]
}

DISTRICT_LABELS = {
    "Thành phố Thủ Đức": [500, 240, "TP.Thủ Đức"],
    "Quận Bình Thạnh":   [370, 270, "B.Thạnh"],
    "Quận Phú Nhuận":    [300, 250, "P.Nhuận"],
    "Quận Tân Bình":     [205, 275, "T.Bình"],
    "Quận 10":          [223, 348, "Q.10"],
    "Quận 11":          [170, 352, "Q.11"],
    "Quận 3":           [283, 310, "Q.3"],
    "Quận 1":           [345, 345, "Q.1"],
    "Quận 5":           [245, 395, "Q.5"],
    "Quận 4":           [365, 380, "Q.4"],
    "Quận 7":           [415, 475, "Q.7"],
    "Quận 8":           [180, 442, "Q.8"]
}

# DANH SÁCH KỀ ĐÃ ĐƯỢC CHỈNH KHỚP ĐỒNG BỘ TUYỆT ĐỐI VỚI HÌNH HỌC KHÔNG GIAN
HCM_ADJACENCY_LIST = {
    "Quận 1": ["Quận 3", "Quận 4", "Quận 5", "Quận Bình Thạnh", "Thành phố Thủ Đức"],
    "Quận 3": ["Quận 1", "Quận 5", "Quận 10", "Quận Phú Nhuận"],
    "Quận 4": ["Quận 1", "Quận 7", "Quận 8", "Thành phố Thủ Đức"],
    "Quận 5": ["Quận 1", "Quận 3", "Quận 8", "Quận 10", "Quận 11"],
    "Quận 7": ["Quận 4", "Quận 8", "Thành phố Thủ Đức"],
    "Quận 8": ["Quận 4", "Quận 5", "Quận 7", "Quận 11"],
    "Quận 10": ["Quận 3", "Quận 5", "Quận 11", "Quận Tân Bình"],
    "Quận 11": ["Quận 5", "Quận 8", "Quận 10", "Quận Tân Bình"],
    "Quận Phú Nhuận": ["Quận 3", "Quận Bình Thạnh", "Quận Tân Bình"],
    "Quận Bình Thạnh": ["Quận 1", "Quận Phú Nhuận", "Thành phố Thủ Đức"],
    "Quận Tân Bình": ["Quận 10", "Quận 11", "Quận Phú Nhuận"],
    "Thành phố Thủ Đức": ["Quận 1", "Quận 4", "Quận 7", "Quận Bình Thạnh"]
}

PALETTE_HEX = {
    "Đỏ Đô": "#E74C3C",
    "Xanh Lục": "#2ECC71",
    "Xanh Biển": "#3498DB",
    "Vàng Chanh": "#F1C40F"
}

# ==========================================
# 2. LỚP XỬ LÝ TOÁN CSP - MIN-CONFLICTS
# ==========================================
class HcmMapColoringCSP:
    def __init__(self, nodes, edges, colors):
        self.nodes = list(nodes)
        self.edges = edges
        self.colors = list(colors)
        self.state = {node: random.choice(self.colors) for node in self.nodes}

    def compute_conflicts(self, target_node, target_color):
        count = 0
        for neighbor in self.edges.get(target_node, []):
            if self.state.get(neighbor) == target_color:
                count += 1
        return count

    def get_conflicted_nodes(self):
        conflicted = []
        for node in self.nodes:
            if self.compute_conflicts(node, self.state[node]) > 0:
                conflicted.append(node)
        return conflicted


# ==========================================
# 3. GIAO DIỆN VÀ ĐIỀU KHIỂN HOẠT HÌNH
# ==========================================
class Application:
    def __init__(self, window):
        self.window = window
        self.window.title("MÔ PHỎNG CSP MIN-CONFLICTS - BẢN ĐỒ ĐỊA LÝ TP.HCM")
        self.window.geometry("1250x750")
        self.window.configure(bg="#141923")

        self.solver = HcmMapColoringCSP(
            HCM_MAP_COORDINATES.keys(), 
            HCM_ADJACENCY_LIST, 
            PALETTE_HEX.keys()
        )
        
        self.polygon_shapes = {}
        self.setup_ui_layout()
        self.render_initial_map()

    def setup_ui_layout(self):
        body_frame = tk.Frame(self.window, bg="#141923")
        body_frame.pack(fill="both", expand=True, padx=15, pady=15)

        self.view_panel = tk.Canvas(body_frame, width=720, height=580, bg="#192030", highlightthickness=1, highlightbackground="#2c3e50")
        self.view_panel.pack(side="left", fill="both", expand=True)
        self.view_panel.create_text(360, 30, text="BẢN ĐỒ ĐỊA LÝ HÀNH CHÍNH TP.HCM (SỬA LỖI TRÙNG MÀU Q.1 - Q.7)", font=("Helvetica", 14, "bold"), fill="#E4F1FE")

        sidebar = tk.Frame(body_frame, bg="#141923")
        sidebar.pack(side="right", fill="y", padx=(15, 0))

        tk.Label(sidebar, text="TIẾN TRÌNH TỐI ƯU HÓA", font=("Helvetica", 11, "bold"), bg="#141923", fg="#5DADE2").pack(anchor="w", pady=(0, 5))
        
        self.terminal_box = tk.Text(sidebar, width=52, height=33, bg="#0B0F19", fg="#85929E", font=("Courier New", 10), bd=0, padx=8, pady=8)
        self.terminal_box.pack(fill="both", expand=True)
        
        self.status_bar = tk.Label(self.window, text="Hệ thống đã sẵn sàng. Bắt đầu thuật toán sau 1.5 giây...", font=("Helvetica", 11, "italic"), bg="#1C2833", fg="#F2F3F4", height=2, anchor="w", padx=15)
        self.status_bar.pack(fill="x", side="bottom", pady=(5, 0))

    def print_log(self, text_message):
        self.terminal_box.insert("end", text_message + "\n")
        self.terminal_box.see("end")

    def render_initial_map(self):
        xs = [pt for poly in HCM_MAP_COORDINATES.values() for i, pt in enumerate(poly) if i % 2 == 0]
        ys = [pt for poly in HCM_MAP_COORDINATES.values() for i, pt in enumerate(poly) if i % 2 != 0]
        
        dx = 360 - (sum(xs) / len(xs))
        dy = 290 - (sum(ys) / len(ys))

        for district, vertexes in HCM_MAP_COORDINATES.items():
            shifted_coords = [coord + dx if idx % 2 == 0 else coord + dy for idx, coord in enumerate(vertexes)]
            current_color = self.solver.state[district]
            
            shape_id = self.view_panel.create_polygon(
                shifted_coords, 
                fill=PALETTE_HEX[current_color], 
                outline="#ffffff", 
                width=1.5
            )
            self.polygon_shapes[district] = shape_id

        for district, (lx, ly, name) in DISTRICT_LABELS.items():
            self.view_panel.create_text(lx + dx, ly + dy, text=name, font=("Arial", 9, "bold"), fill="#FFFFFF")

    def execute_csp_step(self, generation):
        bad_nodes = self.solver.get_conflicted_nodes()
        
        if not bad_nodes:
            self.print_log("\n>>> THUẬT TOÁN ĐÃ TỐI ƯU: KHÔNG CÒN XUNG ĐỘT MÀU! <<<")
            self.status_bar.configure(text="HOÀN THÀNH: Bản đồ đã được tô đúng quy hoạch, không có quận liền kề trùng màu.", fg="#2ECC71")
            return

        selected_node = random.choice(bad_nodes)
        self.print_log(f"[Vòng {generation}] Kiểm tra: {selected_node} (Xung đột hiện tại)")

        color_scores = {}
        self.print_log("  - Đang duyệt bảng màu:")
        for candidate_color in self.solver.colors:
            penalty = self.solver.compute_conflicts(selected_node, candidate_color)
            color_scores[candidate_color] = penalty
            self.print_log(f"    + Màu {candidate_color}: {penalty} cạnh lỗi")

        best_chosen_color = min(color_scores, key=color_scores.get)
        
        self.solver.state[selected_node] = best_chosen_color
        self.view_panel.itemconfig(self.polygon_shapes[selected_node], fill=PALETTE_HEX[best_chosen_color])
        self.print_log(f"  => GÁN ĐỔI: {selected_node} chuyển sang màu [{best_chosen_color}]\n")

        self.window.after(600, lambda: self.execute_csp_step(generation + 1))


# ==========================================
# 4. KHỞI CHẠY HỆ THỐNG
# ==========================================
if __name__ == "__main__":
    app_root = tk.Tk()
    app_instance = Application(app_root)
    app_root.after(1500, lambda: app_instance.execute_csp_step(1))
    app_root.mainloop()