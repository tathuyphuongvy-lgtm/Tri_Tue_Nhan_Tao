# MSSV: 24110069
# Họ và tên: Tạ Thùy Phương Vy
#https://github.com/tathuyphuongvy-lgtm
# ĐỀ TÀI: GIẢI QUYẾT BÀI TOÁN ROBOT HÚT BỤI BẰNG THUẬT TOÁN AND-OR GRAPH SEARCH

import tkinter as tk
from tkinter import scrolledtext

# =========================================================
# 1. ĐỊNH NGHĨA KHÔNG GIAN TRẠNG THÁI (GRID SYSTEM)
# =========================================================
class TrangThaiMayHutBui:
    def __init__(self, vi_tri_robot, tap_o_ban, danh_xinh_nut=""):
        """
        vi_tri_robot: (hang, cot)
        tap_o_ban: danh sach/set chua cac o nhiem ban
        danh_xinh_nut: chuoi ky tu dinh danh (A, B, C...)
        """
        self.vi_tri_thuc = vi_tri_robot
        
        # Logic dọn dẹp tức thời ngay tại ô robot vừa đáp xuống
        bo_o_ban = set(tap_o_ban)
        if vi_tri_robot in bo_o_ban:
            bo_o_ban.remove(vi_tri_robot)
            
        self.o_chua_don = tuple(sorted(list(bo_o_ban)))
        self.ten_nut = danh_xinh_nut

    def kiem_tra_hoan_thanh(self):
        return len(self.o_chua_don) == 0

    def __eq__(self, doi_tuong_khac):
        if not isinstance(doi_tuong_khac, TrangThaiMayHutBui):
            return False
        return self.vi_tri_thuc == doi_tuong_khac.vi_tri_thuc and self.o_chua_don == doi_tuong_khac.o_chua_don

    def __hash__(self):
        return hash((self.vi_tri_thuc, self.o_chua_don))

    def bieu_dien_ma_tran(self):
        """ Xuất chuỗi đồ họa ký tự đại diện ma trận 3x3 """
        cac_dong = []
        for h in range(3):
            chuoi_o = []
            for c in range(3):
                if (h, c) == self.vi_tri_thuc:
                    chuoi_o.append(" R ") 
                elif (h, c) in self.o_chua_don:
                    chuoi_o.append(" 1 ") 
                else:
                    chuoi_o.append(" 0 ") 
            cac_dong.append("[" + "".join(chuoi_o) + "]")
        return "\n".join(cac_dong)

    def __repr__(self):
        return f"Nút [{self.ten_nut}] (Robot: {self.vi_tri_thuc}):\n{self.bieu_dien_ma_tran()}"


def sinh_dinh_danh_nut(bo_dem_so):
    """ Tự động cấp nhãn ký tự tăng dần theo chu kỳ bảng chữ cái """
    bang_chu_cai = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    vi_tri = bo_dem_so % 26
    vong_lap = bo_dem_so // 26
    ky_tu_goc = bang_chu_cai[vi_tri]
    return ky_tu_goc if vong_lap == 0 else f"{ky_tu_goc}{vong_lap}"


def mo_phong_moi_truong_ngau_nhien(trang_thai_goc, hanh_dong, con_so_dem):
    """ TẠO RA CÁC KỊCH BẢN KHÔNG XÁC ĐỊNH (TÌNH HUỐNG TRƯỢT CHÂN) """
    h, c = trang_thai_goc.vi_tri_thuc
    danh_sach_ket_qua = []
    
    tap_ban_hien_tai = set(trang_thai_goc.o_chua_don)
    if (h, c) in tap_ban_hien_tai:
        tap_ban_hien_tai.remove((h, c))
    
    huong_dich_chuyen = {'UP': (-1, 0), 'DOWN': (1, 0), 'LEFT': (0, -1), 'RIGHT': (0, 1)}
    dh, dc = huong_dich_chuyen[hanh_dong]
    
    # KỊCH BẢN 1: Di chuyển chính xác theo ý muốn
    nh, nc = h + dh, c + dc
    nhan_moi_1 = sinh_dinh_danh_nut(con_so_dem[0])
    con_so_dem[0] += 1
    
    ban_kich_ban_1 = set(tap_ban_hien_tai)
    if (nh, nc) in ban_kich_ban_1:
        ban_kich_ban_1.remove((nh, nc))
    danh_sach_ket_qua.append(TrangThaiMayHutBui((nh, nc), ban_kich_ban_1, danh_xinh_nut=nhan_moi_1))

    # KỊCH BẢN 2: Trượt chân sang hướng vuông góc do sàn ướt
    if hanh_dong in ['LEFT', 'RIGHT']:
        sh, sc = h + 1, c 
        if 0 <= sh < 3 and 0 <= sc < 3:
            nhan_truot = sinh_dinh_danh_nut(con_so_dem[0])
            con_so_dem[0] += 1
            ban_truot = set(tap_ban_hien_tai)
            if (sh, sc) in ban_truot:
                ban_truot.remove((sh, sc))
            danh_sach_ket_qua.append(TrangThaiMayHutBui((sh, sc), ban_truot, danh_xinh_nut=nhan_truot))
        else:
            danh_sach_ket_qua.append(TrangThaiMayHutBui((h, c), tap_ban_hien_tai, danh_xinh_nut=trang_thai_goc.ten_nut))
            
    elif hanh_dong in ['UP', 'DOWN']:
        sh, sc = h, c + 1 
        if 0 <= sh < 3 and 0 <= sc < 3:
            nhan_truot = sinh_dinh_danh_nut(con_so_dem[0])
            con_so_dem[0] += 1
            ban_truot = set(tap_ban_hien_tai)
            if (sh, sc) in ban_truot:
                ban_truot.remove((sh, sc))
            danh_sach_ket_qua.append(TrangThaiMayHutBui((sh, sc), ban_truot, danh_xinh_nut=nhan_truot))
        else:
            danh_sach_ket_qua.append(TrangThaiMayHutBui((h, c), tap_ban_hien_tai, danh_xinh_nut=trang_thai_goc.ten_nut))

    # Lọc bỏ các trạng thái trùng lặp cấu trúc vật lý
    ket_qua_du_nhat = []
    bo_nho_loc = set()
    for kq in danh_sach_ket_qua:
        dau_hieu_nhan_dang = (kq.vi_tri_thuc, kq.o_chua_don)
        if dau_hieu_nhan_dang not in bo_nho_loc:
            bo_nho_loc.add(dau_hieu_nhan_dang)
            ket_qua_du_nhat.append(kq)
            
    return ket_qua_du_nhat


# =========================================================
# 2. ENGINE THUẬT TOÁN AND-OR GRAPH SEARCH
# =========================================================
def thuat_toan_and_or_graph(toa_do_dau, cac_o_ban_dau, sl_hang, sl_cot):
    nhat_ky_hanh_trinh = []
    dem_nut = [0]
    anh_chup_lich_su = []
    
    nhan_dau_tien = sinh_dinh_danh_nut(dem_nut[0])
    dem_nut[0] += 1
    trang_thai_khoi_dau = TrangThaiMayHutBui(toa_do_dau, cac_o_ban_dau, danh_xinh_nut=nhan_dau_tien)
    nhat_ky_hanh_trinh.append(f"📦 KHỞI ĐỘNG HỆ THỐNG SEARCH ===\n{trang_thai_khoi_dau}")
    
    class KhungBaiToan:
        def __init__(self):
            self.goc = trang_thai_khoi_dau
        def lay_nuoc_di(self, st):
            h, c = st.vi_tri_thuc
            nuoc_di_kha_thi = []
            if h > 0: nuoc_di_kha_thi.append('UP')
            if h < 2: nuoc_di_kha_thi.append('DOWN')
            if c > 0: nuoc_di_kha_thi.append('LEFT')
            if c < 2: nuoc_di_kha_thi.append('RIGHT')
            return nuoc_di_kha_thi
        def sinh_trang_thai_con(self, st, act):
            return mo_phong_moi_truong_ngau_nhien(st, act, dem_nut)

    bai_toan = KhungBaiToan()
    
    def _tim_kiem_nhanh_or(trang_thai, duong_di):
        lo_trinh_hien_thoi = duong_di + [trang_thai]
        chu_thich = "TIEN_TRINH"
        
        if trang_thai.kiem_tra_hoan_thanh():
            chu_thich = "DICH_MO_THAY"
        elif trang_thai in duong_di:
            chu_thich = "TRUNG_LAP"
            
        anh_chup_lich_su.append((list(lo_trinh_hien_thoi), chu_thich))
        
        if trang_thai.kiem_tra_hoan_thanh():
            nhat_ky_hanh_trinh.append(f"[ĐỈNH OR] {trang_thai.ten_nut} HOÀN TOÀN SẠCH SẼ -> Đạt mục tiêu.")
            return "Dich_Den_Thanh_Cong"
        if trang_thai in duong_di:
            nhat_ky_hanh_trinh.append(f"[ĐỈNH OR] {trang_thai.ten_nut} lặp lại chu kỳ vòng lặp -> Nhánh hỏng.")
            return "that_bai"
            
        cac_huong_di = bai_toan.lay_nuoc_di(trang_thai)
        nhat_ky_hanh_trinh.append(f"[ĐỈNH OR] Khảo sát nút {trang_thai.ten_nut}. Các hướng hợp lệ: {cac_huong_di}\n{trang_thai}")
        
        for kieu_huong in cac_huong_di:
            tap_ket_qua_con = bai_toan.sinh_trang_thai_con(trang_thai, kieu_huong)
            chuoi_dinh_danh = ", ".join([k.ten_nut for k in tap_ket_qua_con])
            nhat_ky_hanh_trinh.append(f"Thử nghiệm di chuyển [{kieu_huong}] ➔ Rẽ xuống [ĐỈNH AND] gom nhóm: [{chuoi_dinh_danh}]")
            
            chien_luoc_con = _tim_kiem_nhanh_and(tap_ket_qua_con, lo_trinh_hien_thoi, chuoi_dinh_danh)
            
            if chien_luoc_con != "that_bai":
                nhat_ky_hanh_trinh.append(f"[ĐỈNH OR] Nút {trang_thai.ten_nut} QUYẾT ĐỊNH chọn hướng [{kieu_huong}]!")
                return {kieu_huong: chien_luoc_con}
            else:
                nhat_ky_hanh_trinh.append(f"[QUAY LUI] Hướng đi [{kieu_huong}] bế tắc! Khôi phục về vị trí cha: {trang_thai.ten_nut}")
                anh_chup_lich_su.append((list(lo_trinh_hien_thoi), f"BACKTRACK_{kieu_huong}_{chuoi_dinh_danh}"))
                
        nhat_ky_hanh_trinh.append(f"[ĐỈNH OR - CẠN KIỆT] Nút {trang_thai.ten_nut} bó tay, không giải quyết được đỉnh AND nào.")
        return "that_bai"

    def _tim_kiem_nhanh_and(tap_trang_thai, duong_di, ten_nhom_and):
        chuoi_ten_nut = ", ".join([k.ten_nut for k in tap_trang_thai])
        nhat_ky_hanh_trinh.append(f"[ĐỈNH AND] Bắt buộc bao phủ mọi nhánh của tập: [{chuoi_ten_nut}]")
        cac_hoach_dinh = {}
        for nhanh_con in tap_trang_thai:
            nhat_ky_hanh_trinh.append(f"Duyệt trường hợp ngẫu nhiên của AND: {nhanh_con.ten_nut}")
            kq_nhanh = _tim_kiem_nhanh_or(nhanh_con, duong_di)
            if kq_nhanh == "that_bai":
                nhat_ky_hanh_trinh.append(f"Nhánh địa bàn {nhanh_con.ten_nut} sập! Toàn bộ tập AND [{chuoi_ten_nut}] vỡ trận.")
                return "that_bai"
            cac_hoach_dinh[nhanh_con] = kq_nhanh
        nhat_ky_hanh_trinh.append(f"[ĐỈNH AND] Hoàn tất xử lý an toàn cho cụm kết quả: [{chuoi_ten_nut}]")
        return cac_hoach_dinh

    ket_qua_cay = _tim_kiem_nhanh_or(bai_toan.goc, [])
    
    duong_di_phang = []
    if ket_qua_cay and ket_qua_cay != "that_bai":
        def boc_tach_tuyen_duong(st, ke_hoach_hien_tai):
            duong_di_phang.append(st)
            if ke_hoach_hien_tai == "Dich_Den_Thanh_Cong" or not isinstance(ke_hoach_hien_tai, dict):
                return
            for hanh_dong, sub_plan in ke_hoach_hien_tai.items():
                if isinstance(sub_plan, dict):
                    for tiep_theo, next_sub in sub_plan.items():
                        boc_tach_tuyen_duong(tiep_theo, next_sub)
                        break
                break
        boc_tach_tuyen_duong(bai_toan.goc, ket_qua_cay)
        nhat_ky_hanh_trinh.append("[THÀNH CÔNG RỰC RỠ] Đã xây dựng xong sơ đồ di chuyển an toàn!")
        return duong_di_phang, nhat_ky_hanh_trinh, False
    else:
        nhat_ky_hanh_trinh.append("[THẤT BẠI LÀM LẠI] Không tìm thấy giải pháp chống trượt chân tối ưu.")
        return anh_chup_lich_su, nhat_ky_hanh_trinh, True


# =========================================================
# 3. GIAO DIỆN HÌNH ẢNH ĐỒ HỌA ỨNG DỤNG (GUI RUN)
# =========================================================
def run(center_frame, log_text, result_text, name=None):
    SO_HANG, SO_COT = 3, 3  
    vi_tri_dau = (0, 0) 
    o_buan_ban_dau = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    tk.Label(center_frame, text="MÔ PHỎNG AND-OR GRAPH SEARCH", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8).pack(side="top", fill="x", pady=(10, 5))

    nhan_thong_bao_trang_thai = tk.Label(center_frame, text="🤖 ĐANG KHỞI TẠO TIẾN TRÌNH...", bg="#ffffff", fg="#1a1a1a", font=("Segoe UI", 12, "bold"), wraplength=700, justify="center")
    nhan_thong_bao_trang_thai.pack(side="top", pady=(5, 5))

    khung_chu_giai = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    khung_chu_giai.pack(side="top", fill="x", padx=40, pady=(0, 15))
    vung_loi_chu_giai = tk.Frame(khung_chu_giai, bg="#1a1a1a")
    vung_loi_chu_giai.pack(anchor="center")
    
    tk.Label(vung_loi_chu_giai, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(vung_loi_chu_giai, text="0 = SẠCH", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(vung_loi_chu_giai, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(vung_loi_chu_giai, text="1 = BẨN", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(vung_loi_chu_giai, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(vung_loi_chu_giai, text="XANH = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    vung_chua_canvas = tk.Frame(center_frame, bg="#ffffff")
    vung_chua_canvas.pack(expand=True)
    KICH_THUOC_O = 100
    khu_vuc_ve = tk.Canvas(vung_chua_canvas, width=SO_COT * KICH_THUOC_O, height=SO_HANG * KICH_THUOC_O, bg="#ffffff", highlightthickness=0)
    khu_vuc_ve.pack(side="bottom")

    du_lieu_tim_kiem, nhat_ky_text, da_that_bai = thuat_toan_and_or_graph(vi_tri_dau, o_buan_ban_dau, SO_HANG, SO_COT)
    
    log_text.delete("1.0", tk.END)
    for khoi_ghi in nhat_ky_text:
        log_text.insert(tk.END, khoi_ghi + "\n\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not du_lieu_tim_kiem or len(du_lieu_tim_kiem) == 0:
        result_text.insert(tk.END, "Kết quả đầu ra: KHÔNG TÌM ĐƯỢC CHIẾN LƯỢC KHA THI!")
        return

    if not da_that_bai:
        lo_trinh_chuan = du_lieu_tim_kiem
        chuoi_ten_cac_nut = [n.ten_nut for n in lo_trinh_chuan]
        chuoi_toa_do_di = [str(n.vi_tri_thuc) for n in lo_trinh_chuan]
        result_text.insert(tk.END, "=== KẾT QUẢ CHIẾN LƯỢC CUỐI CÙNG ===\n\n")
        result_text.insert(tk.END, f"Chuỗi tiến trình nút:\n{' -> '.join(chuoi_ten_cac_nut)}\n\n")
        result_text.insert(tk.END, f"Tọa độ không gian dịch chuyển:\n{' -> '.join(chuoi_toa_do_di)}\n\n")
        result_text.insert(tk.END, "TRẠNG THÁI CHUNG: THÀNH CÔNG MỸ MÃN!")
    else:
        lo_trinh_chuan = du_lieu_tim_kiem[-1][0]
        result_text.insert(tk.END, "=== HỆ THỐNG KHÔNG TÌM ĐƯỢC ĐƯỜNG ĐI ===\n\n")
        result_text.insert(tk.END, "TRẠNG THÁI CHUNG: BỊ KẸT NGOẠI CẢNH (Thuật toán duyệt thất bại toàn bộ nhánh)!")

    def cap_nhat_khung_hinh_ve(mang_nut_lo_trinh, kieu_ghi_chu="TIEN_TRINH"):
        khu_vuc_ve.delete("all")
        if not mang_nut_lo_trinh: return
        
        nut_hien_hanh = mang_nut_lo_trinh[-1]
        
        if kieu_ghi_chu == "DICH_MO_THAY":
            nhan_thong_bao_trang_thai.config(text=f"[ĐỈNH OR] Địa bàn {nut_hien_hanh.ten_nut} SẠCH BONG! (Đang quét nốt nhánh song song)...", fg="#009933")
        elif kieu_ghi_chu == "TRUNG_LAP":
            nhan_thong_bao_trang_thai.config(text=f"[ĐỈNH OR] Địa bàn {nut_hien_hanh.ten_nut} dính cấu trúc lặp vòng ➔ Ngắt nhánh!", fg="#cc0000")
        elif kieu_ghi_chu.startswith("BACKTRACK_"):
            _, cach_di, chuoi_cum_and = kieu_ghi_chu.split("_")
            nhan_thong_bao_trang_thai.config(text=f"[QUAY LUI] Hướng [{cach_di}] kẹt lỗi tại tập AND [{chuoi_cum_and}]!\nQuay về nút gốc: {nut_hien_hanh.ten_nut}", fg="#ff6600")
        else:
            nhan_thong_bao_trang_thai.config(text=f"[ĐANG DUYỆT THỬ] Tiến hành phân tích cấu trúc nút: {nut_hien_hanh.ten_nut}", fg="#0066cc")

        for r in range(SO_HANG):
            for c in range(SO_COT):
                x1, y1 = c * KICH_THUOC_O, r * KICH_THUOC_O
                x2, y2 = x1 + KICH_THUOC_O, y1 + KICH_THUOC_O
                o_nhiem_ban = (r, c) in nut_hien_hanh.o_chua_don
                
                if (r, c) == nut_hien_hanh.vi_tri_thuc:
                    nen_cell, mau_chu, vien_rong = "#3399ff", "white", 3
                else:
                    nen_cell, mau_chu, vien_rong = ("#ff6666", "white", 1) if o_nhiem_ban else ("#e0e0e0", "#444444", 1)
                    
                khu_vuc_ve.create_rectangle(x1, y1, x2, y2, fill=nen_cell, outline="white", width=vien_rong)
                khu_vuc_ve.create_text(x1 + KICH_THUOC_O/2, y1 + KICH_THUOC_O/2, text="1" if o_nhiem_ban else "0", fill=mau_chu, font=("Consolas", 20, "bold"))
                
                if (r, c) == nut_hien_hanh.vi_tri_thuc:
                    khu_vuc_ve.create_text(x1 + KICH_THUOC_O/2, y1 + KICH_THUOC_O/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
                    
        if len(mang_nut_lo_trinh) > 1:
            for i in range(len(mang_nut_lo_trinh) - 1):
                r1, c1 = mang_nut_lo_trinh[i].vi_tri_thuc
                r2, c2 = mang_nut_lo_trinh[i+1].vi_tri_thuc
                khu_vuc_ve.create_line(c1*KICH_THUOC_O + KICH_THUOC_O/2, r1*KICH_THUOC_O + KICH_THUOC_O/2, c2*KICH_THUOC_O + KICH_THUOC_O/2, r2*KICH_THUOC_O + KICH_THUOC_O/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def dieu_khien_hoat_hoa(chi_so_buoc):
        if not da_that_bai:
            if chi_so_buoc < len(lo_trinh_chuan):
                cap_nhat_khung_hinh_ve(lo_trinh_chuan[:chi_so_buoc + 1], "TIEN_TRINH")
                center_frame.after(700, lambda: dieu_khien_hoat_hoa(chi_so_buoc + 1))
            else:
                nhan_thong_bao_trang_thai.config(text="KẾT THÚC: HOÀN THÀNH CHIẾN LƯỢC TOÀN DIỆN!", fg="#009933")
        else:
            if chi_so_buoc < len(du_lieu_tim_kiem):
                ban_chup_hien_tai, kieu_chu_thich = du_lieu_tim_kiem[chi_so_buoc]
                trang_thai_dung_lau = (kieu_chu_thich == "DICH_MO_THAY" or kieu_chu_thich.startswith("BACKTRACK_") or kieu_chu_thich == "TRUNG_LAP")
                thoi_gian_cho = 1500 if trang_thai_dung_lau else 700
                    
                cap_nhat_khung_hinh_ve(ban_chup_hien_tai, kieu_chu_thich)
                center_frame.after(thoi_gian_cho, lambda: dieu_khien_hoat_hoa(chi_so_buoc + 1))
            else:
                nhan_thong_bao_trang_thai.config(text="KẾT THÚC: ROBOT BẤT LỰC TRƯỚC MÔI TRƯỜNG!", fg="#cc0000")
                
    dieu_khien_hoat_hoa(0)

# =========================================================
# KHỞI TẠO CỬA SỔ CHÍNH ĐỘC LẬP (MAIN WINDOW)
# =========================================================
if __name__ == "__main__":
    cua_so_goc = tk.Tk()
    cua_so_goc.title("HỆ THỐNG GIẢI QUYẾT BÀI TOÁN ROBOT - AND-OR SEARCH")
    cua_so_goc.geometry("1450x950")
    cua_so_goc.configure(bg="#1e1e1e")

    # Phân chia bố cục tương tự như các ứng dụng trước
    khung_chia_tren = tk.Frame(cua_so_goc, bg="#1e1e1e")
    khung_chia_tren.pack(side="top", fill="both", expand=True)

    khung_do_hoa = tk.Frame(khung_chia_tren, bg="#ffffff", bd=1, relief="solid")
    khung_do_hoa.pack(side="left", padx=10, pady=10, fill="both", expand=True)

    khung_tien_trinh = tk.Frame(khung_chia_tren, bg="#1e1e1e")
    khung_tien_trinh.pack(side="right", padx=10, pady=10, fill="y")

    # Khung Log bên phải
    tk.Label(khung_tien_trinh, text="NHẬT KÝ KHÔNG GIAN ĐỒ THỊ", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    txt_log = scrolledtext.ScrolledText(khung_tien_trinh, width=65, height=40, font=("Consolas", 10), bg="#000000", fg="#ffffff")
    txt_log.pack(pady=(0, 10))

    # Khung Kết quả bên dưới
    khung_chia_duoi = tk.Frame(cua_so_goc, bg="#1e1e1e")
    khung_chia_duoi.pack(side="bottom", fill="x", padx=10, pady=10)
    tk.Label(khung_chia_duoi, text="CHIẾN LƯỢC ĐẦU RA", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    txt_ket_qua = scrolledtext.ScrolledText(khung_chia_duoi, height=8, font=("Consolas", 11), bg="#000000", fg="#ffffff")
    txt_ket_qua.pack(fill="x")

    # Kích hoạt hàm điều khiển
    run(khung_do_hoa, txt_log, txt_ket_qua)
    cua_so_goc.mainloop()