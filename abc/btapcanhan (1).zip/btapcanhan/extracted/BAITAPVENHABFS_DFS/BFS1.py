import tkinter as tk
from collections import deque

def run(center_frame, log_text, result_text, algo_name):

    # =====================================================
    # CLEAR UI
    # =====================================================
    for w in center_frame.winfo_children():
        w.destroy()

    log_text.delete("1.0", "end")
    result_text.delete("1.0", "end")

    # =====================================================
    # TITLE
    # =====================================================
    tk.Label(
        center_frame,
        text="VACUUM WORLD - BFS APPROACH 1 (OPTIMIZED)",
        bg="#1e1e1e",
        fg="#00ffcc",
        font=("Segoe UI", 16, "bold")
    ).pack(pady=10)

    # =====================================================
    # LEGEND
    # =====================================================
    legend_frame = tk.Frame(center_frame, bg="#1e1e1e")
    legend_frame.pack(pady=5)

    legends = [
        ("0 = CLEAN CELL", "#dddddd"),
        ("1 = DIRTY CELL", "#ff6666"),
        ("BLUE = ROBOT", "#3399ff")
    ]

    for text, color in legends:
        item = tk.Frame(legend_frame, bg="#1e1e1e")
        item.pack(side="left", padx=15)

        tk.Canvas(
            item, width=20, height=20, bg=color,
            highlightthickness=1, highlightbackground="black"
        ).pack(side="left", padx=5)

        tk.Label(
            item, text=text, fg="white", bg="#1e1e1e",
            font=("Consolas", 10, "bold")
        ).pack(side="left")

    # =====================================================
    # INITIAL CONFIGURATION
    # =====================================================
    initial_grid = (
        (0, 1, 0),
        (1, 1, 0),
        (0, 0, 1)
    )
    rows = 3
    cols = 3
    size = 100

    # =====================================================
    # CANVAS SETUP
    # =====================================================
    canvas = tk.Canvas(center_frame, bg="white")
    canvas.pack(fill="both", expand=True)
    canvas.update()

    offset_x = (canvas.winfo_width() - cols * size) // 2
    offset_y = (canvas.winfo_height() - rows * size) // 2

    cells = {}
    texts = {}
    centers = {}

    # DRAW GRID
    for r in range(rows):
        for c in range(cols):
            x1 = offset_x + c * size
            y1 = offset_y + r * size
            x2 = x1 + size
            y2 = y1 + size

            color = "#ff6666" if initial_grid[r][c] == 1 else "#dddddd"

            cells[(r, c)] = canvas.create_rectangle(
                x1, y1, x2, y2, fill=color, outline="black", width=2
            )
            texts[(r, c)] = canvas.create_text(
                (x1 + x2) // 2, (y1 + y2) // 2,
                text=str(initial_grid[r][c]), font=("Consolas", 16, "bold")
            )
            centers[(r, c)] = ((x1 + x2) // 2, (y1 + y2) // 2)

    # ROBOT GRAPHIC
    robot = canvas.create_rectangle(0, 0, 0, 0, fill="#3399ff")

    def move_robot(r, c):
        robot_size = 50
        center_x, center_y = centers[(r, c)]
        x1 = center_x - robot_size // 2
        y1 = center_y - robot_size // 2
        x2 = center_x + robot_size // 2
        y2 = center_y + robot_size // 2
        canvas.coords(robot, x1, y1, x2, y2)

    move_robot(0, 0)

    # =====================================================
    # HELPER FUNCTIONS
    # =====================================================
    def is_goal(grid):
        return all(cell == 0 for row in grid for cell in row)

    def clean_grid(grid, r, c):
        new_grid = [list(row) for row in grid]
        new_grid[r][c] = 0
        return tuple(tuple(row) for row in new_grid)

    def neighbors(r, c):
        directions = [("R", 0, 1), ("D", 1, 0), ("L", 0, -1), ("U", -1, 0)]
        for action, dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                yield action, nr, nc

    def grid_to_string(grid):
        return "\n".join(" ".join(map(str, row)) for row in grid) + "\n"

    # =====================================================
    # BFS APPROACH 1 (Goal check ONLY after POP)
    # =====================================================
    def bfs():
        start_state = ((0, 0), initial_grid)
        
        queue = deque([{
            "state": start_state,
            "parent": None,
            "action": None,
            "step": 0,
            "path": [start_state]
        }])

        reached = set([start_state])
        pop_count = 0

        while queue:
            node = queue.popleft()
            pop_count += 1
            
            (r, c), grid = node["state"]
            parent = node["parent"]
            action = node["action"]
            step = node["step"]

            # Ghi LOG POP vào text box (Giới hạn log để tránh đơ UI nếu chạy quá dài)
            if pop_count <= 200:
                log_text.insert("end", f"\n[POP #{pop_count}] ROBOT={r,c}\n")
                log_text.insert("end", f"Parent: {parent} | Action: {action} | Step: {step}\n")
                log_text.insert("end", grid_to_string(grid))

            # KIỂM TRA ĐÍCH (Đúng chuẩn BFS 1: Chỉ kiểm tra sau khi POP)
            if is_goal(grid):
                log_text.insert("end", f"\n=> GOAL FOUND AT STEP {step}! (Total Pops: {pop_count})\n")
                log_text.insert("end", "=========================\n")
                return node["path"]

            # MỞ RỘNG (EXPAND)
            if pop_count <= 200:
                log_text.insert("end", "\nEXPAND:\n")

            for act, nr, nc in neighbors(r, c):
                # Khác biệt cốt lõi: Chỉ tạo lưới mới nếu ô di chuyển tới là ô BẨN (1)
                # Nếu ô đã SẠCH (0), giữ nguyên trạng thái lưới cũ để tránh sinh trạng thái rác gây lặp vô tận
                if grid[nr][nc] == 1:
                    new_grid = clean_grid(grid, nr, nc)
                else:
                    new_grid = grid

                child_state = ((nr, nc), new_grid)

                if child_state not in reached:
                    reached.add(child_state)
                    
                    child_node = {
                        "state": child_state,
                        "parent": node["state"],
                        "action": act,
                        "step": step + 1,
                        "path": node["path"] + [child_state]
                    }
                    queue.append(child_node)

                    if pop_count <= 200:
                        log_text.insert("end", f" PUSH {nr,nc} | A={act} | S={step+1}\n")

            if pop_count == 201:
                log_text.insert("end", "\n... [Log truncated for performance] ...\n")
                
            log_text.see("end")
        return None

    # TẠO LUỒNG CHẠY THUẬT TOÁN
    solution_path = bfs()

    # =====================================================
    # ANIMATION & DISPLAY RESULT
    # =====================================================
    if solution_path is None:
        result_text.insert("end", "NO SOLUTION")
        return

    def animate(index):
        if index >= len(solution_path):
            result_text.insert("end", "ALL CLEAN!\n\nSHORTEST PATH:\n\n")
            path_str = " -> ".join(str(state[0]) for state in solution_path)
            result_text.insert("end", path_str)
            result_text.insert("end", f"\n\nTOTAL STEPS: {len(solution_path) - 1}")
            return

        (r, c), grid = solution_path[index]
        move_robot(r, c)

        # Cập nhật màu sắc ô lưới thời gian thực trên Canvas
        for rr in range(rows):
            for cc in range(cols):
                val = grid[rr][cc]
                canvas.itemconfig(texts[(rr, cc)], text=str(val))
                color = "#ff6666" if val == 1 else "#dddddd"
                canvas.itemconfig(cells[(rr, cc)], fill=color)

        # Vẽ đường mũi tên màu xanh nối các bước đi
        if index > 0:
            (pr, pc), _ = solution_path[index - 1]
            x1, y1 = centers[(pr, pc)]
            x2, y2 = centers[(r, c)]
            canvas.create_line(x1, y1, x2, y2, width=4, fill="blue", arrow=tk.LAST)

        center_frame.after(600, lambda: animate(index + 1))

    animate(0)