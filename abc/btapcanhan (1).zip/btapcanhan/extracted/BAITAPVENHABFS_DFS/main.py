
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import os
import importlib

# =========================================================
# TỰ ĐỘNG QUÉT VÀ NẠP CÁC FILE THUẬT TOÁN (DYNAMIC LOAD)
# =========================================================
algorithms = {}
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Quét tất cả các file .py trong thư mục để tự động tạo Button
for file in os.listdir(BASE_DIR):
    if file.endswith(".py") and file != "main.py":
        name = file[:-3]
        try:
            module = importlib.import_module(name)
            importlib.reload(module)

            # Nếu file thuật toán có chứa hàm "run", nạp vào danh sách hệ thống
            if hasattr(module, "run"):
                display_name = name.replace("_", " ").upper()
                algorithms[display_name] = module.run
        except Exception as e:
            print(f"Không thể tải thuật toán {name}: {e}")

print("Thuật toán đã nạp thành công:", list(algorithms.keys()))

# =========================================================
# CẤU HÌNH CỬA SỔ CHÍNH (WINDOW)
# =========================================================
root = tk.Tk()
root.title("AI Algorithm Visualizer - Vacuum World States")
root.geometry("1450x820")
root.configure(bg="#121212")

MENU_WIDTH = 260
active_button = None
menu_visible = False

# =========================================================
# THANH CÔNG CỤ PHÍA TRÊN (TOP BAR)
# =========================================================
top_bar = tk.Frame(root, bg="#1f1f1f", height=55)
top_bar.pack(side="top", fill="x")

# =========================================================
# VÙNG HIỂN THỊ CHÍNH (MAIN CONTAINER)
# =========================================================
main_container = tk.Frame(root, bg="#121212")
main_container.pack(fill="both", expand=True)

# 1. KHUNG TRUNG TÂM (CENTER FRAME): Nơi vẽ Grid ma trận và Robot di chuyển
center_frame = tk.Frame(main_container, bg="#1e1e1e")
center_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

# 2. KHUNG LOG BÊN PHẢI (PROCESS LOG): Hiển thị trạng thái Stack/Queue
log_frame = tk.Frame(main_container, bg="#1a1a1a", width=380)
log_frame.pack(side="right", fill="y", padx=(0, 10), pady=10)
log_frame.pack_propagate(False) # Cố định độ rộng khung Log không cho co giãn

log_title = tk.Label(
    log_frame,
    text="PROCESS LOG",
    bg="#1a1a1a",
    fg="#ffcc00",
    font=("Segoe UI", 13, "bold")
)
log_title.pack(anchor="w", padx=10, pady=12)

log_text = ScrolledText(
    log_frame,
    bg="#111111",
    fg="#00ffcc",
    insertbackground="white",
    font=("Consolas", 10),
    relief="flat"
)
log_text.pack(fill="both", expand=True, padx=10, pady=(0, 12))

# =========================================================
# KHUNG HIỂN THỊ KẾT QUẢ ĐÍCH PHÍA DƯỚI (BOTTOM BAR)
# =========================================================
bottom_frame = tk.Frame(root, bg="#0f0f0f", height=130)
bottom_frame.pack(side="bottom", fill="x")

solution_title = tk.Label(
    bottom_frame,
    text="FINAL SOLUTION PATH",
    bg="#0f0f0f",
    fg="#00ff66",
    font=("Segoe UI", 12, "bold")
)
solution_title.pack(anchor="w", padx=15, pady=(8, 4))

result_text = tk.Text(
    bottom_frame,
    height=3,
    bg="#111111",
    fg="white",
    font=("Consolas", 11),
    relief="flat"
)
result_text.pack(fill="x", padx=15, pady=(0, 12))

# =========================================================
# MENU TRƯỢT SANG BÊN (SLIDE MENU)
# =========================================================
side_menu = tk.Frame(root, bg="#202020", width=MENU_WIDTH)
# Ban đầu ẩn Menu bằng cách đặt vị trí x âm ra ngoài màn hình
side_menu.place(x=-MENU_WIDTH, y=55, relheight=1)

menu_title = tk.Label(
    side_menu,
    text="THUẬT TOÁN",
    bg="#202020",
    fg="white",
    font=("Segoe UI", 14, "bold")
)
menu_title.pack(pady=20)

# =========================================================
# HIỆU ỨNG DI CHUYỂN MENU (SLIDE ANIMATION)
# =========================================================
def slide_in(x=-MENU_WIDTH):
    if x < 0:
        side_menu.place(x=x, y=55)
        root.after(4, lambda: slide_in(x + 20))
    else:
        side_menu.place(x=0, y=55)

def slide_out(x=0):
    if x > -MENU_WIDTH:
        side_menu.place(x=x, y=55)
        root.after(4, lambda: slide_out(x - 20))
    else:
        side_menu.place(x=-MENU_WIDTH, y=55)

def toggle_menu():
    global menu_visible
    if menu_visible:
        slide_out()
    else:
        slide_in()
    menu_visible = not menu_visible

# =========================================================
# NỘI DUNG THANH TOP BAR (NÚT ☰ VÀ TIÊU ĐỀ)
# =========================================================
menu_btn = tk.Button(
    top_bar,
    text="☰ Menu",
    font=("Segoe UI", 12, "bold"),
    bg="#2d2d2d",
    fg="white",
    bd=0,
    padx=10,
    activebackground="#4caf50",
    activeforeground="white",
    command=toggle_menu
)
menu_btn.pack(side="left", padx=15, pady=8)

title = tk.Label(
    top_bar,
    text="AI STATE-SPACE SEARCH VISUALIZER",
    bg="#1f1f1f",
    fg="white",
    font=("Segoe UI", 14, "bold")
)
title.pack(side="left", padx=5)

# =========================================================
# ĐIỀU KHIỂN KHI BẤM CHẠY THUẬT TOÁN
# =========================================================
def run_algo(func, btn, name):
    global active_button

    # Đặt lại màu xám mặc định cho nút đã chọn cũ
    if active_button:
        active_button.config(bg="#2d2d2d")

    # Đổi nút đang chọn hiện tại thành màu xanh lá cây rực rỡ
    btn.config(bg="#4caf50")
    active_button = btn

    # Gọi hàm xử lý đồ họa cốt lõi từ file python bên ngoài được liên kết tới
    func(center_frame, log_text, result_text, name)

    # Tự động đóng Menu trượt để nhường không gian quan sát
    toggle_menu()

# =========================================================
# TỰ ĐỘNG KHỞI TẠO CÁC BUTTON LỰA CHỌN THUẬT TOÁN
# =========================================================
for name, func in algorithms.items():
    btn = tk.Button(
        side_menu,
        text=name,
        bg="#2d2d2d",
        fg="white",
        relief="flat",
        font=("Segoe UI", 11, "bold"),
        pady=12,
        activebackground="#4caf50",
        activeforeground="white"
    )

    # Đăng ký sự kiện Click chuông kích hoạt thuật toán tương ứng
    btn.config(command=lambda f=func, b=btn, n=name: run_algo(f, b, n))

    # Đăng ký sự kiện Hover khi rê chuột vào nút
    btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#3fa34d") if b != active_button else None)

    # Đăng ký sự kiện rời chuột (Leave) khỏi nút
    btn.bind("<Leave>", lambda e, b=btn: b.config(bg="#2d2d2d") if b != active_button else None)

    btn.pack(fill="x", padx=15, pady=6)

# =========================================================
# MÀN HÌNH CHÀO MỪNG BAN ĐẦU (WELCOME SCREEN)
# =========================================================
welcome = tk.Label(
    center_frame,
    text="VUI LÒNG BẤM NÚT ☰ MENU\nĐỂ CHỌN MÔ PHỎNG THUẬT TOÁN",
    bg="#1e1e1e",
    fg="#777777",
    font=("Segoe UI", 16, "bold"),
    justify="center"
)
welcome.pack(expand=True)

# Khởi chạy ứng dụng đồ họa
root.mainloop()