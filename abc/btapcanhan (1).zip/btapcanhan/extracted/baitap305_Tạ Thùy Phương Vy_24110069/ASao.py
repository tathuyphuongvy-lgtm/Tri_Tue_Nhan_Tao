#  Tạ Thùy Phương Vy (24110069)

import tkinter as tk
import copy

# Bộ đếm tự động sinh tên nút (X0, Y0, Z0...) tránh bị trùng cấu trúc đặt tên cũ
sequential_id_generator = 0

def auto_generate_node_label():
    global sequential_id_generator
    generation_round = sequential_id_generator // 26
    character_position = sequential_id_generator % 26
    alphabet_char = chr(65 + character_position)  # Mã ASCII xuất phát từ 'A'
    sequential_id_generator += 1
    return f"{alphabet_char}{generation_round}" if generation_round > 0 else alphabet_char

WEIGHT_ALPHA = 1.0  # f(n) = g(n) + WEIGHT_ALPHA * h(n)

# =========================================================
# KHÔNG GIAN TRẠNG THÁI TOÁN HỌC CỦA THIẾT BỊ
# =========================================================
class VacuumGridAgentState:
    """Quản lý thông tin tọa độ máy hút, tập hợp ô bẩn và tính toán hàm đánh giá f(n)."""
    def __init__(self, position_xy, dirty_set, ancestral_node=None, step_action=None, g_cost=0, node_title='S'):
        self.agent_coords = position_xy
        self.dirt_registry = frozenset(dirty_set)
        self.ancestral_node = ancestral_node
        self.step_action = step_action
        self.g_cost = g_cost  # g(n): Tổng số bước từ nút gốc
        self.h_cost = len(self.dirt_registry)  # h(n): Số lượng ô bẩn còn lại
        self.f_cost = self.g_cost + (WEIGHT_ALPHA * self.h_cost)
        self.node_title = node_title

    def verify_goal_reached(self):
        return len(self.dirt_registry) == 0

    def compute_state_signature(self):
        return (self.agent_coords, tuple(sorted(list(self.dirt_registry))))

    def expand_next_states(self, limit_r, limit_c):
        """Sinh các trạng thái kế tiếp: Hút rác tại chỗ hoặc di chuyển đổi tọa độ."""
        generated_nodes = []
        r, c = self.agent_coords
        
        # Hành động 1: Hút bụi (Suck) tại vị trí hiện tại nếu ô đó có rác
        if (r, c) in self.dirt_registry:
            updated_dirt_set = set(self.dirt_registry)
            updated_dirt_set.remove((r, c))
            generated_nodes.append(VacuumGridAgentState(
                position_xy=(r, c),
                dirty_set=updated_dirt_set,
                ancestral_node=self,
                step_action="Suck",
                g_cost=self.g_cost + 1,
                node_title=""
            ))
        
        # Hành động 2: Di chuyển bốn hướng (Đổi thứ tự ưu tiên thành: R, L, D, U)
        directional_moves = [("R", r, c + 1), ("L", r, c - 1), ("D", r + 1, c), ("U", r - 1, c)]
        for move_id, next_r, next_c in directional_moves:
            if 0 <= next_r < limit_r and 0 <= next_c < limit_c:
                retained_dirt_set = set(self.dirt_registry)
                generated_nodes.append(VacuumGridAgentState(
                    position_xy=(next_r, next_c),
                    dirty_set=retained_dirt_set,
                    ancestral_node=self,
                    step_action=move_id,
                    g_cost=self.g_cost + 1,
                    node_title=""
                ))
        return generated_nodes

# =========================================================
# CHUYỂN ĐỔI MA TRẬN PHỤC VỤ GHI FILE NHẬT KÝ
# =========================================================
def stringify_board_layout(dirty_frozenset, total_rows=3, total_cols=3):
    rendered_rows = []
    for r in range(total_rows):
        row_symbols = ["[█]" if (r, c) in dirty_frozenset else "[░]" for c in range(total_cols)]
        rendered_rows.append("  ".join(row_symbols))
    return "\n".join(rendered_rows)

# =========================================================
# THUẬT TOÁN TÌM KIẾM IDA* (ITERATIVE DEEPENING A*)
# =========================================================
def run_ida_star_search(initial_xy, global_dirty_list, max_r, max_c):
    global sequential_id_generator
    sequential_id_generator = 0
    
    root_state = VacuumGridAgentState(initial_xy, global_dirty_list, node_title="S")
    f_threshold = root_state.f_cost
    search_history_logs = []
    traversed_path_nodes = []
    reached_sequence_tracker = []
    global_reached_table = {}

    def recursive_depth_search(current_node, current_threshold):
        traversed_path_nodes.append(f"{current_node.node_title}(f={current_node.f_cost:.1f})")
        unique_signature = current_node.compute_state_signature()
        
        # Cắt tỉa nhánh nếu trạng thái này từng được duyệt với chi phí g(n) thấp hơn
        if unique_signature in global_reached_table and global_reached_table[unique_signature] <= current_node.g_cost:
            return float('inf'), None
        global_reached_table[unique_signature] = current_node.g_cost

        parent_label = current_node.ancestral_node.node_title if current_node.ancestral_node else "None"
        node_summary_chunk = [
            f"[POP] ĐANG KHẢO SÁT: {current_node.node_title} (Vị trí={current_node.agent_coords})",
            f"Nút cha={parent_label} | Hành động={current_node.step_action} | g={current_node.g_cost} | h={current_node.h_cost} | f={current_node.f_cost:.1f}",
            stringify_board_layout(current_node.dirt_registry, max_r, max_c)
        ]

        if current_node.verify_goal_reached():
            node_summary_chunk.append(f"-> THÀNH CÔNG: Đã tìm thấy đích tại nút {current_node.node_title}!")
            search_history_logs.append("\n".join(node_summary_chunk))
            return "FOUND", current_node

        if current_node.f_cost > current_threshold:
            node_summary_chunk.append(f"-> Vượt ngưỡng i={current_threshold:.1f} => TIẾN HÀNH CẮT NHÁNH!\n" + "—"*50)
            search_history_logs.append("\n".join(node_summary_chunk))
            return current_node.f_cost, None

        successors_list = current_node.expand_next_states(max_r, max_c)
        node_summary_chunk.append("KẾT QUẢ PHÁT TRIỂN (EXPAND):")
        valid_frontier_nodes = []
        
        for child in successors_list:
            child.node_title = auto_generate_node_label()
            child_sig = child.compute_state_signature()
            
            if child_sig not in global_reached_table or child.g_cost < global_reached_table.get(child_sig, float('inf')):
                node_summary_chunk.append(f"  [PUSH] Nút {child.node_title} | H.Động={child.step_action} | g={child.g_cost} | h={child.h_cost} | f={child.f_cost:.1f}")
                node_summary_chunk.append(stringify_board_layout(child.dirt_registry, max_r, max_c) + "\n")
                valid_frontier_nodes.append(child)
            else:
                node_summary_chunk.append(f"  [SKIP] Nút {child.node_title} | Trùng lặp trạng thái có chi phí g tốt hơn")
                node_summary_chunk.append(stringify_board_layout(child.dirt_registry, max_r, max_c) + "\n")

        node_summary_chunk.append("HÀNG ĐỢI CHỜ DUYỆT (FRONTIER):")
        for n in valid_frontier_nodes:
            p_label = n.ancestral_node.node_title if n.ancestral_node else "None"
            # SỬA LỖI LOG: Thay thế biến lỗi 'succ' bằng biến chạy chuẩn 'n' của vòng lặp
            node_summary_chunk.append(f"  -> {n.node_title} [Cha={p_label} | H.Động={n.step_action} | g={n.g_cost} | h={n.h_cost} | f={n.f_cost:.1f}]")
            node_summary_chunk.append(stringify_board_layout(n.dirt_registry, max_r, max_c) + "\n")

        node_summary_chunk.append(f"DANH SÁCH ĐÃ DUYỆT (REACHED): [{', '.join(traversed_path_nodes)}]")
        node_summary_chunk.append("—" * 50)
        search_history_logs.append("\n".join(node_summary_chunk))

        lowest_next_bound = float('inf')
        # Sắp xếp các nút con theo f(n) tăng dần để tối ưu hóa thứ tự đệ quy sâu
        for child in sorted(valid_frontier_nodes, key=lambda x: x.f_cost):
            search_status, goal_ref = recursive_depth_search(child, current_threshold)
            if search_status == "FOUND": 
                return "FOUND", goal_ref
            lowest_next_bound = min(lowest_next_bound, search_status)
            
        return lowest_next_bound, None

    while f_threshold < float('inf'):
        global_reached_table = {}
        traversed_path_nodes = []
        search_history_logs.append(f"\n⚡⚡⚡ KÍCH HOẠT VÒNG LẶP VỚI NGƯỠNG THRESHOLD i = {f_threshold:.1f} ⚡⚡⚡\n")
        execution_result, final_solution_node = recursive_depth_search(root_state, f_threshold)
        
        if execution_result == "FOUND":
            optimal_path = []
            while final_solution_node:
                optimal_path.insert(0, final_solution_node)
                final_solution_node = final_solution_node.parent_node
            return optimal_path, search_history_logs
        f_threshold = execution_result
        
    return None, search_history_logs

# =========================================================
# GIAO DIỆN ĐỒ HỌA MỚI (PHONG CÁCH NEON CYBERPUNK)
# =========================================================
def run(canvas_container_frame, text_log_widget, final_result_widget, app_title_tag=None):
    MAX_ROWS, MAX_COLS = 3, 3  
    start_coordinates = (0, 0) 
    dirty_cells_positions = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    canvas_container_frame.configure(bg="#1e1e24")
    for widget in canvas_container_frame.winfo_children():
        widget.destroy()

    text_log_widget.delete("1.0", tk.END)
    final_result_widget.delete("1.0", tk.END)

    # Label Tiêu đề giao diện
    header_title = tk.Label(canvas_container_frame, text="IDA* ALGORITHM - CYBER VACUUM SIMULATION", bg="#1e1e24", fg="#00ffcc", font=("Courier New", 15, "bold"), pady=8)
    header_title.pack(side="top", fill="x", pady=(5, 10))

    # Thanh chú thích màu sắc thiết kế phẳng phẳng
    legend_dock = tk.Frame(canvas_container_frame, bg="#2a2a35", pady=6)
    legend_dock.pack(side="top", fill="x", padx=35, pady=(0, 15))
    legend_alignment_box = tk.Frame(legend_dock, bg="#2a2a35")
    legend_alignment_box.pack(anchor="center")

    tk.Label(legend_alignment_box, bg="#3d3d4d", width=3, relief="flat").pack(side="left", padx=(10, 5))
    tk.Label(legend_alignment_box, text="[░] Ô SẠCH", bg="#2a2a35", fg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")

    tk.Label(legend_alignment_box, bg="#ff3366", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(legend_alignment_box, text="[█] Ô BẨN", bg="#2a2a35", fg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")

    tk.Label(legend_alignment_box, bg="#ff007f", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(legend_alignment_box, text="ROBOT PINK NEON", bg="#2a2a35", fg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")

    visual_grid_wrapper = tk.Frame(canvas_container_frame, bg="#1e1e24")
    visual_grid_wrapper.pack(expand=True)

    BLOCK_PIXELS = 98  # Thay đổi kích thước ô vuông thành 98
    grid_canvas = tk.Canvas(visual_grid_wrapper, width=MAX_COLS * BLOCK_PIXELS, height=MAX_ROWS * BLOCK_PIXELS, bg="#1e1e24", bd=0, highlightthickness=0)
    grid_canvas.pack(side="bottom")

    # Kích hoạt thực thi thuật toán IDA*
    solution_path, total_execution_logs = run_ida_star_search(start_coordinates, dirty_cells_positions, MAX_ROWS, MAX_COLS)

    for single_log in total_execution_logs:
        text_log_widget.insert(tk.END, single_log + "\n")
    text_log_widget.see("1.0")

    if not solution_path:
        final_result_widget.insert(tk.END, "LỖI: HỆ THỐNG KHÔNG XÁC ĐỊNH ĐƯỢC ĐƯỜNG ĐI CHUẨN!")
        return

    path_titles = [node.node_title for node in solution_path]
    coordinate_logs = [f"{node.agent_coords} ({node.step_action if node.step_action else 'Start'})" for node in solution_path]
    
    final_result_widget.insert(tk.END, "=== BÁO CÁO HÀNH TRÌNH TỐI ƯU IDA* ===\n\n")
    final_result_widget.insert(tk.END, f"Chuỗi tiến độ các nút duyệt:\n{' ➔ '.join(path_titles)}\n\n")
    final_result_widget.insert(tk.END, f"Chi tiết dịch chuyển máy:\n{' ➔ '.join(coordinate_logs)}")

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG NỐI
    # =========================================================
    def render_matrix_view(current_state, path_index):
        grid_canvas.delete("all")
        
        for r in range(MAX_ROWS):
            for c in range(MAX_COLS):
                x1, y1 = c * BLOCK_PIXELS, r * BLOCK_PIXELS
                x2, y2 = x1 + BLOCK_PIXELS, y1 + BLOCK_PIXELS
                
                is_cell_dirty = (r, c) in current_state.dirt_registry
                
                if (r, c) == current_state.agent_coords:
                    bg_color, glyph_color, border_color, border_width = "#ff007f", "#ffffff", "#ffffff", 2
                else:
                    bg_color, glyph_color, border_color, border_width = ("#ff3366", "#ffffff", "#ff3366", 1) if is_cell_dirty else ("#3d3d4d", "#a0a0b0", "#2a2a35", 1)

                grid_canvas.create_rectangle(x1, y1, x2, y2, fill=bg_color, outline=border_color, width=border_width)
                grid_canvas.create_text(x1 + BLOCK_PIXELS/2, y1 + BLOCK_PIXELS/2, text="[█]" if is_cell_dirty else "[░]", fill=glyph_color, font=("Courier New", 14, "bold"))
                
                if (r, c) == current_state.agent_coords:
                    grid_canvas.create_text(x1 + BLOCK_PIXELS/2, y1 + BLOCK_PIXELS/2 + 22, text="AGENT", fill="#ffffff", font=("Arial", 8, "bold"))

        # Vẽ đường kết nối hành trình màu xanh Cyan dạ quang nối tâm các ô lưới
        if path_index > 0:
            for i in range(path_index):
                src_r, src_c = solution_path[i].agent_coords
                dst_r, dst_c = solution_path[i+1].agent_coords
                
                if (src_r, src_c) != (dst_r, dst_c):
                    grid_canvas.create_line(
                        src_c * BLOCK_PIXELS + BLOCK_PIXELS / 2,
                        src_r * BLOCK_PIXELS + BLOCK_PIXELS / 2,
                        dst_c * BLOCK_PIXELS + BLOCK_PIXELS / 2,
                        dst_r * BLOCK_PIXELS + BLOCK_PIXELS / 2,
                        fill="#00ffcc", width=3, arrow=tk.LAST
                    )

    # =========================================================
    # VÒNG LẶP HÀM ĐIỀU KHIỂN ANIMATION DIỄN HOẠT
    # =========================================================
    def run_frame_animation(step_index):
        if step_index < len(solution_path):
            current_node = solution_path[step_index]
            render_matrix_view(current_node, step_index)
            canvas_container_frame.after(650, lambda: run_frame_animation(step_index + 1))

    run_frame_animation(0)

# =========================================================
# KHỞI CHẠY KHUNG ỨNG DỤNG ĐỘC LẬP TỰ ĐỘNG
# =========================================================
if __name__ == "__main__":
    root_window = tk.Tk()
    root_window.title("IDA* Pathfinding Sandbox")
    root_window.geometry("1120x680")
    root_window.configure(bg="#2a2a35")
    
    # Bảng Log bên trái
    left_dock_panel = tk.Frame(root_window, width=360, bg="#1e1e24", padx=10, pady=10)
    left_dock_panel.pack(side="left", fill="y")
    tk.Label(left_dock_panel, text="NHẬT KÝ KHẢO SÁT NÚT (IDA*)", fg="#00ffcc", bg="#1e1e24", font=("Courier New", 11, "bold")).pack()
    log_widget_box = tk.Text(left_dock_panel, width=43, bg="#15151a", fg="#ffffff", font=("Consolas", 9), bd=0)
    log_widget_box.pack(side="top", fill="both", expand=True, pady=10)

    # Bảng Kết quả bên phải
    right_dock_panel = tk.Frame(root_window, width=310, bg="#1e1e24", padx=10, pady=10)
    right_dock_panel.pack(side="right", fill="y")
    tk.Label(right_dock_panel, text="HÀNH TRÌNH TỐI ƯU CUỐI", fg="#00ffcc", bg="#1e1e24", font=("Courier New", 11, "bold")).pack()
    result_widget_box = tk.Text(right_dock_panel, width=36, bg="#15151a", fg="#ff007f", font=("Arial", 10), bd=0, wrap="word")
    result_widget_box.pack(side="top", fill="both", expand=True, pady=10)

    # Khung đồ họa hiển thị ở giữa
    center_canvas_panel = tk.Frame(root_window, bg="#1e1e24")
    center_canvas_panel.pack(side="left", fill="both", expand=True)

    # Kích hoạt hàm xử lý
    run(center_canvas_panel, log_widget_box, result_widget_box)
    root_window.mainloop()