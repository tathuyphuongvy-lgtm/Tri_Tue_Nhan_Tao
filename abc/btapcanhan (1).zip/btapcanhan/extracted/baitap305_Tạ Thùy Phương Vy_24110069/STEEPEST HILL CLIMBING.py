# Thùy Phương Vy - 24110069
# THUẬT TOÁN LEO ĐỒI DỐC NHẤT (STEEPEST HILL CLIMBING) - BÀI TOÁN MÁY HÚT BỤI
import tkinter as tk
import copy

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    """Lưu trữ trạng thái: Vị trí robot, danh sách ô bẩn, node cha, hành động, bước và heuristic."""
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos
        self.dirty_cells = set(dirty_cells)
        self.parent = parent
        self.action = action
        self.step = step
        self.h = len(self.dirty_cells) # Heuristic: Số ô rác còn lại
        self.name = name

    def is_goal(self):
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh ra các trạng thái kế tiếp chuẩn: Di chuyển (U,D,L,R) hoặc Hút (Suck)"""
        successors = []
        r, c = self.agent_pos
        
        # 1. Nếu vị trí hiện tại bẩn -> Sinh hành động HÚT BỤI (Suck) làm giảm h ngay lập tức
        if (r, c) in self.dirty_cells:
            new_dirty = copy.deepcopy(self.dirty_cells)
            new_dirty.remove((r, c))
            successors.append(VacuumState((r, c), new_dirty, self, "Suck", self.step + 1))
        
        # 2. Các hành động di chuyển (Chỉ đổi vị trí, không tự động sạch rác khi đi qua)
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)]
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                new_dirty = copy.deepcopy(self.dirty_cells)
                successors.append(VacuumState((nr, nc), new_dirty, self, action, self.step + 1))
                
        return successors

# =========================================================
# HÀM BỔ TRỢ IN MA TRẬN CHO LOG
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN LEO ĐỒI DỐC NHẤT (STEEPEST HILL CLIMBING)
# =========================================================
def steepest_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS):
    start_node = VacuumState(start_pos, initial_dirty, name="S")
    path = [start_node]
    steps_log = ["--- BẮT ĐẦU LEO ĐỒI DỐC NHẤT ---"]
    current = start_node
    node_counter = 0
    
    # Tránh đi lặp lại vô hạn giữa các ô có cùng lượng rác (độ dốc phẳng)
    visited_positions = {current.agent_pos} 

    while not current.is_goal():
        successors = current.generate_successors(ROWS, COLS)
        
        log_chunk = [
            f"[POP] NODE: {current.name} (Robot={current.agent_pos})",
            f"Parent: {current.parent.name if current.parent else 'None'} | Action: {current.action} | Step: {current.step} | h={current.h}",
            f"\n{get_matrix_str(current.dirty_cells, ROWS, COLS)}",
            "EXPAND & CHỌN NODE DỐC NHẤT:"
        ]

        best_successor = None
        min_h = float('inf') # Khởi tạo vô cùng để tìm láng giềng có h nhỏ nhất

        # Bước 1: Đánh nhãn và log tất cả các node con được sinh ra
        for succ in successors:
            node_counter += 1
            succ.name = chr(65 + (node_counter % 26)) + str(node_counter // 26 if node_counter // 26 > 0 else "")
            log_chunk.append(f"  [PUSH NODE {succ.name}] (Robot={succ.agent_pos}) | Action: {succ.action} | h={succ.h}")
        
        # Bước 2: Tìm ứng viên láng giềng tối ưu nhất (h nhỏ nhất)
        for succ in successors:
            if succ.h < min_h:
                # Tránh đi lùi về vị trí cũ đã qua khi độ dốc h bằng nhau (tránh loop)
                if succ.h == current.h and succ.agent_pos in visited_positions:
                    continue
                min_h = succ.h
                best_successor = succ
                
        # Bước 3: Di chuyển nếu node con tốt nhất cải thiện hơn hoặc bằng node hiện tại
        if best_successor and (best_successor.h <= current.h):
            log_chunk.append(f"-> CHỌN Node {best_successor.name} (Action: {best_successor.action}, h={best_successor.h} là tốt nhất)")
            steps_log.append("\n".join(log_chunk))
            
            current = best_successor
            path.append(current)
            visited_positions.add(current.agent_pos)
            
            # Nếu vừa thực hiện Hút bụi (Suck), reset danh sách đã đi để robot có thể quay lại ô cũ nếu cần thiết
            if current.action == "Suck":
                visited_positions = {current.agent_pos}
        else:
            log_chunk.append("-> KHÔNG CÓ HƯỚNG NÀO TỐT HƠN! BỊ KẸT TẠI CỰC TRỊ ĐỊA PHƯƠNG!")
            steps_log.append("\n".join(log_chunk))
            break
            
    return path, steps_log

# =========================================================
# HÀM RUN CHÍNH XỬ LÝ KHỞI TẠO GIAO DIỆN VÀ HOẠT HỌA
# =========================================================
def run(center_frame, log_text, result_text, name=None):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - Steepest Hill Climbing Search", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Thanh chú thích (Legend)
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    # Chạy thuật toán tìm đường
    path, steps_log = steepest_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS)
    
    # Ghi log chi tiết
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*40 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    # Ghi kết quả chung cuộc
    result_text.delete("1.0", tk.END)
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    path_names = [node.name for node in path]
    path_coords = [f"{node.agent_pos} ({node.action if node.action else 'Start'})" for node in path]
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Hành động chi tiết:\n{' -> '.join(path_coords)}\n\n")
    
    last_node = path[-1]
    if last_node.is_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!\nDo hàm h(n) bằng nhau ở các hướng đi tiếp theo.")
        
    def draw_state(state, step_index):
        canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirty_cells
                if (r, c) == state.agent_pos:
                    cell_bg, text_color, width_border = "#3399ff", "white", 3
                else:
                    cell_bg, text_color, width_border = ("#ff6666", "white", 1) if is_dirty else ("#e0e0e0", "#444444", 1)
                
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline="white", width=width_border)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2, text="1" if is_dirty else "0", fill=text_color, font=("Consolas", 20, "bold"))
                if (r, c) == state.agent_pos:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
        
        # Vẽ các mũi tên chỉ lộ trình đường đi của robot
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                if (r1, c1) != (r2, c2): 
                    canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def animate(step_index):
        if step_index < len(path):
            draw_state(path[step_index], step_index)
            center_frame.after(600, lambda: animate(step_index + 1))
            
    animate(0)

# =========================================================
# KHỞI TẠO KHUNG CỬA SỔ CHÍNH ĐỂ CHẠY ĐỘC LẬP
# =========================================================
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Vacuum World - Steepest Hill Climbing")
    root.geometry("1100://700") # Khung giao diện rộng rãi để chứa Log và đồ họa
    root.configure(bg="#f0f0f0")

    # Layout chia làm 3 cột: Trái (Log), Giữa (Đồ họa/Canvas), Phải (Kết quả kết luận)
    left_frame = tk.Frame(root, width=350, bg="#1e1e1e", padx=10, pady=10)
    left_frame.pack(side="left", fill="y")
    tk.Label(left_frame, text="THÔNG TIN LOG CHI TIẾT", fg="#ffffff", bg="#1e1e1e", font=("Segoe UI", 12, "bold")).pack()
    log_txt = tk.Text(left_frame, width=42, bg="#2d2d2d", fg="#ffffff", font=("Consolas", 9.5), bd=0)
    log_txt.pack(side="top", fill="both", expand=True, pady=10)

    right_frame = tk.Frame(root, width=300, bg="#2b2b2b", padx=10, pady=10)
    right_frame.pack(side="right", fill="y")
    tk.Label(right_frame, text="KẾT QUẢ ĐƯỜNG ĐI", fg="#ffffff", bg="#2b2b2b", font=("Segoe UI", 12, "bold")).pack()
    result_txt = tk.Text(right_frame, width=35, bg="#3c3c3c", fg="#00ffcc", font=("Segoe UI", 10), bd=0, wrap="word")
    result_txt.pack(side="top", fill="both", expand=True, pady=10)

    middle_frame = tk.Frame(root, bg="#ffffff")
    middle_frame.pack(side="left", fill="both", expand=True)

    # Chạy hàm điều hướng chính thức
    run(middle_frame, log_txt, result_txt)

    root.mainloop()