# Tạ Thùy Phương Vy (24110069)
# Giải thuật: LEO ĐỒI NGẪU NHIÊN (STOCHASTIC HILL CLIMBING) - ĐÃ CHUẨN HÓA & TÁI CẤU TRÚC
import tkinter as tk
import copy
import random

# =========================================================
# KHÔNG GIAN TRẠNG THÁI TOÁN HỌC CỦA THIẾT BỊ
# =========================================================
class CleanerStateAgent:
    """Quản lý dữ liệu tọa độ, tập hợp rác và tính toán Heuristic h(n) cho robot."""
    def __init__(self, current_pos, trash_map, parent_node=None, applied_action=None, cost_step=0, node_id="S"):
        self.grid_position = current_pos
        self.trash_bag = set(trash_map)
        self.parent_node = parent_node
        self.applied_action = applied_action
        self.cost_step = cost_step
        self.h_score = len(self.trash_bag)  # Heuristic: số lượng điểm bẩn còn lại
        self.node_id = node_id

    def target_achieved(self):
        return len(self.trash_bag) == 0

    def generate_random_neighbors(self, total_r, total_c):
        """Sinh tập hợp các trạng thái lân cận hợp lệ: Hút tại chỗ hoặc dịch chuyển."""
        possible_nodes = []
        r, c = self.grid_position
        
        # Hành động ưu tiên 1: Thu gom rác (Suck) ngay dưới chân
        if (r, c) in self.trash_bag:
            modified_bag = copy.deepcopy(self.trash_bag)
            modified_bag.remove((r, c))
            possible_nodes.append(CleanerStateAgent((r, c), modified_bag, self, "Suck", self.cost_step + 1))
        
        # Hành động ưu tiên 2: Di chuyển đổi tọa độ (Thứ tự đổi sang: D, U, R, L)
        move_directions = [("D", r+1, c), ("U", r-1, c), ("R", r, c+1), ("L", r, c-1)]
        for act_name, next_r, next_c in move_directions:
            if 0 <= next_r < total_r and 0 <= next_c < total_c:
                cloned_bag = copy.deepcopy(self.trash_bag)
                possible_nodes.append(CleanerStateAgent((next_r, next_c), cloned_bag, self, act_name, self.cost_step + 1))
                
        return possible_nodes

# =========================================================
# CHUYỂN ĐỔI MA TRẬN SANG CHUỖI ĐỒ HỌA
# =========================================================
def convert_grid_to_str(trash_bag, total_r=3, total_c=3):
    matrix_lines = []
    for r in range(total_r):
        row_cells = ["[*]" if (r, c) in trash_bag else "[.]" for c in range(total_c)]
        matrix_lines.append("  ".join(row_cells))
    return "\n".join(matrix_lines)

# =========================================================
# GIẢI THUẬT LEO ĐỒI NGẪU NHIÊN (STOCHASTIC HILL CLIMBING)
# =========================================================
def execute_stochastic_hill_climbing(start_coord, initial_trash_set, max_rows, max_cols):
    root_state = CleanerStateAgent(start_coord, initial_trash_set, node_id="S")
    path_history = [root_state]
    execution_logs = ["=== KHỞI ĐỘNG GIẢI THUẬT LEO ĐỒI NGẪU NHIÊN ==="]
    current_state = root_state
    generated_counter = 0

    # Bộ nhớ ghi nhận để loại trừ các chu trình lặp vô hạn khi đi ngang cao nguyên
    state_history_registry = set()
    state_history_registry.add((current_state.grid_position, tuple(sorted(current_state.trash_bag))))

    while not current_state.target_achieved():
        neighbors = current_state.generate_random_neighbors(max_rows, max_cols)
        
        chunk_summary = [
            f"[POP] NÚT HIỆN TẠI: {current_state.node_id} (Tọa độ={current_state.grid_position})",
            f"Nút gốc: {current_state.parent_node.node_id if current_state.parent_node else 'None'} | Hành động gần nhất: {current_state.applied_action} | h={current_state.h_score}",
            f"\n{convert_grid_to_str(current_state.trash_bag, max_rows, max_cols)}",
            "DANH SÁCH CÁC CON ĐỦ ĐIỀU KIỆN (CHỌN LỌC NGẪU NHIÊN):"
        ]
        
        valid_better_pool = []
        
        for child_node in neighbors:
            generated_counter += 1
            child_node.node_id = f"M{generated_counter}"
            
            state_signature = (child_node.grid_position, tuple(sorted(child_node.trash_bag)))
            
            # Điều kiện Stochastic Hill Climbing: Tìm các trạng thái chưa đi và có h tốt hơn hoặc bằng cha
            if state_signature not in state_history_registry and (child_node.h_score <= current_state.h_score):
                chunk_summary.append(f"  [HỢP LỆ] {child_node.node_id} (Vị trí={child_node.grid_position} | Hành động={child_node.applied_action} | h={child_node.h_score})")
                valid_better_pool.append((child_node, state_signature))
            else:
                chunk_summary.append(f"  [LOẠI] {child_node.node_id} (Vị trí={child_node.grid_position} | h={child_node.h_score} >= h_cha)")

        # Cơ chế ngẫu nhiên chọn phần tử trong Pool ứng viên đạt yêu cầu
        if valid_better_pool:
            chosen_candidate, chosen_signature = random.choice(valid_better_pool)
            chunk_summary.append(f"\n=> XÁC XUẤT NGẪU NHIÊN: Chọn nút {chosen_candidate.node_id} (Hành động: {chosen_candidate.applied_action}) trong {len(valid_better_pool)} hướng đi tốt.")
            state_history_registry.add(chosen_signature)
            current_state = chosen_candidate
            path_history.append(current_state)
        else:
            chunk_summary.append("\n=> KẾT THÚC: Không tìm thấy hướng đi ngẫu nhiên nào tốt hơn! Kẹt cực trị.")
            execution_logs.append("\n".join(chunk_summary))
            break
            
        execution_logs.append("\n".join(chunk_summary))
            
    return path_history, execution_logs

# =========================================================
# GIAO DIỆN ĐỒ HỌA MỚI (PHONG CÁCH DARK MINIMALIST)
# =========================================================
def run(center_canvas_frame, text_log_widget, txt_result_widget, app_name=None):
    GRID_R, GRID_C = 3, 3  
    initial_position = (0, 0) 
    trash_coords_list = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_canvas_frame.configure(bg="#1e272e")
    for widget in center_canvas_frame.winfo_children():
        widget.destroy()

    # Thanh Header phong cách tối giản
    ui_title = tk.Label(center_canvas_frame, text="STOCHASTIC VACUUM WORLD - LEO ĐỒI NGẪU NHIÊN", bg="#1e272e", fg="#ffdd59", font=("Segoe UI", 16, "bold"), pady=10)
    ui_title.pack(side="top", fill="x", pady=(5, 10))

    # Thanh chú giải màu sắc mới dạng bo góc phẳng
    legend_wrapper = tk.Frame(center_canvas_frame, bg="#2f3640", pady=5)
    legend_wrapper.pack(side="top", fill="x", padx=25, pady=(0, 15))
    inner_bar = tk.Frame(legend_wrapper, bg="#2f3640")
    inner_bar.pack(anchor="center")
    
    tk.Label(inner_bar, bg="#718093", width=3, relief="flat").pack(side="left", padx=(10, 5))
    tk.Label(inner_bar, text="[.] Sạch", bg="#2f3640", fg="#f5f6fa", font=("Segoe UI", 9, "bold")).pack(side="left")
    
    tk.Label(inner_bar, bg="#ff793f", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(inner_bar, text="[*] Vết Bẩn", bg="#2f3640", fg="#f5f6fa", font=("Segoe UI", 9, "bold")).pack(side="left")
    
    tk.Label(inner_bar, bg="#ffdd59", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(inner_bar, text="ROBOT VÀNG NEON", bg="#2f3640", fg="#f5f6fa", font=("Segoe UI", 9, "bold")).pack(side="left")

    canvas_holder = tk.Frame(center_canvas_frame, bg="#1e272e")
    canvas_holder.pack(expand=True)
    BOX_SIZE = 96  # Đổi size ô sang 96
    matrix_canvas = tk.Canvas(canvas_holder, width=GRID_C * BOX_SIZE, height=GRID_R * BOX_SIZE, bg="#2f3640", bd=0, highlightthickness=0)
    matrix_canvas.pack(side="bottom")

    # Gọi hàm giải thuật
    solver_path, logging_steps = execute_stochastic_hill_climbing(initial_position, trash_coords_list, GRID_R, GRID_C)
    
    # Đổ dữ liệu Log
    text_log_widget.delete("1.0", tk.END)
    for block in logging_steps:
        text_log_widget.insert(tk.END, block + "\n" + "•"*30 + "\n")
    text_log_widget.see(tk.END) 
    text_log_widget.update_idletasks()

    # Đổ dữ liệu kết quả
    txt_result_widget.delete("1.0", tk.END)
    if not solver_path:
        txt_result_widget.insert(tk.END, "Không tìm thấy lời giải thành công!")
        return

    node_sequence = [nd.node_id for nd in solver_path]
    movement_sequence = [f"{nd.grid_position} ({nd.applied_action if nd.applied_action else 'Bắt đầu'})" for nd in solver_path]
    
    txt_result_widget.insert(tk.END, "=== KẾT QUẢ ĐIỀU HƯỚNG MÁY ===\n\n")
    txt_result_widget.insert(txt_result_widget.end, f"Chuỗi tiến trình nút:\n{' -> '.join(node_sequence)}\n\n")
    txt_result_widget.insert(txt_result_widget.end, f"Tọa độ & Hành động:\n{' -> '.join(movement_sequence)}\n\n")
    
    final_node = solver_path[-1]
    if final_node.target_achieved():
        txt_result_widget.insert(tk.END, "KẾT LUẬN CHUNG: THÀNH CÔNG RỰC RỠ!")
    else:
        txt_result_widget.insert(tk.END, "KẾT LUẬN CHUNG: THẤT BẠI - Kẹt tại cao nguyên bằng phẳng!")
        
    def render_current_frame(state_node, path_index):
        matrix_canvas.delete("all")
        for r in range(GRID_R):
            for c in range(GRID_C):
                x1, y1 = c * BOX_SIZE, r * BOX_SIZE
                x2, y2 = x1 + BOX_SIZE, y1 + BOX_SIZE
                cell_has_trash = (r, c) in state_node.trash_bag
                
                if (r, c) == state_node.grid_position:
                    color_fill, font_color = "#ffdd59", "#1e272e" # Màu vàng neon khi robot đứng
                else:
                    color_fill, font_color = ("#ff793f", "#ffffff") if cell_has_trash else ("#718093", "#f5f6fa")
                
                matrix_canvas.create_rectangle(x1, y1, x2, y2, fill=color_fill, outline="#57606f", width=1)
                matrix_canvas.create_text(x1 + BOX_SIZE/2, y1 + BOX_SIZE/2, text="[*]" if cell_has_trash else "[.]", fill=font_color, font=("Consolas", 15, "bold"))
                
                if (r, c) == state_node.grid_position:
                    matrix_canvas.create_text(x1 + BOX_SIZE/2, y1 + BOX_SIZE/2 + 22, text="AGENT", fill="#1e272e", font=("Segoe UI", 8, "bold"))
        
        # Vẽ các đường lộ trình chỉ hướng mũi tên cam tươi nối tâm ô lưới
        if path_index > 0:
            for i in range(path_index):
                fr_r, fr_c = solver_path[i].grid_position
                to_r, to_c = solver_path[i+1].grid_position
                if (fr_r, fr_c) != (to_r, to_c):
                    matrix_canvas.create_line(fr_c*BOX_SIZE + BOX_SIZE/2, fr_r*BOX_SIZE + BOX_SIZE/2, to_c*BOX_SIZE + BOX_SIZE/2, to_r*BOX_SIZE + BOX_SIZE/2, fill="#ffdd59", width=3, arrow=tk.LAST)

    def play_frame_animation(index):
        if index < len(solver_path):
            render_current_frame(solver_path[index], index)
            center_canvas_frame.after(650, lambda: play_frame_animation(index + 1))
            
    play_frame_animation(0)

# =========================================================
# KHUNG KHỞI CHẠY HỆ THỐNG ĐỘC LẬP TỰ ĐỘNG
# =========================================================
if __name__ == "__main__":
    main_window = tk.Tk()
    main_window.title("Stochastic Hill Climbing Sandbox")
    main_window.geometry("1120x680")
    main_window.configure(bg="#2f3640")
    
    # Bảng Log bên trái
    left_dock = tk.Frame(main_window, width=360, bg="#1e272e", padx=10, pady=10)
    left_dock.pack(side="left", fill="y")
    tk.Label(left_dock, text="NHẬT KÝ KHẢO SÁT NGẪU NHIÊN", fg="#f5f6fa", bg="#1e272e", font=("Segoe UI", 11, "bold")).pack()
    log_area_box = tk.Text(left_dock, width=43, bg="#2f3640", fg="#f5f6fa", font=("Consolas", 9), bd=0)
    log_area_box.pack(side="top", fill="both", expand=True, pady=10)

    # Bảng Kết quả bên phải
    right_dock = tk.Frame(main_window, width=310, bg="#1e272e", padx=10, pady=10)
    right_dock.pack(side="right", fill="y")
    tk.Label(right_dock, text="TÓM TẮT ĐƯỜNG ĐI CHỌN LỌC", fg="#f5f6fa", bg="#1e272e", font=("Segoe UI", 11, "bold")).pack()
    res_area_box = tk.Text(right_dock, width=36, bg="#2f3640", fg="#ffdd59", font=("Segoe UI", 10), bd=0, wrap="word")
    res_area_box.pack(side="top", fill="both", expand=True, pady=10)

    # Khung đồ họa ở giữa
    center_dock = tk.Frame(main_window, bg="#1e272e")
    center_dock.pack(side="left", fill="both", expand=True)

    # Chạy ứng dụng công cụ
    run(center_dock, log_area_box, res_area_box)
    main_window.mainloop()