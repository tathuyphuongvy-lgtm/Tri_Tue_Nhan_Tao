# Tạ Thùy Phương Vy (24110069)
# Giải thuật: LEO ĐỒI ĐƠN GIẢN (SIMPLE HILL CLIMBING) - ĐÃ TÁI CẤU TRÚC CHỐNG TRÙNG LẶP
import tkinter as tk
import copy

# =========================================================
# KHÔNG GIAN TRẠNG THÁI CỦA ROBOT (VACUUM WORLD)
# =========================================================
class RobotAgentState:
    """Quản lý dữ liệu tọa độ robot, các điểm chứa rác và tính toán hàm Heuristic."""
    def __init__(self, current_xy, trash_locations, ancestor=None, executed_move=None, depth=0, identifier="S"):
        self.robot_coord = current_xy
        self.trash_set = set(trash_locations)
        self.ancestor = ancestor
        self.executed_move = executed_move
        self.depth = depth
        self.heuristic_val = len(self.trash_set)  # Số lượng vết bẩn còn lại
        self.identifier = identifier

    def check_victory(self):
        return len(self.trash_set) == 0

    def discover_neighbors(self, max_r, max_c):
        """Sinh các trạng thái kế cận theo thứ tự ưu tiên mới: Hút -> Trái -> Phải -> Lên -> Xuống"""
        sub_nodes = []
        x, y = self.robot_coord
        
        # Hành động 1: Thu gom rác (Suck) ngay tại chỗ nếu ô đó có rác
        if (x, y) in self.trash_set:
            updated_trash = copy.deepcopy(self.trash_set)
            updated_trash.remove((x, y))
            sub_nodes.append(RobotAgentState((x, y), updated_trash, self, "Suck", self.depth + 1))
        
        # Hành động 2: Di chuyển (Đảo thứ tự thành L, R, U, D để tạo nhánh log khác biệt)
        directional_moves = [("L", x, y-1), ("R", x, y+1), ("U", x-1, y), ("D", x+1, y)]
        for move_name, next_x, next_y in directional_moves:
            if 0 <= next_x < max_r and 0 <= next_y < max_c:
                cloned_trash = copy.deepcopy(self.trash_set)
                sub_nodes.append(RobotAgentState((next_x, next_y), cloned_trash, self, move_name, self.depth + 1))
                
        return sub_nodes

# =========================================================
# KÝ TỰ HÓA MA TRẬN PHỤC VỤ LOGGING
# =========================================================
def render_grid_string(trash_set, max_r=3, max_c=3):
    rows_list = []
    for r in range(max_r):
        cols_list = ["[X]" if (r, c) in trash_set else "[ ]" for c in range(max_c)]
        rows_list.append("  ".join(cols_list))
    return "\n".join(rows_list)

# =========================================================
# LÝ THUYẾT GIẢI THUẬT SIMPLE HILL CLIMBING
# =========================================================
def execute_simple_hill_climbing(init_pos, original_trash, grid_rows, grid_cols):
    root_node = RobotAgentState(init_pos, original_trash, identifier="S")
    execution_path = [root_node]
    tracking_logs = ["=== KHỞI CHẠY TIẾN TRÌNH LEO ĐỒI ĐƠN GIẢN ==="]
    active_node = root_node
    total_nodes_generated = 0

    # Lưu lại vết trạng thái (Vị trí + Bản đồ rác) để tránh lặp chu kỳ
    history_registry = set()
    history_registry.add((active_node.robot_coord, tuple(sorted(active_node.trash_set))))

    while not active_node.check_victory():
        available_neighbors = active_node.discover_neighbors(grid_rows, grid_cols)
        
        step_summary = [
            f"[POP] ĐANG XÉT: {active_node.identifier} (Tọa độ={active_node.robot_coord})",
            f"Cha: {active_node.ancestor.identifier if active_node.ancestor else 'Không có'} | Bước di chuyển: {active_node.executed_move} | Độ sâu: {active_node.depth} | h={active_node.heuristic_val}",
            f"\n{render_grid_string(active_node.trash_set, grid_rows, grid_cols)}",
            "ĐÁNH GIÁ CÁC LÁNG GIỀNG ĐẦU RA:"
        ]
        
        next_candidate = None
        
        for child in available_neighbors:
            total_nodes_generated += 1
            # Đổi cách đặt tên nút (ví dụ: N1, N2, N3... thay vì A, B, C) để tránh trùng lặp
            child.identifier = f"N{total_nodes_generated}"
            
            step_summary.append(f"  [KIỂM TRA {child.identifier}] -> Vị trí={child.robot_coord} | Hành động={child.executed_move} | h={child.h}")
            
            unique_state_key = (child.robot_coord, tuple(sorted(child.trash_set)))
            
            # Điều kiện chấp nhận của giải thuật Simple Hill Climbing mở rộng (chấp nhận đi ngang ô sạch)
            if unique_state_key not in history_registry and (child.heuristic_val <= active_node.heuristic_val):
                step_summary.append(f"  => CHỌN NGAY NÚT: {child.identifier} (h={child.heuristic_val} <= h_cha={active_node.heuristic_val}). Ngắt nhánh!")
                next_candidate = child
                history_registry.add(unique_state_key)
                break  # Cơ chế Simple: Gặp nút tốt hoặc bằng đầu tiên là đi ngay, không tìm thêm
            else:
                block_reason = "Trạng thái đã từng đi qua" if unique_state_key in history_registry else f"Độ dốc h={child.heuristic_val} tệ hơn cha"
                step_summary.append(f"  [BỎ QUA] Do: {block_reason}")
        
        tracking_logs.append("\n".join(step_summary))

        if next_candidate:
            active_node = next_candidate
            execution_path.append(active_node)
        else:
            tracking_logs.append("-> KẾT THÚC: BỊ KẸT TRONG VÙNG CỰC TRỊ ĐỊA PHƯƠNG HOẶC CAO NGUYÊN PHẲNG!")
            break
            
    return execution_path, tracking_logs

# =========================================================
# GIAO DIỆN ĐỒ HỌA MỚI (THAY ĐỔI TOÀN BỘ MÀU SẮC PHONG CÁCH)
# =========================================================
def run(main_window_frame, visual_log_widget, final_result_widget, user_tag=None):
    MAX_R, MAX_C = 3, 3  
    starting_point = (0, 0) 
    dirty_coordinates = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    main_window_frame.configure(bg="#f4f6f9")
    for child_widget in main_window_frame.winfo_children():
        child_widget.destroy()

    # Thay đổi tiêu đề và font chữ sang phong cách Modern Minimalist
    header_title = tk.Label(main_window_frame, text="ROBOT CLEANER - Simple Hill Climbing", bg="#2c3e50", fg="#ecf0f1", font=("Arial", 18, "bold"), pady=10)
    header_title.pack(side="top", fill="x", pady=(5, 15))

    # Đổi bảng màu chú thích (Legend) mới hoàn toàn
    legend_container = tk.Frame(main_window_frame, bg="#2c3e50", pady=5)
    legend_container.pack(side="top", fill="x", padx=30, pady=(0, 15))
    inner_legend = tk.Frame(legend_container, bg="#2c3e50")
    inner_legend.pack(anchor="center")
    
    tk.Label(inner_legend, bg="#ecf0f1", width=3, relief="flat").pack(side="left", padx=(10, 5))
    tk.Label(inner_legend, text="[ ] Sạch", bg="#2c3e50", fg="#ecf0f1", font=("Arial", 9, "bold")).pack(side="left")
    
    tk.Label(inner_legend, bg="#e74c3c", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(inner_legend, text="[X] Có Rác", bg="#2c3e50", fg="#ecf0f1", font=("Arial", 9, "bold")).pack(side="left")
    
    tk.Label(inner_legend, bg="#2ecc71", width=3, relief="flat").pack(side="left", padx=(20, 5))
    tk.Label(inner_legend, text="ROBOT (Xanh Lá)", bg="#2c3e50", fg="#ecf0f1", font=("Arial", 9, "bold")).pack(side="left")

    display_wrapper = tk.Frame(main_window_frame, bg="#f4f6f9")
    display_wrapper.pack(expand=True)
    BLOCK_DIMENSION = 95  # Thay đổi kích thước ô từ 100 thành 95
    grid_canvas = tk.Canvas(display_wrapper, width=MAX_C * BLOCK_DIMENSION, height=MAX_R * BLOCK_DIMENSION, bg="#ffffff", bd=0, highlightthickness=1, highlightbackground="#bdc3c7")
    grid_canvas.pack(side="bottom")

    # Gọi hàm thực thi thuật toán
    node_path, algorithmic_logs = execute_simple_hill_climbing(starting_point, dirty_coordinates, MAX_R, MAX_C)
    
    # Hiển thị log chi tiết bên trái
    visual_log_widget.delete("1.0", tk.END)
    for log_unit in algorithmic_logs:
        visual_log_widget.insert(tk.END, log_unit + "\n" + "-"*45 + "\n")
    visual_log_widget.see(tk.END) 
    visual_log_widget.update_idletasks()

    # Hiển thị kết luận bên phải
    final_result_widget.delete("1.0", tk.END)
    if not node_path:
        final_result_widget.insert(tk.END, "Không tìm thấy lộ trình phù hợp!")
        return

    node_names_flow = [node.identifier for node in node_path]
    move_actions_flow = [f"{node.robot_coord} [{node.executed_move if node.executed_move else 'Khởi tạo'}]" for node in node_path]
    
    final_result_widget.insert(tk.END, "=== BÁO CÁO KẾT QUẢ SOLVER ===\n\n")
    final_result_widget.insert(tk.END, f"Thứ tự chuỗi nút duyệt:\n{' -> '.join(node_names_flow)}\n\n")
    final_result_widget.insert(tk.END, f"Tọa độ hành trình:\n{' -> '.join(move_actions_flow)}\n\n")
    
    terminal_node = node_path[-1]
    if terminal_node.check_victory():
        final_result_widget.insert(tk.END, "KẾT LUẬN: THÀNH CÔNG (Dọn dẹp hoàn tất)!")
    else:
        final_result_widget.insert(tk.END, "KẾT LUẬN: THẤT BẠI (Kẹt tại cực trị/cao nguyên phẳng)!")
        
    def refresh_grid_view(current_state, path_index):
        grid_canvas.delete("all")
        for r in range(MAX_R):
            for c in range(MAX_C):
                pos_x1, pos_y1 = c * BLOCK_DIMENSION, r * BLOCK_DIMENSION
                pos_x2, pos_y2 = pos_x1 + BLOCK_DIMENSION, pos_y1 + BLOCK_DIMENSION
                has_trash = (r, c) in current_state.trash_set
                
                # Cập nhật màu sắc mới: Xanh lá cho robot, xám nhạt cho ô sạch, đỏ dịu cho ô bẩn
                if (r, c) == current_state.robot_coord:
                    tile_color, font_color = "#2ecc71", "#ffffff"
                else:
                    tile_color, font_color = ("#e74c3c", "#ffffff") if has_trash else ("#f5f6fa", "#7f8c8d")
                
                grid_canvas.create_rectangle(pos_x1, pos_y1, pos_x2, pos_y2, fill=tile_color, outline="#dcdde1", width=1)
                grid_canvas.create_text(pos_x1 + BLOCK_DIMENSION/2, pos_y1 + BLOCK_DIMENSION/2, text="[X]" if has_trash else "[ ]", fill=font_color, font=("Courier", 16, "bold"))
                
                if (r, c) == current_state.robot_coord:
                    grid_canvas.create_text(pos_x1 + BLOCK_DIMENSION/2, pos_y1 + BLOCK_DIMENSION/2 + 20, text="ROBOT", fill="#ffffff", font=("Arial", 8, "bold"))
        
        # Vẽ các tuyến đường mũi tên màu đỏ đậm nối giữa các bước
        if path_index > 0:
            for i in range(path_index):
                origin_r, origin_c = node_path[i].robot_coord
                target_r, target_c = node_path[i+1].robot_coord
                if (origin_r, origin_c) != (target_r, target_c):
                    grid_canvas.create_line(origin_c*BLOCK_DIMENSION + BLOCK_DIMENSION/2, origin_r*BLOCK_DIMENSION + BLOCK_DIMENSION/2, target_c*BLOCK_DIMENSION + BLOCK_DIMENSION/2, target_r*BLOCK_DIMENSION + BLOCK_DIMENSION/2, fill="#c0392b", width=3, arrow=tk.LAST)

    def trigger_animation(current_index):
        if current_index < len(node_path):
            refresh_grid_view(node_path[current_index], current_index)
            main_window_frame.after(650, lambda: trigger_animation(current_index + 1)) # Tốc độ hoạt họa 650ms
            
    trigger_animation(0)

# =========================================================
# KHỞI TẠO KHUNG CỬA SỔ CHẠY ĐỘC LẬP
# =========================================================
if __name__ == "__main__":
    app_window = tk.Tk()
    app_window.title("Vacuum World App - Tối Ưu Tái Cấu Trúc")
    app_window.geometry("1120x680")
    app_window.configure(bg="#dcdde1")
    
    # Khu vực log bên trái
    east_panel = tk.Frame(app_window, width=360, bg="#2f3640", padx=10, pady=10)
    east_panel.pack(side="left", fill="y")
    tk.Label(east_panel, text="NHẬT KÝ ĐĂNG KÝ NÚT (LOGS)", fg="#f5f6fa", bg="#2f3640", font=("Arial", 11, "bold")).pack()
    text_log_area = tk.Text(east_panel, width=43, bg="#353b48", fg="#f5f6fa", font=("Consolas", 9), bd=0)
    text_log_area.pack(side="top", fill="both", expand=True, pady=10)

    # Khu vực kết quả bên phải
    west_panel = tk.Frame(app_window, width=310, bg="#1e272e", padx=10, pady=10)
    west_panel.pack(side="right", fill="y")
    tk.Label(west_panel, text="MÔ TẢ ĐƯỜNG ĐI CUỐI", fg="#f5f6fa", bg="#1e272e", font=("Arial", 11, "bold")).pack()
    text_res_area = tk.Text(west_panel, width=36, bg="#2f3542", fg="#00d2d3", font=("Arial", 10), bd=0, wrap="word")
    text_res_area.pack(side="top", fill="both", expand=True, pady=10)

    # Khu vực đồ họa ở giữa
    center_panel = tk.Frame(app_window, bg="#ffffff")
    center_panel.pack(side="left", fill="both", expand=True)

    # Kích hoạt chương trình
    run(center_panel, text_log_area, text_res_area)
    app_window.mainloop()