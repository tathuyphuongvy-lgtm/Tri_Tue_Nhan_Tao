# MSSV: 24110069
# Họ và tên: Tạ Thùy Phương Vy
#https://github.com/tathuyphuongvy-lgtm
# ĐỀ TÀI: GIẢI QUYẾT BÀI TOÁN TÔ MÀU BẢN ĐỒ MIỀN NAM BẰNG CSP & BACKTRACKING

import tkinter as tk
from tkinter import scrolledtext

# =========================================================
# 1. LỚP THUẬT TOÁN CSP (BACKTRACKING CHUẨN)
# =========================================================
class BoGiaiQuyetMienNamCSP:
    def __init__(self, danh_sach_tinh, do_thi_ranh_gioi, bang_mau):
        self.cac_tinh = danh_sach_tinh
        self.ranh_gioi = do_thi_ranh_gioi
        self.bang_mau = bang_mau
        self.phuong_an_mau = {}

    def _hop_le_mau_sac(self, tinh_xet, mau_thu):
        """ Đảm bảo tỉnh đang xét không bị trùng màu với các tỉnh hàng xóm đã tô """
        for hang_xom in self.ranh_gioi.get(tinh_xet, []):
            if hang_xom in self.phuong_an_mau and self.phuong_an_mau[hang_xom] == mau_thu:
                return False
        return True

    def bat_dau_giai(self, ham_callback_log=None):
        return self._thuc_thi_quay_lui(ham_callback_log)

    def _thuc_thi_quay_lui(self, ham_callback_log):
        # Điều kiện dừng: Tất cả các tỉnh đều đã được điền màu thành công
        if len(self.phuong_an_mau) == len(self.cac_tinh):
            return self.phuong_an_mau

        # Lấy địa phương chưa được phân bổ màu đầu tiên
        tinh_chua_to = [t for t in self.cac_tinh if t not in self.phuong_an_mau]
        tinh_chon = tinh_chua_to[0]

        for mau in self.bang_mau:
            if ham_callback_log:
                ham_callback_log(tinh_chon, mau, "UONG_THU")

            if self._hop_le_mau_sac(tinh_chon, mau):
                self.phuong_an_mau[tinh_chon] = mau
                if ham_callback_log:
                    ham_callback_log(tinh_chon, mau, "CHAP_THUAN")

                ket_qua_nhanh = self._thuc_thi_quay_lui(ham_callback_log)
                if ket_qua_nhanh is not None:
                    return ket_qua_nhanh

                # Thu hồi màu nếu nhánh tìm kiếm phía sau đi vào ngõ cụt
                del self.phuong_an_mau[tinh_chon]
                if ham_callback_log:
                    ham_callback_log(tinh_chon, mau, "TRA_LAI")
            else:
                # Xác định danh sách tỉnh giáp ranh đang bị xung đột màu
                tinh_xung_dot = [
                    hx for hx in self.ranh_gioi.get(tinh_chon, [])
                    if hx in self.phuong_an_mau and self.phuong_an_mau[hx] == mau
                ]
                if ham_callback_log:
                    ham_callback_log(tinh_chon, mau, "TRUNG_MAU", tinh_xung_dot)
                        
        return None

# =========================================================
# 2. TOẠ ĐỘ VÀ ĐỊA LÝ KHÔNG GIAN CÁC TỈNH MIỀN NAM (CHUẨN 100%)
# =========================================================
TOA_DO_TINH_THANH = {
    "TP. Hồ Chí Minh": [280, 360, 380, 350, 340, 440, 350, 480, 260, 440], 
    "Bình Dương":      [240, 220, 380, 210, 380, 350, 280, 360],          
    "Đồng Nai":        [380, 210, 520, 230, 480, 420, 340, 440, 380, 350], 
    "Long An":         [120, 340, 280, 360, 260, 440, 160, 480],          
    "Bà Rịa Vũng Tàu": [340, 440, 480, 420, 540, 530, 350, 480]           
}

TOA_DO_NHAN_TINH = {
    "TP. Hồ Chí Minh": (310, 410, "SG"), 
    "Bình Dương":      (310, 270, "BD"),
    "Đồng Nai":        (440, 310, "ĐN"),
    "Long An":         (190, 400, "LA"),
    "Bà Rịa Vũng Tàu": (440, 470, "VT")
}

BANG_GIAP_RANH = {
    "TP. Hồ Chí Minh": ["Bình Dương", "Đồng Nai", "Long An", "Bà Rịa Vũng Tàu"],
    "Bình Dương":      ["TP. Hồ Chí Minh", "Đồng Nai"],
    "Đồng Nai":        ["Bình Dương", "TP. Hồ Chí Minh", "Bà Rịa Vũng Tàu"],
    "Long An":         ["TP. Hồ Chí Minh"],
    "Bà Rịa Vũng Tàu": ["TP. Hồ Chí Minh", "Đồng Nai"]
}

HE_HEX_MAU_SAC = {"Đỏ": "#ff6666", "Xanh lá": "#4bd24b", "Xanh dương": "#4696ff", "Vàng": "#ffeb46"}
TAP_MAU_DUNGS = list(HE_HEX_MAU_SAC.keys())

# =========================================================
# 3. GIAO DIỆN ĐỒ HỌA ỨNG DỤNG (GUI)
# =========================================================
def main():
    giao_dien_chinh = tk.Tk()
    giao_dien_chinh.title("BÀI TOÁN TÔ MÀU BẢN ĐỒ ĐÔNG NAM BỘ - CSP BACKTRACKING")
    giao_dien_chinh.geometry("1450x950")
    giao_dien_chinh.configure(bg="#1e1e1e")

    # Thuật toán tự động tính toán để đưa mô hình bản đồ vào chính giữa khung vẽ
    tap_x, tap_y = [], []
    for toa_do_tinh in TOA_DO_TINH_THANH.values():
        for i in range(len(toa_do_tinh)):
            if i % 2 == 0: tap_x.append(toa_do_tinh[i])
            else: tap_y.append(toa_do_tinh[i])
            
    can_chinh_x = 400 - (sum(tap_x) / len(tap_x))
    can_chinh_y = 300 - (sum(tap_y) / len(tap_y))

    # Xây dựng các khung phân chia bố cục màn hình
    khung_tren = tk.Frame(giao_dien_chinh, bg="#1e1e1e")
    khung_tren.pack(side="top", fill="both", expand=True)

    khung_trai = tk.Frame(khung_tren, bg="#121212", bd=1, relief="solid")
    khung_trai.pack(side="left", padx=10, pady=10, fill="both", expand=True)

    khung_phai = tk.Frame(khung_tren, bg="#1e1e1e")
    khung_phai.pack(side="right", padx=10, pady=10, fill="y")

    # Màn hình đồ họa Canvas
    khu_ve = tk.Canvas(khung_trai, width=800, height=750, bg="#1a1a1a", highlightthickness=0)
    khu_ve.pack(pady=5)
    khu_ve.create_text(400, 30, text="MÔ PHỎNG THUẬT TOÁN BACKTRACKING", font=("Segoe UI", 16, "bold"), fill="#ffcc00")

    # Cấu trúc khung Log tiến trình hoạt động
    tk.Label(khung_phai, text="LOG QUÁ TRÌNH TÌM KIẾM KHÔNG GIAN", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    o_ghi_log = scrolledtext.ScrolledText(khung_phai, width=65, height=40, font=("Consolas", 10), bg="#000000", fg="#ffffff")
    o_ghi_log.pack(pady=(0, 10))

    # Cấu trúc khung hiển thị kết quả cuối cùng
    khung_duoi = tk.Frame(giao_dien_chinh, bg="#1e1e1e")
    khung_duoi.pack(side="bottom", fill="x", padx=10, pady=10)
    tk.Label(khung_duoi, text="LỜI GIẢI ĐẦU RA", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    o_ket_qua = scrolledtext.ScrolledText(khung_duoi, height=8, font=("Consolas", 11), bg="#000000", fg="#ffffff")
    o_ket_qua.pack(fill="x")

    # Tiến hành vẽ các tỉnh thành lên canvas theo hệ tọa độ mới
    ma_so_tinh_ve = {}
    for ten_tinh, danh_sach_canh in TOA_DO_TINH_THANH.items():
        toa_do_dich_chuyen = [danh_sach_canh[i] + (can_chinh_x if i % 2 == 0 else can_chinh_y) for i in range(len(danh_sach_canh))]
        ma_so_tinh_ve[ten_tinh] = khu_ve.create_polygon(toa_do_dich_chuyen, fill="#e0e0e0", outline="#111111", width=2)
        
    for ten_tinh, (nx, ny, nhan_viet_tat) in TOA_DO_NHAN_TINH.items(): 
        khu_ve.create_text(nx + can_chinh_x, ny + can_chinh_y, text=nhan_viet_tat, font=("Segoe UI", 14, "bold"), fill="#000000")

    # Khởi động công cụ giải thuật và lịch trình chạy hoat họa
    bo_xu_ly = BoGiaiQuyetMienNamCSP(list(TOA_DO_TINH_THANH.keys()), BANG_GIAP_RANH, TAP_MAU_DUNGS)
    nhat_ky_hanh_trinh = []

    def log_tien_trinh(tinh, mau, su_kien, bo_sung=None):
        nhat_ky_hanh_trinh.append((tinh, mau, su_kien, bo_sung))
        
        if su_kien == "UONG_THU": 
            o_ghi_log.insert(tk.END, f"📌 Thử đặt màu [{mau}] cho địa bàn: {tinh}\n")
        elif su_kien == "CHAP_THUAN": 
            o_ghi_log.insert(tk.END, f"  HỢP LỆ: Chấp nhận tạm thời màu [{mau}].\n")
        elif su_kien == "TRUNG_MAU": 
            ds_trung = ', '.join(bo_sung)
            o_ghi_log.insert(tk.END, f"  XUNG ĐỘT: Trùng màu với tỉnh giáp ranh: {ds_trung}\n")
        elif su_kien == "TRA_LAI": 
            o_ghi_log.insert(tk.END, f" ❌ BACKTRACK: Gặp ngõ cụt, thu hồi màu [{mau}] từ tỉnh {tinh}.\n\n")
            
        o_ghi_log.see(tk.END)

    # Thực thi giải thuật thu về kết quả
    ket_qua_cuoi = bo_xu_ly.bat_dau_giai(ham_callback_log=log_tien_trinh)
    if ket_qua_cuoi:
        o_ket_qua.insert(tk.END, f"HỆ THỐNG ĐÃ TÌM THẤY LỜI GIẢI HOÀN CHỈNH:\n{str(ket_qua_cuoi)}")

    # Xử lý chạy đồ họa động (Animation) theo từng bước thuật toán
    def chay_hoat_hoa(index_buoc):
        if index_buoc < len(nhat_ky_hanh_trinh):
            t, m, sk, _ = nhat_ky_hanh_trinh[index_buoc]
            if sk == "CHAP_THUAN": 
                khu_ve.itemconfig(ma_so_tinh_ve[t], fill=HE_HEX_MAU_SAC[m])
            elif sk == "TRA_LAI": 
                khu_ve.itemconfig(ma_so_tinh_ve[t], fill="#e0e0e0")
            giao_dien_chinh.after(200, lambda: chay_hoat_hoa(index_buoc + 1))

    giao_dien_chinh.after(500, lambda: chay_hoat_hoa(0))
    giao_dien_chinh.mainloop()

if __name__ == "__main__":
    main()