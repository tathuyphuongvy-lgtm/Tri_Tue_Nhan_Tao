# MSSV: 24110069
# Họ và tên: Tạ Thùy Phương Vy
#https://github.com/tathuyphuongvy-lgtm
# ĐỀ TÀI: GIẢI QUYẾT BÀI TOÁN TÔ MÀU BẢN ĐỒ BẰNG CSP & FORWARD CHECKING

import tkinter as tk
from tkinter import scrolledtext
import copy

# =========================================================
# 1. ENGINE XỬ LÝ THUẬT TOÁN CSP (FORWARD CHECKING)
# =========================================================
class BoGiaiCSPMap:
    def __init__(self, danh_sach_vung, bang_ke, tap_mau):
        self.cac_vung = danh_sach_vung
        self.ke_nhau = bang_ke
        self.mau_hop_le = tap_mau
        
        # Luu ket qua gan mau hien tai
        self.phat_mau = {}
        # Tap domain kha dung cho tung khu vuc
        self.mien_gia_tri = {vung: list(tap_mau) for vung in danh_sach_vung}

    def _kiem_tra_truoc(self, vung_chon, mau_gan, cac_mien):
        """ Thuc hien Forward Checking de loai bo mau khoi cac vung hang xom """
        for hang_xom in self.ke_nhau.get(vung_chon, []):
            if hang_xom not in self.phat_mau and mau_gan in cac_mien[hang_xom]:
                cac_mien[hang_xom].remove(mau_gan)
                # Neu co bat ky vung ke nao bi rong domain -> Be tac (False)
                if not cac_mien[hang_xom]: 
                    return False 
        return True

    def thuc_thi_tim_kiem(self, callback_ghi_log=None):
        return self._quay_lui_tim_kiem(callback_ghi_log)

    def _quay_lui_tim_kiem(self, callback_ghi_log):
        # Dieu kien dung: Da to xong mau cho tat ca cac vung
        if len(self.phat_mau) == len(self.cac_vung):
            return self.phat_mau

        # Lay vung dau tien chua duoc gan mau (Phuong phap chon mac dinh)
        vung_trong = [v for v in self.cac_vung if v not in self.phat_mau]
        khu_vuc_xet = vung_trong[0]

        for mau in self.mien_gia_tri[khu_vuc_xet]:
            if callback_ghi_log: 
                callback_ghi_log(khu_vuc_xet, mau, "THU_NGHIEM", None)
            
            # Sao luu mien gia tri truoc khi forward check de phuc hoi neu can
            mien_sao_luu = copy.deepcopy(self.mien_gia_tri)
            self.phat_mau[khu_vuc_xet] = mau
            
            if self._kiem_tra_truoc(khu_vuc_xet, mau, self.mien_gia_tri):
                if callback_ghi_log: 
                    callback_ghi_log(khu_vuc_xet, mau, "CHAP_NHAN", None)
                
                ket_qua = self._quay_lui_tim_kiem(callback_ghi_log)
                if ket_qua is not None: 
                    return ket_qua
            else:
                # Tim cac vung bi xung dot dan toi rong domain
                vung_bi_nghen = [hx for hx in self.ke_nhau.get(khu_vuc_xet, []) 
                                 if hx not in self.phat_mau and mau in mien_sao_luu[hx]]
                if callback_ghi_log: 
                    callback_ghi_log(khu_vuc_xet, mau, "XUNG_DOT", vung_bi_nghen)

            # Khoi phuc lai trang thai neu buoc di that bai (Backtracking)
            del self.phat_mau[khu_vuc_xet]
            self.mien_gia_tri = mien_sao_luu
            if callback_ghi_log: 
                callback_ghi_log(khu_vuc_xet, mau, "QUAY_LUI", None)
                
        return None


# =========================================================
# =========================================================
# 2. TOA DO VA DU LIEU KHONG GIAN BAN DO MOI (MÔ PHỎNG MIỀN NAM)
# =========================================================
TOA_DO_DA_GIAC = {
    "TP. Hồ Chí Minh": [280, 360, 380, 350, 340, 440, 350, 480, 260, 440], # Thu hẹp góc đông nam lại một chút
    "Bình Dương":      [240, 220, 380, 210, 380, 350, 280, 360],          
    "Đồng Nai":        [380, 210, 520, 230, 480, 420, 340, 440, 380, 350], # Đỉnh [340, 440] kéo xuống tiếp giáp VT
    "Long An":         [120, 340, 280, 360, 260, 440, 160, 480],          
    "Bà Rịa Vũng Tàu": [340, 440, 480, 420, 540, 530, 350, 480]           # Đỉnh đầu đổi thành [340, 440] để dính vào ĐN
}

VI_TRI_NHA_NHAN = {
    "TP. Hồ Chí Minh": (310, 410, "SG"), 
    "Bình Dương":      (310, 270, "BD"),
    "Đồng Nai":        (440, 310, "ĐN"),
    "Long An":         (190, 400, "LA"),
    "Bà Rịa Vũng Tàu": (440, 470, "VT")
}

DANH_SACH_KE = {
    "TP. Hồ Chí Minh": ["Bình Dương", "Đồng Nai", "Long An", "Bà Rịa Vũng Tàu"],
    "Bình Dương":      ["TP. Hồ Chí Minh", "Đồng Nai"],
    "Đồng Nai":        ["Bình Dương", "TP. Hồ Chí Minh", "Bà Rịa Vũng Tàu"],
    "Long An":         ["TP. Hồ Chí Minh"],
    "Bà Rịa Vũng Tàu": ["TP. Hồ Chí Minh", "Đồng Nai"]
}

BANG_MA_MAU = {"Đỏ": "#ff6666", "Xanh lá": "#4bd24b", "Xanh dương": "#4696ff", "Vàng": "#ffeb46"}
DANH_SACH_MAU = list(BANG_MA_MAU.keys())


# =========================================================
# 3. GIAO DIỆN ĐỒ HỌA ỨNG DỤNG (GUI)
# =========================================================
def khoi_chay_chuong_trinh():
    giao_dien = tk.Tk()
    giao_dien.title("BÀI TOÁN TÔ MÀU BẢN ĐỒ - THUẬT TOÁN CSP")
    giao_dien.geometry("1450x950")
    giao_dien.configure(bg="#1e1e1e")

    # Chia vung giao dien chinh
    khung_tren = tk.Frame(giao_dien, bg="#1e1e1e")
    khung_tren.pack(side="top", fill="both", expand=True)
    
    khung_trai = tk.Frame(khung_tren, bg="#121212", bd=1, relief="solid")
    khung_trai.pack(side="left", padx=10, pady=10, fill="both", expand=True)
    
    khung_phai = tk.Frame(khung_tren, bg="#1e1e1e")
    khung_phai.pack(side="right", padx=10, pady=10, fill="y")

    # Thiet ke Canvas ve ban do
    vung_ve = tk.Canvas(khung_trai, width=800, height=750, bg="#1a1a1a")
    vung_ve.pack(pady=5)
    vung_ve.create_text(400, 30, text="MÔ PHỎNG FORWARD CHECKING", font=("Segoe UI", 16, "bold"), fill="#ffcc00")
    
    # Khung hien thi nhat ky thuat toan
    tk.Label(khung_phai, text="NHẬT KÝ QUÁ TRÌNH TÔ MÀU", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    o_nhat_ky = scrolledtext.ScrolledText(khung_phai, width=65, height=40, font=("Consolas", 10), bg="#000", fg="#fff")
    o_nhat_ky.pack(pady=(0, 10))

    # Khung ket qua cuoi cung o duoi cung
    khung_duoi = tk.Frame(giao_dien, bg="#1e1e1e")
    khung_duoi.pack(side="bottom", fill="x", padx=10, pady=10)
    tk.Label(khung_duoi, text="KẾT QUẢ ĐẦU RA CUỐI CÙNG", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    o_ket_qua = scrolledtext.ScrolledText(khung_duoi, height=8, font=("Consolas", 11), bg="#000", fg="#00ffcc")
    o_ket_qua.pack(fill="x")

    # Canh giua ban do dua tren trong tam du lieu toa do
    toan_bo_x = [toa_do[i] for toa_do in TOA_DO_DA_GIAC.values() for i in range(0, len(toa_do), 2)]
    toan_bo_y = [toa_do[i] for toa_do in TOA_DO_DA_GIAC.values() for i in range(1, len(toa_do), 2)]
    do_lech_x = 400 - (sum(toan_bo_x) / len(toan_bo_x))
    do_lech_y = 300 - (sum(toan_bo_y) / len(toan_bo_y))
    
    # Render cac da giac phuong/xa len canvas
    id_cac_da_giac = {}
    for ten_vung, pts in TOA_DO_DA_GIAC.items():
        toa_do_chuyen_doi = [pts[i] + (do_lech_x if i % 2 == 0 else do_lech_y) for i in range(len(pts))]
        id_cac_da_giac[ten_vung] = vung_ve.create_polygon(toa_do_chuyen_doi, fill="#e0e0e0", outline="white")
        
    for ten_vung, (lx, ly, ky_hieu) in VI_TRI_NHA_NHAN.items(): 
        vung_ve.create_text(lx + do_lech_x, ly + do_lech_y, text=ky_hieu, font=("Arial", 14, "bold"))

    # Khoi tao doi tuong thuat toan va danh sach lich su buoc di
    bo_giai = BoGiaiCSPMap(list(TOA_DO_DA_GIAC.keys()), DANH_SACH_KE, DANH_SACH_MAU)
    lich_su_chay = []

    def ghi_nhan_tien_trinh(vung, mau, kieu_su_kien, thong_tin_them):
        lich_su_chay.append((vung, mau, kieu_su_kien))
        duong_phan_cach = "=" * 50 + "\n"
        
        if kieu_su_kien == "THU_NGHIEM":
            o_nhat_ky.insert("end", f"{duong_phan_cach}👉 TIẾN HÀNH THỬ: Vùng [{vung}] gán màu [{mau}]\n")
            o_nhat_ky.insert("end", f"   Mền khả dụng hiện tại: {bo_giai.mien_gia_tri[vung]}\n")
        
        elif kieu_su_kien == "CHAP_NHAN":
            o_nhat_ky.insert("end", f" ✅ THÀNH CÔNG! Tiến hành cập nhật miền giá trị hàng xóm:\n")
            for h_xom in DANH_SACH_KE.get(vung, []):
                if h_xom not in bo_giai.phat_mau:
                    o_nhat_ky.insert("end", f"   + {h_xom}: {bo_giai.mien_gia_tri[h_xom]}\n")
        
        elif kieu_su_kien == "XUNG_DOT":
            o_nhat_ky.insert("end", f" ❌ XUNG ĐỘT PHÁT SINH: Các vùng {', '.join(thong_tin_them)} bị rỗng mền giá trị!\n")
            
        elif kieu_su_kien == "QUAY_LUI":
            o_nhat_ky.insert("end", " ↩️ BACKTRACK: Khôi phục lại không gian mền ban đầu.\n")
            
        o_nhat_ky.see("end")
        
    # Chay ngam thuat toan truoc de lay toan bo lich su thu nghiem
    loi_giai_cuoi = bo_giai.thuc_thi_tim_kiem(callback_ghi_log=ghi_nhan_tien_trinh)
    if loi_giai_cuoi: 
        o_ket_qua.insert("end", f"Tìm thấy lời giải hợp lệ cho bản đồ:\n{str(loi_giai_cuoi)}")
    else:
        o_ket_qua.insert("end", "Không tìm thấy phương án tô màu hợp lệ.")

    # Tao hieu ung hoat hoa (Animation) tren giao dien dua tren lich su da luu
    def chay_hoat_hoa(chi_so):
        if chi_so < len(lich_su_chay):
            v, m, sk = lich_su_chay[chi_so]
            if sk == "CHAP_NHAN": 
                vung_ve.itemconfig(id_cac_da_giac[v], fill=BANG_MA_MAU[m])
            elif sk == "QUAY_LUI": 
                vung_ve.itemconfig(id_cac_da_giac[v], fill="#e0e0e0")
            giao_dien.after(220, lambda: chay_hoat_hoa(chi_so + 1))
            
    giao_dien.after(400, lambda: chay_hoat_hoa(0))
    giao_dien.mainloop()

if __name__ == "__main__": 
    khoi_chay_chuong_trinh()