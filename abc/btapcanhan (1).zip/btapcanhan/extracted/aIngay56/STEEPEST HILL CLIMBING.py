# =========================================================
# THUẬT TOÁN STEEPEST HILL CLIMBING - PHIÊN BẢN BIẾN ĐỔI SÂU SẮC
# Tạ Thùy Phương Vy _24110069
# =========================================================
import tkinter as tk

class GridNavigator:
    """
    Điều hướng Robot hút bụi dựa trên thuật toán Leo đồi dốc nhất (Steepest Hill Climbing).
    Sử dụng hàm Heuristic h(n) = Số ô rác + Tổng khoảng cách Manhattan.
    """
    def __init__(self, agent_idx, dirt_list, parent=None, move_tag=None, steps=0, node_id="S"):
        self.location = agent_idx                # Cặp (row, col) của robot
        # Quản lý rác dạng danh sách đã sắp xếp để đồng bộ phong cách chống trùng lặp
        self.dirt_registry = sorted(list(dirt_list)) 
        self.parent_ref = parent                 # Trỏ đến node cha
        self.arrival_move = move_tag             # Hướng di chuyển đến node này
        self.g_depth = steps                     # Độ sâu tìm kiếm (số bước di chuyển)
        self.node_id = node_id                   # Nhãn của Node
        
        # Hàm Heuristic cải tiến: Số lượng ô rác + Tổng khoảng cách Manhattan
        self.manhattan_cost = self._evaluate_distance()

    def _evaluate_distance(self):
        if not self.dirt_registry:
            return 0
        r_bot, c_bot = self.location
        # h(n) = Số lượng ô rác + Tổng khoảng cách Manhattan từ robot đến các ô rác
        base_dirt_count = len(self.dirt_registry)
        manhattan_sum = sum(abs(r_bot - dr) + abs(c_bot - dc) for (dr, dc) in self.dirt_registry)
        return base_dirt_count + manhattan_sum

    def verify_goal(self):
        return len(self.dirt_registry) == 0

    def expand_neighbors(self, limit_rows, limit_cols):
        """Sinh các trạng thái kế tiếp bằng kỹ thuật tối ưu hóa mã nguồn."""
        r, c = self.location
        # Vector dịch chuyển trực giao: (Hướng, dòng mới, cột mới)
        vectors = [("U", r - 1, c), ("D", r + 1, c), ("L", r, c - 1), ("R", r, c + 1)]
        
        # Lọc các tọa độ nằm trong biên ma trận hợp lệ
        valid_moves = [(dir_tag, nr, nc) for dir_tag, nr, nc in vectors 
                       if 0 <= nr < limit_rows and 0 <= nc < limit_cols]
        
        children = []
        for d_tag, next_r, next_c in valid_moves:
            # Cập nhật danh sách rác bằng cách lọc loại bỏ ô robot vừa đi qua (nếu có rác thì hút)
            next_dirt = [dirt for dirt in self.dirt_registry if dirt != (next_r, next_c)]
            
            sub_state = GridNavigator(
                agent_idx=(next_r, next_c),
                dirt_list=next_dirt,
                parent=self,
                move_tag=d_tag,
                steps=self.g_depth + 1
            )
            children.append(sub_state)
        return children

# =========================================================
# ĐỊNH DẠNG MA TRẬN LOG ĐỒNG BỘ PHONG CÁCH
# =========================================================
def render_matrix_text(dirty_list, max_r=3, max_c=3):
    """Tạo chuỗi log ma trận dạng [0] và [1] đồng bộ với bài Local Beam Search."""
    output_rows = []
    for r in range(max_r):
        row_cells = [f"[{'1' if (r, c) in dirty_list else '0'}]" for c in range(max_c)]
        output_rows.append(" ".join(row_cells))
    return "\n".join(output_rows)

# =========================================================
# THUẬT TOÁN LEO ĐỒI DỐC NHẤT (STEEPEST HILL CLIMBING)
# =========================================================
def run_steepest_hill_climbing_engine(start_point, initial_dirt, total_rows, total_cols):
    root_node = GridNavigator(start_point, initial_dirt, node_id="S")
    solution_trace = [root_node]
    runtime_logs = ["<<< --- BẮT ĐẦU CHẠY THUẬT TOÁN STEEPEST HILL CLIMBING --- >>>"]
    current_node = root_node
    node_counter = 0

    while not current_node.verify_goal():
        branches = current_node.expand_neighbors(total_rows, total_cols)
        
        chunk = [
            f"[TRÍCH XUẤT] NODE HIỆN TẠI: {current_node.node_id} (Vị trí Robot={current_node.location})",
            f"Cha: {current_node.parent_ref.node_id if current_node.parent_ref else 'None'} | Hướng: {current_node.arrival_move} | Bước: {current_node.g_depth} | h={current_node.manhattan_cost}",
            f"{render_matrix_text(current_node.dirt_registry, total_rows, total_cols)}",
            "DANH SÁCH ĐÁNH GIÁ CÁC TRẠNG THÁI KẾ CẬN (ĐỘ DỐC):"
        ]

        best_candidate = None
        current_best_h = current_node.manhattan_cost 

        for child in branches:
            node_counter += 1
            # Đặt tên dạng kí tự tăng dần và thêm số thứ tự để tránh trùng lặp
            child.node_id = f"{chr(65 + (node_counter % 26))}_{node_counter}"
            
            chunk.append(f"    (+) Xét Node: {child.node_id} | Vị trí: {child.location} | Hướng: {child.arrival_move} | h={child.manhattan_cost}")
            chunk.append(f"{render_matrix_text(child.dirt_registry, total_rows, total_cols)}")
            
            # Nguyên lý dốc nhất: Chỉ chọn trạng thái có h(n) nhỏ hơn hẳn trạng thái hiện tại
            if child.manhattan_cost < current_best_h:
                current_best_h = child.manhattan_cost
                best_candidate = child
        
        if best_candidate:
            chunk.append(f"\n==> QUYẾT ĐỊNH CHỌN: Node {best_candidate.node_id} (Độ dốc tốt nhất h={best_candidate.manhattan_cost})")
            runtime_logs.append("\n".join(chunk))
            current_node = best_candidate
            solution_trace.append(current_node)
        else:
            chunk.append("\n==> DỪNG TIẾN TRÌNH: Rơi vào trạng thái Cực trị địa phương (Local Optimum)!")
            runtime_logs.append("\n".join(chunk))
            break
            
    return solution_trace, runtime_logs

# =========================================================
# ĐIỀU KHIỂN ĐỒ HỌA HOẠT CẢNH VÀ HIỂN THỊ GUI
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - Steepest Hill Climbing", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 18, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    
    legends = [("#e0e0e0", "0 = CLEAN CELL"), ("#ff6666", "1 = DIRTY CELL"), ("#3399ff", "BLUE = ROBOT")]
    for bg_c, txt in legends:
        tk.Label(center_legend, bg=bg_c, width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
        tk.Label(center_legend, text=txt, bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 95
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    # Kích hoạt động cơ giải thuật Steepest Hill Climbing mới
    path, steps_log = run_steepest_hill_climbing_engine(start_pos, initial_dirty, ROWS, COLS)
    
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n\n" + "="*45 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    path_names = [node.node_id for node in path]
    path_coords = [str(node.location) for node in path]
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
    
    last_node = path[-1]
    if last_node.verify_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!")
        
    def draw_state(state, step_index):
        canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirt_registry
                if (r, c) == state.location:
                    cell_bg, text_color, width_border = "#3399ff", "white", 3
                else:
                    cell_bg, text_color, width_border = ("#ff6666", "white", 1) if is_dirty else ("#e0e0e0", "#444444", 1)
                
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline="white", width=width_border)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 - (5 if (r,c) == state.location else 0), text="1" if is_dirty else "0", fill=text_color, font=("Consolas", 18, "bold"))
                if (r, c) == state.location:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 15, text="ROBOT", fill="white", font=("Segoe UI", 8, "bold"))
                    
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].location
                r2, c2 = path[i+1].location
                canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=3, arrow=tk.LAST)

    def animate(step_index):
        if step_index < len(path):
            draw_state(path[step_index], step_index)
            center_frame.after(650, lambda: animate(step_index + 1))
    animate(0)

# =========================================================
# KHỐI KHỞI CHẠY KHUNG ĐỒ HỌA HOÀN CHỈNH ĐỘC LẬP
# =========================================================
if __name__ == "__main__":
    app_root = tk.Tk()
    app_root.title("Advanced Intelligence Simulation - Steepest Hill Climbing")
    app_root.geometry("1100x650")
    
    # Thiết kế giao diện 3 phân vùng độc lập
    sec_left = tk.Frame(app_root, width=350, bg="#f4f4f6")
    sec_left.pack(side="left", fill="both", expand=True)
    
    sec_right = tk.Frame(app_root, width=310, bg="#edf0f5")
    sec_right.pack(side="right", fill="both", expand=True)
    
    sec_center = tk.Frame(app_root, width=440, bg="#ffffff")
    sec_center.pack(side="left", fill="both", expand=True)
    
    # Gắn vùng chứa Text Log và kết quả
    text_log_area = tk.Text(sec_left, wrap="word", font=("Courier New", 9))
    text_log_area.pack(fill="both", expand=True, padx=5, pady=5)
    
    text_res_area = tk.Text(sec_right, wrap="word", font=("Courier New", 10))
    text_res_area.pack(fill="both", expand=True, padx=5, pady=5)
    
    # Khởi động chương trình
    run(sec_center, text_log_area, text_res_area, "SteepestHillClimbing")
    
    app_root.mainloop()