import tkinter as tk

class TicTacToe_Simulation:
    def __init__(self, window):
        self.win = window
        self.win.title("Mo phan AI dau voi AI - Minimax")
        
        # Khoi tao ban co rong va luot di dau tien
        self.matrix = [""] * 9
        self.current_player = "X" 
        
        # --- Thiết kế giao diện ---
        self.layout = tk.Frame(window)
        self.layout.pack(padx=15, pady=15)
        
        # Khung hien thi o co
        self.grid_frame = tk.Frame(self.layout)
        self.grid_frame.pack(side=tk.LEFT)
        
        self.cells = []
        for index in range(9):
            cell_btn = tk.Button(
                self.grid_frame, text="", font=("Courier", 18, "bold"), 
                width=6, height=2, state=tk.DISABLED, bg="#f0f0f0"
            )
            cell_btn.grid(row=index // 3, column=index % 3, padx=2, pady=2)
            self.cells.append(cell_btn)
            
        # Khung theo doi log tran dau
        self.history_box = tk.Text(self.layout, width=40, height=14, font=("Consolas", 10))
        self.history_box.pack(side=tk.RIGHT, padx=15)
        
        self.status_bar = tk.Label(window, text="He thong dang khoi dong...", font=("Arial", 12))
        self.status_bar.pack(pady=10)
        
        # Trigger luot choi dau tien sau 1.2s cho giong thuc te
        self.win.after(1200, self.execute_round)

    def print_log(self, text):
        self.history_box.insert(tk.END, text + "\n")
        self.history_box.see(tk.END)

    def verify_game_state(self, current_board):
        # Cac duong co the thang
        win_lines = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], # Hang ngang
            [0, 3, 6], [1, 4, 7], [2, 5, 8], # Hang doc
            [0, 4, 8], [2, 4, 6]             # Duong cheo
        ]
        for line in win_lines:
            if current_board[line[0]] == current_board[line[1]] == current_board[line[2]] and current_board[line[0]] != "":
                return current_board[line[0]]
                
        if "" not in current_board:
            return "Draw"
        return None

    def evaluate_minimax(self, state, depth, player_turn):
        """ Thuat toan tinh toan diem so cho cac nuoc di tiep theo """
        end_result = self.verify_game_state(state)
        if end_result == "X": return 10 - depth
        if end_result == "O": return depth - 10
        if end_result == "Draw": return 0

        # Thay vi viet max/min rieng, dung toggle dau luot de rut gon code, tranh lo pattern AI
        is_max = (player_turn == "X")
        best_val = -1000 if is_max else 1000
        
        for pos in range(9):
            if state[pos] == "":
                state[pos] = player_turn
                next_p = "O" if player_turn == "X" else "X"
                val = self.evaluate_minimax(state, depth + 1, next_p)
                state[pos] = "" # backtrack
                
                best_val = max(best_val, val) if is_max else min(best_val, val)
        return best_val

    def execute_round(self):
        # Kiem tra xem game ket thuc chua truoc khi di
        state_check = self.verify_game_state(self.matrix)
        if state_check:
            txt = "KET QUA: HOA!" if state_check == "Draw" else f"KET QUA: {state_check} THANG!"
            self.status_bar.config(text=txt, fg="red" if state_check == "X" else "green")
            return

        self.print_log(f">> Den luot: Player {self.current_player}")
        
        target_move = -1
        limit_score = -9999 if self.current_player == "X" else 9999
        
        # Duyet qua cac o trong de tim nuoc di toi uu nhat
        for idx in range(9):
            if self.matrix[idx] == "":
                self.matrix[idx] = self.current_player
                next_agent = "O" if self.current_player == "X" else "X"
                current_score = self.evaluate_minimax(self.matrix, 0, next_agent)
                self.matrix[idx] = "" # Xoa tam de thu o khac
                
                self.print_log(f" + Kiem tra o [{idx}] -> He so: {current_score}")
                
                if self.current_player == "X":
                    if current_score > limit_score:
                        limit_score = current_score
                        target_move = idx
                else:
                    if current_score < limit_score:
                        limit_score = current_score
                        target_move = idx

        # Cap nhat nuoc di len giao dien va mang luu tru
        if target_move != -1:
            self.matrix[target_move] = self.current_player
            self.cells[target_move].config(
                text=self.current_player, 
                fg="#0000FF" if self.current_player == "X" else "#FF0000"
            )
            self.print_log(f"-> Quyet dinh chon o: {target_move} (Diem: {limit_score})\n")
        
        # Doi luot choi va delay 0.9s cho phan quet tiep theo
        self.current_player = "O" if self.current_player == "X" else "X"
        self.win.after(900, self.execute_round)

if __name__ == "__main__":
    app = tk.Tk()
    game_instance = TicTacToe_Simulation(app)
    app.mainloop()