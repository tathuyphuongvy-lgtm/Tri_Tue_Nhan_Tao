import tkinter as tk

class TicTacToeExpectimaxSim:
    def __init__(self, master_win):
        self.window = master_win
        self.window.title("Simulation: Expectimax Agent Game")
        
        # Khoi tao bang co trong
        self.grid_state = [""] * 9
        self.active_turn = "X"
        
        # --- Giao dien ---
        self.container = tk.Frame(master_win)
        self.container.pack(padx=12, pady=12)
        
        self.panel_board = tk.Frame(self.container)
        self.panel_board.pack(side=tk.LEFT)
        
        self.board_cells = []
        for pos in range(9):
            btn = tk.Button(
                self.panel_board, text="", font=("Segoe UI", 16, "bold"),
                width=6, height=2, state=tk.DISABLED, bg="#fafafa"
            )
            btn.grid(row=pos // 3, column=pos % 3, padx=3, pady=3)
            self.board_cells.append(btn)
            
        # SUA TAI DAY: Doi 9.5 thanh số nguyên 9 hoặc 10
        self.terminal_log = tk.Text(self.container, width=50, height=18, font=("Consolas", 10))
        self.terminal_log.pack(side=tk.RIGHT, padx=10)
        
        self.info_banner = tk.Label(master_win, text="Dang nap thuat toan...", font=("Helvetica", 11, "italic"))
        self.info_banner.pack(pady=8)
        
        # Chay sau 1.2 giay
        self.window.after(1200, self.process_next_step)

    def append_log(self, message):
        self.terminal_log.insert(tk.END, message + "\n")
        self.terminal_log.see(tk.END)

    def evaluate_board(self, current_matrix):
        winning_rules = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        for rule in winning_rules:
            if current_matrix[rule[0]] == current_matrix[rule[1]] == current_matrix[rule[2]] and current_matrix[rule[0]] != "":
                return current_matrix[rule[0]]
                
        return "Tie" if "" not in current_matrix else None

    def run_expectimax(self, matrix, current_depth, current_agent):
        state_result = self.evaluate_board(matrix)
        if state_result == "X": 
            return 10 - current_depth
        if state_result == "O": 
            return current_depth - 10
        if state_result == "Tie": 
            return 0

        available_slots = [index for index, val in enumerate(matrix) if val == ""]

        if current_agent == "X":
            highest_score = -float('inf')
            for slot in available_slots:
                matrix[slot] = "X"
                node_value = self.run_expectimax(matrix, current_depth + 1, "O")
                matrix[slot] = ""
                if node_value > highest_score:
                    highest_score = node_value
            return highest_score
        else:
            accumulated_score = 0
            for slot in available_slots:
                matrix[slot] = "O"
                node_value = self.run_expectimax(matrix, current_depth + 1, "X")
                matrix[slot] = ""
                accumulated_score += node_value
                
            return accumulated_score / len(available_slots)

    def process_next_step(self):
        match_status = self.evaluate_board(self.grid_state)
        if match_status:
            final_text = "TRAN DAU HOA!" if match_status == "Tie" else f"NGUOI CHOI {match_status} CHIEN THANG!"
            self.info_banner.config(text=final_text, fg="#d9534f" if match_status == "X" else "#5cb85c")
            return

        self.append_log(f"=== Phan tich luot: {self.active_turn} ===")
        chosen_move = -1
        open_positions = [i for i, v in enumerate(self.grid_state) if v == ""]
        
        if self.active_turn == "X":
            optimal_value = -float('inf')
            for pos in open_positions:
                self.grid_state[pos] = "X"
                calculated_weight = self.run_expectimax(self.grid_state, 0, "O")
                self.grid_state[pos] = ""
                
                self.append_log(f" -> Thu o {pos} | Trong so: {calculated_weight:.3f}")
                if calculated_weight > optimal_value:
                    optimal_value = calculated_weight
                    chosen_move = pos
        else:
            optimal_value = float('inf')
            for pos in open_positions:
                self.grid_state[pos] = "O"
                calculated_weight = self.run_expectimax(self.grid_state, 0, "X")
                self.grid_state[pos] = ""
                
                self.append_log(f" -> Thu o {pos} | Gia tri ky vong: {calculated_weight:.3f}")
                if calculated_weight < optimal_value:
                    optimal_value = calculated_weight
                    chosen_move = pos

        if chosen_move != -1:
            self.grid_state[chosen_move] = self.active_turn
            self.board_cells[chosen_move].config(
                text=self.active_turn,
                fg="#1b6ca8" if self.active_turn == "X" else "#db3b61"
            )
            self.append_log(f">> Quyet dinh: Chon o [{chosen_move}] voi Diem so: {optimal_value:.3f}\n")

        self.active_turn = "O" if self.active_turn == "X" else "X"
        self.window.after(850, self.process_next_step)

if __name__ == "__main__":
    root_window = tk.Tk()
    simulator = TicTacToeExpectimaxSim(root_window)
    root_window.mainloop()