import tkinter as tk

class TicTacToeAlphaBetaEngine:
    def __init__(self, main_window):
        self.app = main_window
        self.app.title("Gia lap thuat toan Alpha-Beta Pruning")
        
        # Trang thai ban co va nguoi di dau
        self.matrix_state = [""] * 9
        self.active_player = "X"
        
        # --- Do hoa giao dien ---
        self.root_layout = tk.Frame(main_window)
        self.root_layout.pack(padx=12, pady=12)
        
        self.grid_board = tk.Frame(self.root_layout)
        self.grid_board.pack(side=tk.LEFT)
        
        self.cell_widgets = []
        for idx in range(9):
            cell = tk.Button(
                self.grid_board, text="", font=("Segoe UI", 16, "bold"),
                width=6, height=2, state=tk.DISABLED, bg="#fcfcfc"
            )
            cell.grid(row=idx // 3, column=idx % 3, padx=2, pady=2)
            self.cell_widgets.append(cell)
            
        # Co chu de so nguyen 10 de tranh loi he thong
        self.display_log = tk.Text(self.root_layout, width=55, height=18, font=("Consolas", 10))
        self.display_log.pack(side=tk.RIGHT, padx=12)
        
        self.status_text = tk.Label(main_window, text="He thong dang phan tich...", font=("Arial", 11, "bold"))
        self.status_text.pack(pady=6)
        
        # Kich hoat game sau 1.2s
        self.app.after(1200, self.run_next_frame)

    def write_log(self, text_msg):
        self.display_log.insert(tk.END, text_msg + "\n")
        self.display_log.see(tk.END)

    def check_board_winner(self, current_map):
        lines = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        for line in lines:
            if current_map[line[0]] == current_map[line[1]] == current_map[line[2]] and current_map[line[0]] != "":
                return current_map[line[0]]
                
        if "" not in current_map:
            return "Draw"
        return None

    def execute_alpha_beta(self, map_data, depth, alpha, beta, player):
        """ Ham xu ly quyet dinh va cat tia nhanh Alpha-Beta bang Player dinh danh """
        match_result = self.check_board_winner(map_data)
        if match_result == "X":
            return 10 - depth
        if match_result == "O":
            return depth - 10
        if match_result == "Draw":
            return 0

        slots_left = [i for i, v in enumerate(map_data) if v == ""]

        if player == "X":
            # Luot toi uu hoa diem so cao nhat (MAX)
            highest_val = -float('inf')
            for slot in slots_left:
                map_data[slot] = "X"
                score = self.execute_alpha_beta(map_data, depth + 1, alpha, beta, "O")
                map_data[slot] = ""
                
                highest_val = max(highest_val, score)
                alpha = max(alpha, score)
                
                # THAY DOI TAI DAY: Log da duoc doi thanh dang viet tat gon nhu dan code tay
                if beta <= alpha:
                    self.write_log(f"   => [Pruned] d={depth} | alpha={alpha}, beta={beta}")
                    break
            return highest_val
        else:
            # Luot toi thieu hoa thiet hai (MIN)
            lowest_val = float('inf')
            for slot in slots_left:
                map_data[slot] = "O"
                score = self.execute_alpha_beta(map_data, depth + 1, alpha, beta, "X")
                map_data[slot] = ""
                
                lowest_val = min(lowest_val, score)
                beta = min(beta, score)
                
                if beta <= alpha:
                    self.write_log(f"   => [Pruned] d={depth} | alpha={alpha}, beta={beta}")
                    break
            return lowest_val

    def run_next_frame(self):
        end_state = self.check_board_winner(self.matrix_state)
        if end_state:
            msg = "KET QUA: HOA CO!" if end_state == "Draw" else f"KET QUA: {end_state} THANG TRAN!"
            self.status_text.config(text=msg, fg="#d9534f" if end_state == "X" else "#428bca")
            return

        self.write_log(f"--- Player {self.active_player} Turn ---")
        best_move = -1
        available_moves = [i for i, val in enumerate(self.matrix_state) if val == ""]
        
        if self.active_player == "X":
            record_score = -float('inf')
            for cell_id in available_moves:
                self.matrix_state[cell_id] = "X"
                current_score = self.execute_alpha_beta(self.matrix_state, 0, -float('inf'), float('inf'), "O")
                self.matrix_state[cell_id] = ""
                
                self.write_log(f" Check pos {cell_id} | score: {current_score}")
                if current_score > record_score:
                    record_score = current_score
                    best_move = cell_id
        else:
            record_score = float('inf')
            for cell_id in available_moves:
                self.matrix_state[cell_id] = "O"
                current_score = self.execute_alpha_beta(self.matrix_state, 0, -float('inf'), float('inf'), "X")
                self.matrix_state[cell_id] = ""
                
                self.write_log(f" Check pos {cell_id} | score: {current_score}")
                if current_score < record_score:
                    record_score = current_score
                    best_move = cell_id

        # Luu gia tri da chon va hien thi len o co
        if best_move != -1:
            self.matrix_state[best_move] = self.active_player
            self.cell_widgets[best_move].config(
                text=self.active_player,
                fg="#2980b9" if self.active_player == "X" else "#c0392b"
            )
            self.write_log(f" >> Selected: Slot {best_move} (final: {record_score})\n")

        # Hoan doi luot choi cho khung hinh tiep theo
        self.active_player = "O" if self.active_player == "X" else "X"
        self.app.after(900, self.run_next_frame)

if __name__ == "__main__":
    window = tk.Tk()
    engine = TicTacToeAlphaBetaEngine(window)
    window.mainloop()