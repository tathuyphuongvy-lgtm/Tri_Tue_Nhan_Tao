#24110069_ Tạ Thùy Phương Vy
#https://github.com/tathuyphuongvy-lgtm
import tkinter as tk
import copy
import random

# =========================================================
# LỚP QUẢN LÝ TRẠNG THÁI KHÔNG GIAN (GRID STATE)
# =========================================================
class GridState:
    """
    Biểu diễn một cấu hình trạng thái của robot và các ô bẩn trong ma trận.
    """
    def __init__(self, robot_loc, dirt_map, ancestor=None, move_dir=None, cost=0, node_id="S"):
        self.robot_loc = robot_loc          # Tọa độ hiện tại (row, col) của máy hút bụi
        self.dirt_map = set(dirt_map)       # Tập hợp các tọa độ chứa rác
        self.ancestor = ancestor            # Trạng thái cha trước đó
        self.move_dir = move_dir            # Hướng di chuyển dẫn đến trạng thái này (U, D, L, R)
        self.cost = cost                    # Chi phí đường đi từ nút gốc
        self.h_val = len(self.dirt_map)     # Heuristic: Số lượng ô bẩn còn lại
        self.node_id = node_id              # Tên định danh của nút trên cây tìm kiếm

    def check_victory(self):
        """Trả về True nếu toàn bộ bản đồ đã được làm sạch"""
        return not self.dirt_map

    def get_neighbors(self, max_r, max_c):
        """Sinh các trạng thái kế cận hợp lệ bằng cách di chuyển 4 hướng"""
        adjacent_nodes = []
        r, c = self.robot_loc
        directions = [("U", r - 1, c), ("D", r + 1, c), ("L", r, c - 1), ("R", r, c + 1)]
        
        for direction, next_r, next_c in directions:
            if 0 <= next_r < max_r and 0 <= next_c < max_c:
                next_dirt = copy.deepcopy(self.dirt_map)
                if (next_r, next_c) in next_dirt:
                    next_dirt.remove((next_r, next_c))
                
                child_node = GridState(
                    robot_loc=(next_r, next_c), 
                    dirt_map=next_dirt, 
                    ancestor=self, 
                    move_dir=direction, 
                    cost=self.cost + 1
                )
                adjacent_nodes.append(child_node)
        return adjacent_nodes

    @staticmethod
    def setup_random_configuration(max_r, max_c, total_dirt=4):
        """Khởi tạo ngẫu nhiên vị trí robot và rác khi thực hiện Restart"""
        all_coordinates = [(r, c) for r in range(max_r) for c in range(max_c)]
        spawn_robot = random.choice(all_coordinates)
        spawn_dirt = random.sample(all_coordinates, min(total_dirt, len(all_coordinates)))
        
        if spawn_robot in spawn_dirt:
            spawn_dirt.remove(spawn_robot)
            
        return GridState(spawn_robot, spawn_dirt, node_id="S")


# =========================================================
# HÀM TRỢ GIÚP LOGGING TRỰC QUAN
# =========================================================
def stringify_grid(dirt_map, max_r=3, max_c=3):
    return "\n".join(" ".join("1" if (r, c) in dirt_map else "0" for c in range(max_c)) for r in range(max_r))


# =========================================================
# THUẬT TOÁN LEO ĐỒI KHỞI ĐỘNG NGẪU NHIÊN (CORE ALGORITHM)
# =========================================================
def execute_random_restart_hill_climbing(init_pos, init_dirt, grid_rows, grid_cols, max_attempts=5):
    root_node = GridState(init_pos, init_dirt, node_id="S")
    execution_logs = ["=== KHỞI CHẠY GIẢI THUẬT LEO ĐỒI RANDOM RESTART ==="]
    global_node_idx = 0
    history_of_runs = [] 

    for attempt in range(1, max_attempts + 1):
        execution_logs.append(f"\n[TIẾN TRÌNH] BẮT ĐẦU LƯỢT CHẠY THỨ {attempt}")
        if attempt == 1:
            current_state = root_node
        else:
            current_state = GridState.setup_random_configuration(grid_rows, grid_cols, len(init_dirt))
            
        current_run_path = [current_state]

        while True:
            if current_state.check_victory():
                execution_logs.append(f"\n[THÀNH CÔNG] Tìm thấy Goal tại lượt chạy thứ {attempt}!\nNút đích: {current_state.node_id} (Vị trí: {current_state.robot_loc})")
                history_of_runs.append(current_run_path)
                return current_run_path, execution_logs, history_of_runs
            
            possible_moves = current_state.get_neighbors(grid_rows, grid_cols)
            log_buffer = [
                f"-> Đang duyệt: {current_state.node_id} (Robot: {current_state.robot_loc})",
                f"   Cha: {current_state.ancestor.node_id if current_state.ancestor else 'None'} | Hành động: {current_state.move_dir} | h = {current_state.h_val}",
                f"{stringify_grid(current_state.dirt_map, grid_rows, grid_cols)}",
                "   Đánh giá các nút con:"
            ]

            promising_moves = []
            for node in possible_moves:
                global_node_idx += 1
                node.node_id = chr(65 + (global_node_idx % 26)) + (str(global_node_idx // 26) if global_node_idx >= 26 else "")
                log_buffer.append(f"     + Con {node.node_id} (Robot: {node.robot_loc}) | h = {node.h_val}")
                
                if node.h_val < current_state.h_val:
                    promising_moves.append(node)
            
            if not promising_moves:
                log_buffer.append("=> KẾT QUẢ: BỊ KẸT (Không có trạng thái nào tốt hơn)!")
                log_buffer.append(f"=> HỆ THỐNG SẼ RESTART SANG LƯỢT TIẾP THEO.")
                execution_logs.append("\n".join(log_buffer))
                history_of_runs.append(current_run_path)
                break
            else:
                lowest_h = min(n.h_val for n in promising_moves)
                best_candidates = [n for n in promising_moves if n.h_val == lowest_h]
                chosen_node = random.choice(best_candidates)
                
                log_buffer.append(f"======> LỰA CHỌN: Nút {chosen_node.node_id} (h = {chosen_node.h_val})")
                execution_logs.append("\n".join(log_buffer))
                
                current_state = chosen_node
                current_run_path.append(current_state)
                
    execution_logs.append(f"\n[THẤT BẠI] Đã thử nghiệm hết {max_attempts} lượt nhưng không giải được bài toán.")
    return current_run_path, execution_logs, history_of_runs


# =========================================================
# QUẢN LÝ GIAO DIỆN VÀ ĐIỀU KHIỂN HOẠT HỌA (GUI & ANIMATION)
# =========================================================
def run(center_frame, log_text, result_text, name=""):
    GRID_R, GRID_C = 3, 3
    initial_robot_pos = (0, 0)
    initial_dirt_locs = [(0, 1), (1, 0), (1, 1), (2, 2)]
    LIMIT_RESTART = 5
    GRID_UNIT = 100

    center_frame.configure(bg="#111111") 
    for widget in center_frame.winfo_children():
        widget.destroy()
    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    header = tk.Label(center_frame, text="ROBOT VACUUM - RANDOM RESTART HILL CLIMBING", bg="#1f1f1f", fg="#00e676", font=("Arial", 16, "bold"), pady=10)
    header.pack(side="top", fill="x", pady=(5, 10))
    
    legend_frame = tk.Frame(center_frame, bg="#1f1f1f", pady=6)
    legend_frame.pack(side="top", fill="x", padx=20, pady=(0, 15))
    
    legend_items = [("#text_clean", "0 = SẠCH", "#424242"), ("#text_dirty", "1 = BẨN", "#ff3d00"), ("#text_bot", "BLUE = ROBOT", "#2979ff")]
    for idx, (tag, txt, color) in enumerate(legend_items):
        lbl_box = tk.Label(legend_frame, bg=color, width=3, relief="flat")
        lbl_box.grid(row=0, column=idx*2, padx=(15, 5))
        lbl_txt = tk.Label(legend_frame, text=txt, bg="#1f1f1f", fg="#ffffff", font=("Tahoma", 9, "bold"))
        lbl_txt.grid(row=0, column=idx*2+1, padx=(0, 15))

    canvas_box = tk.Frame(center_frame, bg="#111111")
    canvas_box.pack(expand=True)
    board_view = tk.Canvas(canvas_box, width=GRID_C * GRID_UNIT, height=GRID_R * GRID_UNIT, bg="#222222", highlightthickness=1, highlightbackground="#444444")
    board_view.pack(side="bottom")

    final_path, log_data, run_history = execute_random_restart_hill_climbing(
        initial_robot_pos, initial_dirt_locs, GRID_R, GRID_C, LIMIT_RESTART
    )
    
    for block in log_data:
        log_text.insert(tk.END, block + "\n" + "-"*50 + "\n")
    log_text.see(tk.END)
    log_text.update_idletasks()

    if not final_path:
        result_text.insert(tk.END, "CRITICAL: Không tìm thấy phương án di chuyển khả thi!")
        return

    result_text.insert(tk.END, f"=== THỐNG KÊ GIẢI THUẬT ===\nTổng số chu kỳ khởi động: {len(run_history)}\n\n")
    
    end_state = final_path[-1]
    if end_state.check_victory():
        result_text.insert(tk.END, f"TRẠNG THÁI: HOÀN THÀNH XUẤT SẮC!\nGiải được bài toán tại chu kỳ thứ {len(run_history)}.\n")
        result_text.tag_config("win_style", foreground="#00e676")
        result_text.tag_add("win_style", "1.0", "end")
        
        result_text.insert(tk.END, "\n" + "="*15 + " ĐƯỜNG ĐI CHI TIẾT " + "="*15 + "\n\n")
        
        node_chain = [n.node_id for n in final_path]
        result_text.insert(tk.END, "Chuỗi các nút đã đi: " + " -> ".join(node_chain) + "\n\n")
        
        coord_chain = " -> ".join([str(n.robot_loc) for n in final_path])
        result_text.insert(tk.END, "Tọa độ di chuyển thực tế:\n" + coord_chain + "\n")
    else:
        result_text.insert(tk.END, f"TRẠNG THÁI: THẤT BẠI!\nĐã dùng hết {LIMIT_RESTART} lượt restart nhưng bị kẹt ở điểm cực trị địa phương.")
        result_text.tag_config("lose_style", foreground="#ff3d00")
        result_text.tag_add("lose_style", "1.0", "end")
        
    result_text.see(tk.END)
    result_text.update_idletasks()

    def render_matrix_view(path_track, current_node, current_step_idx):
        board_view.delete("all")
        for r in range(GRID_R):
            for c in range(GRID_C):
                pos_x1, pos_y1 = c * GRID_UNIT, r * GRID_UNIT
                pos_x2, pos_y2 = pos_x1 + GRID_UNIT, pos_y1 + GRID_UNIT
                is_cell_dirty = (r, c) in current_node.dirt_map
                val_display = "1" if is_cell_dirty else "0"
                
                if (r, c) == current_node.robot_loc:
                    bg_color, fg_color, border_color, border_w = "#2979ff", "#ffffff", "#ffffff", 3
                else:
                    bg_color = "#ff3d00" if is_cell_dirty else "#424242"
                    fg_color = "#ffffff" if is_cell_dirty else "#9e9e9e"
                    border_color, border_w = "#616161", 1

                board_view.create_rectangle(pos_x1, pos_y1, pos_x2, pos_y2, fill=bg_color, outline=border_color, width=border_w)
                text_y_offset = -12 if (r, c) == current_node.robot_loc else 0
                board_view.create_text(pos_x1 + GRID_UNIT/2, pos_y1 + GRID_UNIT/2 + text_y_offset, text=val_display, fill=fg_color, font=("Consolas", 18, "bold"))
                
                if (r, c) == current_node.robot_loc:
                    board_view.create_text(pos_x1 + GRID_UNIT/2, pos_y1 + GRID_UNIT/2 + 16, text="AGENT", fill="#ffffff", font=("Arial", 9, "bold"))

        if current_step_idx > 0:
            for i in range(current_step_idx):
                start_r, start_c = path_track[i].robot_loc
                dest_r, dest_c = path_track[i+1].robot_loc
                
                arrow_x1 = start_c * GRID_UNIT + GRID_UNIT / 2
                arrow_y1 = start_r * GRID_UNIT + GRID_UNIT / 2
                arrow_x2 = dest_c * GRID_UNIT + GRID_UNIT / 2
                arrow_y2 = dest_r * GRID_UNIT + GRID_UNIT / 2
                board_view.create_line(arrow_x1, arrow_y1, arrow_x2, arrow_y2, fill="#ffd600", width=3, arrow=tk.LAST)

    def trigger_animation(run_idx, step_idx):
        if run_idx < len(run_history):
            active_path = run_history[run_idx]
            if step_idx < len(active_path):
                node_to_draw = active_path[step_idx]
                render_matrix_view(active_path, node_to_draw, step_idx)
                board_view.create_text(25, 20, text=f"RUN: {run_idx + 1}", fill="#00e676", font=("Arial", 11, "bold"), anchor="w")
                center_frame.after(600, lambda: trigger_animation(run_idx, step_idx + 1))
            else:
                if run_idx < len(run_history) - 1:
                    board_view.create_rectangle(0, 0, GRID_C*GRID_UNIT, GRID_R*GRID_UNIT, fill="#b71c1c", stipple="gray50")
                    board_view.create_text(GRID_C*GRID_UNIT/2, GRID_R*GRID_UNIT/2, text="LOCAL OPTIMUM!\nRESTARTING...", fill="#ffffff", font=("Arial", 14, "bold"), justify="center")
                    center_frame.after(1200, lambda: trigger_animation(run_idx + 1, 0))
        else:
            pass

    trigger_animation(0, 0)


# ==============================================================================
# ĐOẠN CODE KHỞI TẠO CỬA SỔ TKINTER BẮT BUỘC ĐỂ KHỞI CHẠY (BỔ SUNG THÊM Ở ĐÂY)
# ==============================================================================
if __name__ == "__main__":
    # 1. Tạo cửa sổ chính ứng dụng
    root = tk.Tk()
    root.title("Vacuum World - Random Restart Hill Climbing")
    root.geometry("1100x700")
    root.configure(bg="#111111")

    # 2. Tạo bố cục hai bên: Bên trái vẽ ma trận, bên phải in text logs
    left_panel = tk.Frame(root, bg="#111111")
    left_panel.pack(side="left", fill="both", expand=True, padx=10, pady=10)

    right_panel = tk.Frame(root, bg="#1a1a1a", width=400)
    right_panel.pack(side="right", fill="both", padx=10, pady=10)

    # 3. Thành phần hiển thị Log chi tiết bên phải
    tk.Label(right_panel, text="THÔNG TIN LOG CHI TIẾT", bg="#1a1a1a", fg="#ffffff", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10, 5))
    t_log = tk.Text(right_panel, height=22, width=50, bg="#222222", fg="#cccccc", font=("Consolas", 9))
    t_log.pack(fill="both", expand=True, pady=5)

    # 4. Thành phần hiển thị Kết quả đường đi bên phải
    tk.Label(right_panel, text="KẾT QUẢ ĐƯỜNG ĐI CUỐI CÙNG", bg="#1a1a1a", fg="#ffffff", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10, 5))
    t_result = tk.Text(right_panel, height=12, width=50, bg="#222222", fg="#ffffff", font=("Arial", 10))
    t_result.pack(fill="x", pady=5)

    # 5. Hàm trung gian bấm nút kích hoạt mô phỏng
    def start_simulation():
        run(left_panel, t_log, t_result)

    # 6. Nút bấm tương tác trên UI
    btn_start = tk.Button(right_panel, text="BẮT ĐẦU CHẠY MÔ PHỎNG", bg="#00e676", fg="#000000", font=("Arial", 11, "bold"), command=start_simulation, height=2)
    btn_start.pack(fill="x", pady=15)

    # Tự động chạy ngay lần đầu tiên khi mở ứng dụng
    root.after(100, start_simulation)

    # Kích hoạt vòng lặp UI Tkinter
    root.mainloop()