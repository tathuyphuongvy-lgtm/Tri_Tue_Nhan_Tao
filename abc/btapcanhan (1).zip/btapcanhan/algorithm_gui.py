import tkinter as tk
from tkinter import ttk

class AlgorithmApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Giao diện Tinh chỉnh Thuật toán")
        self.root.geometry("800x600")
        
        # Áp dụng theme để giao diện trông hiện đại hơn
        style = ttk.Style()
        style.theme_use('clam')
        
        # Chia layout chính: Cột điều khiển (trái) và Cột hiển thị (phải)
        self.control_frame = ttk.Frame(root, padding="10", width=250)
        self.control_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.display_frame = ttk.Frame(root, padding="10")
        self.display_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # ==========================================
        # CONTROL PANEL (KHU VỰC ĐIỀU KHIỂN)
        # ==========================================
        
        # 1. Nút / Dropdown chọn Thuật toán
        ttk.Label(self.control_frame, text="Chọn Thuật toán:", font=("Helvetica", 11, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        self.algo_var = tk.StringVar()
        self.algo_dropdown = ttk.Combobox(self.control_frame, textvariable=self.algo_var, state="readonly", font=("Helvetica", 10))
        self.algo_dropdown['values'] = ("Thuật toán Sắp xếp (Sort)", "Thuật toán Tìm kiếm (Search)", "Thuật toán Đồ thị (Graph)")
        self.algo_dropdown.current(0)
        self.algo_dropdown.pack(fill=tk.X, pady=(0, 20))
        self.algo_dropdown.bind("<<ComboboxSelected>>", self.on_algorithm_change)
        
        # 2. Các thanh trượt tinh chỉnh (Tweak Parameters)
        ttk.Label(self.control_frame, text="Tinh chỉnh Thông số:", font=("Helvetica", 11, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        # Thanh trượt tinh chỉnh thông số 1 (VD: Tốc độ)
        self.param1_label_var = tk.StringVar(value="Tốc độ: 50")
        ttk.Label(self.control_frame, textvariable=self.param1_label_var).pack(anchor=tk.W)
        self.param1_scale = ttk.Scale(self.control_frame, from_=1, to=100, orient=tk.HORIZONTAL, command=self.update_param1_label)
        self.param1_scale.set(50)
        self.param1_scale.pack(fill=tk.X, pady=(0, 15))
        
        # Thanh trượt tinh chỉnh thông số 2 (VD: Số lượng dữ liệu)
        self.param2_label_var = tk.StringVar(value="Kích thước dữ liệu: 100")
        ttk.Label(self.control_frame, textvariable=self.param2_label_var).pack(anchor=tk.W)
        self.param2_scale = ttk.Scale(self.control_frame, from_=10, to=1000, orient=tk.HORIZONTAL, command=self.update_param2_label)
        self.param2_scale.set(100)
        self.param2_scale.pack(fill=tk.X, pady=(0, 25))
        
        # 3. Các nút Hành động
        self.run_button = ttk.Button(self.control_frame, text="▶ Chạy Thuật toán", command=self.run_algorithm)
        self.run_button.pack(fill=tk.X, pady=5)
        
        self.clear_button = ttk.Button(self.control_frame, text="✖ Xóa hiển thị", command=self.clear_display)
        self.clear_button.pack(fill=tk.X, pady=5)
        
        # ==========================================
        # DISPLAY PANEL (KHU VỰC HIỂN THỊ)
        # ==========================================
        
        # Bảng Canvas để vẽ hoặc hiển thị kết quả trực quan
        self.canvas = tk.Canvas(self.display_frame, bg="white", highlightthickness=1, highlightbackground="#ccc")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Thanh trạng thái (Status bar)
        self.status_var = tk.StringVar(value="Sẵn sàng")
        self.status_label = ttk.Label(self.display_frame, textvariable=self.status_var, foreground="#555", font=("Helvetica", 9, "italic"))
        self.status_label.pack(anchor=tk.W, pady=(5, 0))

    def update_param1_label(self, val):
        self.param1_label_var.set(f"Tốc độ: {int(float(val))}")

    def update_param2_label(self, val):
        self.param2_label_var.set(f"Kích thước dữ liệu: {int(float(val))}")

    def on_algorithm_change(self, event):
        selected = self.algo_var.get()
        self.status_var.set(f"Đã chọn: {selected}. Bấm 'Chạy Thuật toán' để bắt đầu.")
        
    def run_algorithm(self):
        selected_algo = self.algo_var.get()
        speed = int(self.param1_scale.get())
        data_size = int(self.param2_scale.get())
        
        self.status_var.set(f"Đang chạy {selected_algo} với Tốc độ={speed}, Kích thước={data_size}...")
        self.clear_display()
        
        # Giả lập logic hiển thị kết quả (Bạn sẽ chèn code thuật toán thật vào đây)
        self.canvas.update()
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        self.canvas.create_text(
            canvas_width / 2, canvas_height / 2, 
            text=f"ĐANG THỰC THI:\n{selected_algo}\n\nThông số Tốc độ: {speed}\nKích thước dữ liệu: {data_size}", 
            font=("Helvetica", 14), justify=tk.CENTER, fill="#333"
        )
        
    def clear_display(self):
        self.canvas.delete("all")
        self.status_var.set("Sẵn sàng")

if __name__ == "__main__":
    root = tk.Tk()
    app = AlgorithmApp(root)
    root.mainloop()
