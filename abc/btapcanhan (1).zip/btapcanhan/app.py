import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import os
import sys
import importlib.util

# =========================================================
# CLASS ĐIỀU KHIỂN THỜI GIAN (CUSTOM FRAME)
# =========================================================
class ControlledFrame(tk.Frame):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.pending_tasks = []
        self.is_paused = False
        self.speed_multiplier = 1.0
        self.tick_interval = 30 # Tần số quét (ms)
        self.running_tick = False

    def start_tick(self):
        if not self.running_tick:
            self.running_tick = True
            self._tick()

    def after(self, ms, func=None, *args):
        # Ghi đè hàm after để can thiệp vào thời gian
        if func is None:
            return super().after(ms)
        task = {"remaining": float(ms), "func": func, "args": args}
        self.pending_tasks.append(task)
        return task

    def _tick(self):
        if not self.is_paused:
            decrement = self.tick_interval * self.speed_multiplier
            to_remove = []
            for t in self.pending_tasks:
                t["remaining"] -= decrement
                if t["remaining"] <= 0:
                    try:
                        t["func"](*t["args"])
                    except Exception as e:
                        print(f"Error in animation task: {e}")
                    to_remove.append(t)
            
            for t in to_remove:
                if t in self.pending_tasks:
                    self.pending_tasks.remove(t)
                    
        super().after(self.tick_interval, self._tick)
        
    def clear_tasks(self):
        self.pending_tasks.clear()


# =========================================================
# 1. QUÉT VÀ NẠP TẤT CẢ CÁC FILE THUẬT TOÁN
# =========================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXTRACTED_DIR = os.path.join(BASE_DIR, "extracted")

algorithms = {}
algo_file_paths = {} # Lưu đường dẫn file để xem code

NAME_MAPPING = {
    "timkiemmtKhongNhinThay": "👁️ Sensorless Search",
    "timkiemtrongmtNhinThayMotPhan": "🕵️ Partially Observable Search",
    "ASao": "⭐ A* Search",
    "BFS1": "🧭 Breadth-First Search (v1)",
    "BFS2": "🧭 Breadth-First Search (v2)",
    "DFS1": "🗺️ Depth-First Search (v1)",
    "DFS2": "🗺️ Depth-First Search (v2)",
    "LOCAL BEAM SEARCH": "🔦 Local Beam Search",
    "STEEPEST HILL CLIMBING": "🏔️ Steepest Hill Climbing",
    "HILL CLIMBING": "🏔️ Hill Climbing",
    "STOCHASTIC HILL CLIMBING": "🎲 Stochastic Hill Climbing",
    "RANDOM RESTART HILL CLIMBING": "🔄 Random Restart Hill Climbing"
}

if os.path.exists(EXTRACTED_DIR):
    for root_dir, dirs, files in os.walk(EXTRACTED_DIR):
        for file in files:
            if file.endswith(".py") and file != "main.py":
                file_path = os.path.join(root_dir, file)
                module_name = os.path.splitext(file)[0]
                
                try:
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    if spec and spec.loader:
                        if root_dir not in sys.path:
                            sys.path.insert(0, root_dir)
                            
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        
                        if hasattr(module, "run"):
                            base_name = NAME_MAPPING.get(module_name, f"⚙️ {module_name.replace('_', ' ').title()}")
                            display_name = base_name
                            
                            counter = 2
                            original_display_name = display_name
                            while display_name in algorithms:
                                display_name = f"{original_display_name} (v{counter})"
                                counter += 1
                                
                            algorithms[display_name] = module.run
                            algo_file_paths[display_name] = file_path
                            
                        if root_dir in sys.path:
                            sys.path.remove(root_dir)
                except Exception as e:
                    print(f"Bỏ qua file {file}: {e}")

print(f"Đã tải thành công {len(algorithms)} thuật toán.")

# =========================================================
# 2. KHỞI TẠO GIAO DIỆN CHÍNH (PREMIUM THEME)
# =========================================================
root = tk.Tk()
root.title("TỔNG HỢP GIAO DIỆN THUẬT TOÁN AI")
root.geometry("1450x820")
root.configure(bg="#1e1e24")

MENU_WIDTH = 340
active_button = None
menu_visible = False
algo_buttons = [] # Lưu danh sách nút để filter

# Thanh Top Bar
top_bar = tk.Frame(root, bg="#2f3640", height=65)
top_bar.pack(side="top", fill="x")

# Container chính
main_container = tk.Frame(root, bg="#1e1e24")
main_container.pack(fill="both", expand=True)

# Khung Trung Tâm (Vẽ đồ họa) - Dùng ControlledFrame thay vì tk.Frame thường
center_frame = ControlledFrame(main_container, bg="#2b2b36", highlightthickness=1, highlightbackground="#3d3d4e")
center_frame.pack(side="left", fill="both", expand=True, padx=15, pady=15)
center_frame.start_tick()

# Khung Log bên phải
log_frame = tk.Frame(main_container, bg="#2b2b36", width=420, highlightthickness=1, highlightbackground="#3d3d4e")
log_frame.pack(side="right", fill="y", padx=(0, 15), pady=15)
log_frame.pack_propagate(False)

# ---- Tab Controller ----
tab_bar = tk.Frame(log_frame, bg="#2b2b36")
tab_bar.pack(fill="x", padx=15, pady=(15, 5))

def show_tab(tab_name):
    if tab_name == "log":
        code_text.pack_forget()
        log_text.pack(fill="both", expand=True)
        btn_tab_log.config(bg="#4cd137", fg="#2f3640")
        btn_tab_code.config(bg="#718093", fg="#f5f6fa")
    else:
        log_text.pack_forget()
        code_text.pack(fill="both", expand=True)
        btn_tab_code.config(bg="#4cd137", fg="#2f3640")
        btn_tab_log.config(bg="#718093", fg="#f5f6fa")

btn_tab_log = tk.Button(tab_bar, text="📝 LOG", bg="#4cd137", fg="#2f3640", font=("Segoe UI", 10, "bold"), relief="flat", padx=10, pady=5, command=lambda: show_tab("log"))
btn_tab_log.pack(side="left", expand=True, fill="x", padx=(0, 5))

btn_tab_code = tk.Button(tab_bar, text="💻 SOURCE CODE", bg="#718093", fg="#f5f6fa", font=("Segoe UI", 10, "bold"), relief="flat", padx=10, pady=5, command=lambda: show_tab("code"))
btn_tab_code.pack(side="right", expand=True, fill="x", padx=(5, 0))

# ---- Nội dung Tabs ----
content_frame = tk.Frame(log_frame, bg="#1e1e24")
content_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))

log_text = ScrolledText(content_frame, bg="#1e1e24", fg="#00a8ff", insertbackground="white", font=("Consolas", 10), relief="flat", padx=10, pady=10)
log_text.pack(fill="both", expand=True)

code_text = ScrolledText(content_frame, bg="#1e1e24", fg="#f5f6fa", insertbackground="white", font=("Consolas", 9), relief="flat", padx=10, pady=10)
# code_text bắt đầu ẩn

# Khung Bottom hiển thị kết quả
bottom_frame = tk.Frame(root, bg="#2f3640", height=130)
bottom_frame.pack(side="bottom", fill="x")

tk.Label(bottom_frame, text="🎯 FINAL SOLUTION PATH / RESULT", bg="#2f3640", fg="#4cd137", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=20, pady=(10, 4))
result_text = tk.Text(bottom_frame, height=3, bg="#1e1e24", fg="#f5f6fa", font=("Consolas", 12), relief="flat", padx=10, pady=5)
result_text.pack(fill="x", padx=20, pady=(0, 15))

# =========================================================
# 3. SIDEBAR MENU TRƯỢT VÀ THANH TÌM KIẾM
# =========================================================
side_menu = tk.Frame(root, bg="#353b48", width=MENU_WIDTH)
side_menu.place(x=-MENU_WIDTH, y=65, relheight=1)

tk.Label(side_menu, text="📂 DANH MỤC THUẬT TOÁN", bg="#353b48", fg="#f5f6fa", font=("Segoe UI", 14, "bold")).pack(pady=(20, 5))

# Thanh tìm kiếm
search_var = tk.StringVar()
search_entry = tk.Entry(side_menu, textvariable=search_var, bg="#2f3640", fg="#f5f6fa", font=("Segoe UI", 11), insertbackground="white", relief="flat")
search_entry.pack(fill="x", padx=20, pady=(0, 15), ipady=5)
search_entry.insert(0, "🔍 Tìm kiếm...")
search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, "end") if search_entry.get() == "🔍 Tìm kiếm..." else None)

canvas_menu = tk.Canvas(side_menu, bg="#353b48", highlightthickness=0)
scrollbar = tk.Scrollbar(side_menu, orient="vertical", command=canvas_menu.yview)
scrollable_frame = tk.Frame(canvas_menu, bg="#353b48")
scrollable_frame.bind("<Configure>", lambda e: canvas_menu.configure(scrollregion=canvas_menu.bbox("all")))
canvas_menu.create_window((0, 0), window=scrollable_frame, anchor="nw", width=MENU_WIDTH)
canvas_menu.configure(yscrollcommand=scrollbar.set)
canvas_menu.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# Lọc thuật toán
def filter_algorithms(*args):
    query = search_var.get().lower()
    if query == "🔍 tìm kiếm...": return
    for btn, name in algo_buttons:
        if query in name.lower():
            btn.pack(fill="x", padx=15, pady=6)
        else:
            btn.pack_forget()
search_var.trace("w", filter_algorithms)

# Hiệu ứng trượt
def slide_in(x=-MENU_WIDTH):
    if x < 0:
        side_menu.place(x=x, y=65)
        root.after(3, lambda: slide_in(x + 40))
    else:
        side_menu.place(x=0, y=65)

def slide_out(x=0):
    if x > -MENU_WIDTH:
        side_menu.place(x=x, y=65)
        root.after(3, lambda: slide_out(x - 40))
    else:
        side_menu.place(x=-MENU_WIDTH, y=65)

def toggle_menu():
    global menu_visible
    if menu_visible: slide_out()
    else: slide_in()
    menu_visible = not menu_visible

# =========================================================
# GLOBAL CONTROLS (SPEED / PAUSE) - TOP BAR
# =========================================================
tk.Button(top_bar, text="☰ CHỌN THUẬT TOÁN", font=("Segoe UI", 11, "bold"), bg="#e84118", fg="white", bd=0, padx=20, activebackground="#c23616", activeforeground="white", command=toggle_menu).pack(side="left", fill="y")
tk.Label(top_bar, text="🤖 AI ALGORITHMS VISUALIZER", bg="#2f3640", fg="#f5f6fa", font=("Segoe UI Black", 14)).pack(side="left", padx=15)

# Control Frame trên Top Bar
control_frame = tk.Frame(top_bar, bg="#2f3640")
control_frame.pack(side="right", padx=20, fill="y", pady=10)

def toggle_pause():
    center_frame.is_paused = not center_frame.is_paused
    btn_pause.config(text="▶ RESUME" if center_frame.is_paused else "⏸ PAUSE", bg="#fbc531" if center_frame.is_paused else "#718093")

btn_pause = tk.Button(control_frame, text="⏸ PAUSE", bg="#718093", fg="white", font=("Segoe UI", 9, "bold"), relief="flat", command=toggle_pause, padx=10)
btn_pause.pack(side="right", padx=10)

def update_speed(val):
    # val từ 0.1 đến 3.0
    center_frame.speed_multiplier = float(val)
    lbl_speed.config(text=f"Speed: {float(val):.1f}x")

lbl_speed = tk.Label(control_frame, text="Speed: 1.0x", bg="#2f3640", fg="#f5f6fa", font=("Segoe UI", 9, "bold"))
lbl_speed.pack(side="right", padx=5)

speed_slider = tk.Scale(control_frame, from_=0.1, to=3.0, resolution=0.1, orient="horizontal", bg="#2f3640", fg="#f5f6fa", highlightthickness=0, bd=0, command=update_speed, length=120, showvalue=0)
speed_slider.set(1.0)
speed_slider.pack(side="right", padx=5)


# =========================================================
# 4. CHẠY THUẬT TOÁN VÀ GẮN NÚT
# =========================================================
def load_source_code(name):
    code_text.delete("1.0", "end")
    file_path = algo_file_paths.get(name)
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code_text.insert("end", f.read())
        except Exception as e:
            code_text.insert("end", f"Lỗi khi đọc file:\n{e}")

def run_algo(func, btn, name):
    global active_button
    if active_button:
        active_button.config(bg="#718093", fg="#f5f6fa")
    
    btn.config(bg="#4cd137", fg="#2f3640")
    active_button = btn
    
    # Xoá rác màn hình và reset task chờ
    center_frame.clear_tasks()
    center_frame.is_paused = False
    btn_pause.config(text="⏸ PAUSE", bg="#718093")
    
    for w in center_frame.winfo_children():
        w.destroy()
    log_text.delete("1.0", "end")
    result_text.delete("1.0", "end")
    
    # Chuyển về tab LOG
    show_tab("log")
    load_source_code(name)
    
    try:
        func(center_frame, log_text, result_text, name)
    except Exception as e:
        log_text.insert("end", f"\n[!] Lỗi khi chạy thuật toán:\n{e}")
        
    toggle_menu()

for name, func in algorithms.items():
    btn = tk.Button(scrollable_frame, text=name, bg="#718093", fg="#f5f6fa", relief="flat", font=("Segoe UI", 10, "bold"), pady=12, anchor="w", padx=20, activebackground="#4cd137", activeforeground="#2f3640")
    btn.config(command=lambda f=func, b=btn, n=name: run_algo(f, b, n))
    btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#4cd137", fg="#2f3640") if b != active_button else None)
    btn.bind("<Leave>", lambda e, b=btn: b.config(bg="#718093", fg="#f5f6fa") if b != active_button else None)
    btn.pack(fill="x", padx=15, pady=6)
    algo_buttons.append((btn, name))

tk.Label(center_frame, text="✨ CHÀO MỪNG BẠN ✨\n\nVUI LÒNG BẤM NÚT ☰ ĐỂ CHỌN THUẬT TOÁN", bg="#2b2b36", fg="#7f8fa6", font=("Segoe UI", 18, "bold"), justify="center").pack(expand=True)

if not algorithms:
    tk.Label(center_frame, text="KHÔNG TÌM THẤY THUẬT TOÁN NÀO.\nHãy chắc chắn thư mục 'extracted' chứa các file python hợp lệ.", bg="#2b2b36", fg="#e84118", font=("Segoe UI", 14, "bold"), justify="center").pack()

if __name__ == "__main__":
    root.mainloop()
