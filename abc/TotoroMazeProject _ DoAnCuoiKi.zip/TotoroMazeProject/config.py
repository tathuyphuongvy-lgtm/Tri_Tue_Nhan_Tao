import pygame

# 1. Cấu hình màn hình
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800

# 2. Phối màu Ghibli
COLOR_OUTER_FRAME = (141, 110, 99)   # Màu khung gỗ sồi mộc bọc ngoài rìa
COLOR_BG_CANVAS = (215, 206, 184)   # Màu đất đá cuội cổ điển làm nền mê cung
COLOR_HEADER = (46, 64, 55)         # Xanh rừng rậm sương mù đậm (Header)
COLOR_SIDEBAR = (61, 82, 70)        # Xanh rêu mộc trầm (Sidebar & Footer)
COLOR_BUTTON = (94, 116, 103)       # Màu nút bấm gỗ trầm
COLOR_BUTTON_HOVER = (123, 148, 134)# Màu nút sáng lên khi rê chuột vào
COLOR_LOG_BOX = (245, 242, 230)     # Màu giấy da cổ kính mờ (Nền bảng Tiến trình phải)
COLOR_TEXT_DARK = (44, 53, 48)      # Màu chữ charcoal đậm dễ đọc
COLOR_TEXT_LIGHT = (245, 246, 245)  # Màu chữ trắng kem mượt

COLOR_WALL_MOSS = (41, 75, 59)      # Bụi cây khiên rậm bo tròn (Tường)
COLOR_FLOOR_STONE = (244, 241, 230) # Đường đi lát đá mịn màng
COLOR_GRID_LINE = (225, 218, 201)   # Đường kẻ lưới tiệp màu đất

# 3. Hàm tạo font (Để dùng sau khi pygame.init() ở main.py)
def get_fonts():
    return {
        "SM": pygame.font.SysFont("Segoe UI", 14),
        "MD": pygame.font.SysFont("Segoe UI", 16, bold=True),
        "LG": pygame.font.SysFont("Segoe UI", 22, bold=True)
    }