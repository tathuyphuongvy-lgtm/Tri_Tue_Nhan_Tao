# =================================================================
# FILE: main.py
# CHỨC NĂNG: Điều phối game, vẽ giao diện, và đo lường thuật toán AI
# =================================================================
import pygame
import sys
import collections 
import random
import config as cfg
from maze_engine import Maze
from assets_loader import load_game_assets

# Import các module đo lường và thuật toán
from utils.metrics import SearchMetrics, handle_algorithm_finished
from solver_manager import SolverManager

# =================================================================
# IMPORT CÁC THUẬT TOÁN
from algorithms.gr1_uninformed.bfs_Nhu import BFSAlgorithm
from algorithms.gr1_uninformed.dfs_Vy import DFSAlgorithm
from algorithms.gr1_uninformed.iddfs_Khuong import IDDFSAlgorithm
from algorithms.gr2_informed.astar_Khuong import AStarAlgorithm
from algorithms.gr2_informed.greedy_Vy import GreedyAlgorithm
from algorithms.gr2_informed.idastar_Nhu import IDAStarAlgorithm
from algorithms.gr3_local.local_beam_Vy import LocalBeamSearch
from algorithms.gr3_local.simulated_annealing_Nhu import SimulatedAnnealing
from algorithms.gr3_local.steepest_hill_Khuong import SteepestHillClimbingAlgorithm
from algorithms.gr4_complex.sensorless_Vy import SensorlessAlgorithm
from algorithms.gr4_complex.partial_observability_Khuong import PartialObservabilityAlgorithm
from algorithms.gr4_complex.nondeterministic_Nhu import Nondeterministic
from algorithms.gr5_csp.backtracking_Vy import Backtracking
from algorithms.gr5_csp.ac_3_Khuong import AC3Algorithm
from algorithms.gr5_csp.min_conflicts_Nhu import MinConflicts
from algorithms.gr6_adversarial.minimax_Nhu import MinimaxAlgorithm
from algorithms.gr6_adversarial.alpha_beta_Vy import AlphaBetaAlgorithm
from algorithms.gr6_adversarial.expectimax_Khuong import ExpectimaxAlgorithm
# =================================================================

pygame.init()
FONTS = cfg.get_fonts()

screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT))
pygame.display.set_caption("🌳 ToToRo - Mê Cung Rừng Già Ghibli 🌳")
clock = pygame.time.Clock()

solver_mgr = SolverManager()

SCENARIO = {
    "Nhóm 1": {"map": "maps/map_easy.txt", "algos": ["BFS", "DFS", "IDDFS"]},
    "Nhóm 2": {"map": "maps/map_easy.txt", "algos": ["IDA_Star", "Greedy", "A_Star"]},
    "Nhóm 3": {"map": "maps/map_easy.txt", "algos": ["Simulated_Annealing", "Local_Beam", "Steepest_Hill_Climbing"]},
    "Nhóm 4": {"map": "maps/map_complex.txt", "algos": ["Nondeterministic", "Sensorless", "Partial_Observability"]},
    "Nhóm 5": {"map": "maps/map_csp.txt", "algos": ["Min_Conflicts", "Backtracking", "AC_3"]},
    "Nhóm 6": {"map": "maps/map_adversarial.txt", "algos": ["Minimax", "Alpha_Beta", "Expectimax"]}
}

GROUP_MAPPING = {
    "Nhóm 1": "G1_Uninformed", "Nhóm 2": "G2_Informed", "Nhóm 3": "G3_LocalSearch",
    "Nhóm 4": "G4_ComplexEnv", "Nhóm 5": "G5_CSP", "Nhóm 6": "G6_Adversarial"
}

ALGORITHM_REGISTRY = {
    "BFS": BFSAlgorithm().run,
    "DFS": DFSAlgorithm().run,
    "IDDFS": IDDFSAlgorithm().run,
    "A_Star": AStarAlgorithm().run,
    "Greedy": GreedyAlgorithm().run,
    "IDA_Star": IDAStarAlgorithm().run,
    "Steepest_Hill_Climbing": SteepestHillClimbingAlgorithm().run,
    "Local_Beam": LocalBeamSearch().run,
    "Sensorless": SensorlessAlgorithm().run,
    "Simulated_Annealing": SimulatedAnnealing().run,
    "Partial_Observability": PartialObservabilityAlgorithm().run,
    "Nondeterministic": Nondeterministic().run,
    "Backtracking": Backtracking().run,
    "AC_3": AC3Algorithm().run,
    "Min_Conflicts": MinConflicts().run,
    "Minimax": MinimaxAlgorithm().run,  
    "Alpha_Beta": AlphaBetaAlgorithm().run,
    "Expectimax": ExpectimaxAlgorithm().run      
}

tracker = SearchMetrics()
scroll_y = 0  
log_item_height = 22  
is_dragging_scrollbar = False

# === FIX CHÍNH: KHỞI TẠO BIẾN TOÀN CỤC TRÁNH LỖI NAMERROR KHI LĂN CHUỘT ===
logs = ["Hệ thống đã sẵn sàng."]
total_log_height = max(1, len(logs) * log_item_height)
# ======================================================================

AVAILABLE_WIDTH = cfg.SCREEN_WIDTH - 300
AVAILABLE_HEIGHT = cfg.SCREEN_HEIGHT - 180

start_pos, end_pos = (1, 1), (15, 17)
totoro_current_pos = start_pos
scanning_pos = None  
totoro_direction = "RIGHT"
current_frame_idx = 0

totoro_move_path, path_found_list = [], []
move_counter, move_delay = 0, 5
csp_current_path = []

# Biến lưu lịch sử và quản lý thuật toán đối kháng
g6_visited_history = []
g6_game_active = True
current_running_algo = "Minimax"  

selected_group = "Nhóm 1"
enemy_frames = []          
enemy_current_frame = 0    
enemy_anim_timer = 0       
ENEMY_ANIM_SPEED = 150     

menu_open = False
sidebar_x = -320

def update_grid_layout(rows, cols):
    grid_size = int(min(AVAILABLE_WIDTH // cols, AVAILABLE_HEIGHT // rows) * 0.95)
    pixel_w = cols * grid_size
    pixel_h = rows * grid_size
    offset_x = (AVAILABLE_WIDTH - pixel_w) // 2
    offset_y = 70 + (AVAILABLE_HEIGHT - pixel_h) // 2
    return grid_size, pixel_w, pixel_h, offset_x, offset_y

def load_scenario_map(group_name):
    global maze, MAZE_ROWS, MAZE_COLS, maze_data
    global GRID_SIZE, MAZE_PIXEL_WIDTH, MAZE_PIXEL_HEIGHT, maze_offset_x, maze_offset_y
    global assets, start_door_img, end_door_img, footprint_img, totoro_frames_ngang, totoro_frames_doc
    global key_img, lock_img, enemy_frames
    global totoro_current_pos, totoro_move_path, path_found_list, final_path_str
    global csp_current_path, start_pos, end_pos, g6_visited_history, g6_game_active
    
    try:
        map_path = SCENARIO[group_name]["map"]
        maze = Maze(map_path)
        MAZE_ROWS, MAZE_COLS = maze.rows, maze.cols
        maze_data = maze.data
        
        s_pos, g_pos = maze.get_start_goal()
        if s_pos: start_pos = s_pos
        if g_pos: end_pos = g_pos
        
        GRID_SIZE, MAZE_PIXEL_WIDTH, MAZE_PIXEL_HEIGHT, maze_offset_x, maze_offset_y = update_grid_layout(MAZE_ROWS, MAZE_COLS)
        
        assets = load_game_assets(GRID_SIZE)
        start_door_img = assets.get("start_door")
        end_door_img = assets.get("end_door")
        footprint_img = assets.get("footprint")
        key_img = assets.get("key")
        lock_img = assets.get("lock")
        totoro_frames_ngang = assets.get("totoro_ngang", [])
        totoro_frames_doc = assets.get("totoro_doc", [])
        enemy_frames = assets.get("enemy", [])
        
        if hasattr(solver_mgr, "has_key"):
            solver_mgr.has_key = False
            
        totoro_current_pos = extract_pure_coordinate(start_pos) or (1, 1)
        totoro_move_path.clear()
        path_found_list.clear()
        csp_current_path.clear()
        g6_visited_history = [totoro_current_pos]
        g6_game_active = True
        final_path_str = "Đang chờ chọn thuật toán..."
        return True
    except Exception as e:
        print(f"Lỗi khi nạp cấu hình {group_name}: {e}")
        return False

def draw_text_wrapped(surface, text, font, color, x, y, max_width):
    nodes = text.split(' -> ')
    curr_x, curr_y = x, y
    for i, node in enumerate(nodes):
        display_text = node if i == len(nodes) - 1 else node + " ->"
        node_surface = font.render(display_text, True, color)
        if curr_x + node_surface.get_width() >= x + max_width:
            curr_x = x; curr_y += font.get_height()
        surface.blit(node_surface, (curr_x, curr_y))
        curr_x += node_surface.get_width() + 10

def extract_pure_coordinate(node):
    if isinstance(node, (list, tuple)):
        if len(node) >= 2 and isinstance(node[0], (int, float)): return (int(node[0]), int(node[1]))
        elif len(node) > 0: return extract_pure_coordinate(node[0])
    if isinstance(node, dict):
        for key in ['pos', 'current', 'curr']:
            if key in node: return extract_pure_coordinate(node[key])
    return None

load_scenario_map(selected_group) 

# =================================================================
# GAME LOOP
# =================================================================
running = True
while running:
    dt = clock.tick(30) 
    mx, my = pygame.mouse.get_pos() 

    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            running = False
            
        elif event.type == pygame.MOUSEWHEEL:
            total_log_height = max(1, len(logs) * log_item_height)
            scroll_y = max(0, min(scroll_y - event.y * 30, total_log_height - 560))
            
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                mx, my = event.pos
                scroll_area_h = 560
                total_log_height = max(1, len(logs) * log_item_height)
                bar_height = max(40, (scroll_area_h / max(scroll_area_h, total_log_height)) * scroll_area_h)
                bar_y = 110 + (scroll_y / (total_log_height - scroll_area_h) * (scroll_area_h - bar_height)) if total_log_height > scroll_area_h else 110

                if (cfg.SCREEN_WIDTH - 20 <= mx <= cfg.SCREEN_WIDTH) and (bar_y <= my <= bar_y + bar_height):
                    is_dragging_scrollbar = True
                if 15 < mx < 60 and 15 < my < 55: 
                    menu_open = not menu_open
                
                if menu_open:
                    for i, (g_name, data) in enumerate(SCENARIO.items()):
                        if pygame.Rect(30, 90 + i * 105, 260, 35).move(sidebar_x, 0).collidepoint(mx, my):
                            selected_group = g_name
                            load_scenario_map(selected_group)
                            logs.append(f"Đã nạp thành công map: {SCENARIO[selected_group]['map']}")
                        
                        for j, algo in enumerate(data["algos"]):
                            if pygame.Rect(40, 130 + i * 105 + j * 22, 240, 20).move(sidebar_x, 0).collidepoint(mx, my):
                                logs.append(f"Đang chạy thuật toán {algo}...")
                                load_scenario_map(selected_group)
                                
                                current_running_algo = algo 
                                totoro_current_pos = extract_pure_coordinate(start_pos) or (1, 1)   
                                totoro_direction = "RIGHT"       
                                path_found_list.clear()          
                                totoro_move_path.clear()         
                                csp_current_path.clear()
                                final_path_str = "AI đang tính toán step-by-step..." 
                                
                                selected_algo_run_func = ALGORITHM_REGISTRY.get(algo)
                                
                                if selected_algo_run_func:
                                    # =============================================================
                                    # 🎯 ĐO THỜI GIAN THẬT 100% CỦA CPU TẠI ĐÂY (KHÔNG ÉP SỐ)
                                    # =============================================================
                                    import time
                                    # 1. Tạo một instance generator chạy ngầm độc lập
                                    test_generator = selected_algo_run_func(maze, totoro_current_pos, end_pos, debug_mode=False)
                                    
                                    # 2. Bấm giờ và ép generator chạy cạn kiệt lập tức bằng vòng lặp while để đo thời gian CPU thuần túy
                                    cpu_start = time.perf_counter()
                                    pure_step_data = None
                                    try:
                                        while True:
                                            pure_step_data = next(test_generator)
                                    except StopIteration:
                                        pass
                                    except Exception as e:
                                        # Hứng gói tin return 'finished' của Python Generator qua thuộc tính .value
                                        if hasattr(e, 'value') and isinstance(e.value, dict) and e.value.get("type") == "finished":
                                            pure_step_data = e.value
                                    cpu_end = time.perf_counter()
                                    
                                    # 3. Tính thời gian CPU thực tế (ms)
                                    real_cpu_time_ms = (cpu_end - cpu_start) * 1000
                                    
                                    # 4. Lưu con số THẬT này vào một biến tạm trên tracker để tí nữa khối 'finished' bốc ra dùng
                                    tracker.latest_pure_cpu_time = round(real_cpu_time_ms, 6)
                                    # =============================================================
                                    
                                    # Khởi động bộ quản lý solver_mgr để chạy đồ họa step-by-step như bình thường
                                    solver_mgr.start(selected_algo_run_func, maze, totoro_current_pos, end_pos, debug_mode=True)
                                    csp_current_path = [] 
                                else:
                                    logs.append(f"⚠️ Chưa tích hợp code của thuật toán: {algo}!")
                                menu_open = False

        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1: is_dragging_scrollbar = False

    # -----------------------------------------------------------------
    # PHẦN 3.2: CẬP NHẬT LOGIC GAME (BƯỚC ĐI REAL-TIME QUA TỪNG FRAME)
    # -----------------------------------------------------------------
    step_data = solver_mgr.update() 
    if step_data:
        if step_data["type"] == "log":
            logs.extend(step_data["data"])
            scanning_pos = step_data.get("curr", step_data.get("current"))
            
            # CHỈ NHÓM 5 MỚI NHẬN MẢNG ĐƯỜNG XANH DƯƠNG THÔ ĐỂ VẼ
            if selected_group == "Nhóm 5" and "csp_path" in step_data:
                csp_current_path = step_data["csp_path"]
            
            total_log_height = max(1, len(logs) * log_item_height)
            scroll_y = max(0, total_log_height - 560)
            
        elif step_data["type"] == "finished": 
            scanning_pos = None
            path_found = step_data.get("path")
            
            if hasattr(path_found, '__iter__') and not isinstance(path_found, (list, tuple, str)):
                path_found = list(path_found)

            # CHỈNH SỬA 2: Nạp trực tiếp logs đóng khung từ gói tin trả về của Algorithm vào UI Log Pygame
            if "logs" in step_data:
                logs.extend(step_data["logs"])

            current_group_id = GROUP_MAPPING.get(selected_group, "G1_Uninformed")
            current_algo_name = current_running_algo.replace("*", "_Star").replace(" ", "_").replace("-", "_")

            # =================================================================
            # XỬ LÝ KHỐI REAL-TIME CHO CẢ 3 THUẬT TOÁN NHÓM 6 (ĐỐI KHÁNG REAL-TIME)
            # =================================================================
            if selected_group == "Nhóm 6":
                if g6_game_active:
                    if path_found and len(path_found) > 1:
                        next_pos = extract_pure_coordinate(path_found[1]) or path_found[1]
                        
                        # -------------------------------------------------------------
                        # KỊCH BẢN 1: PHÁT HIỆN VÒNG LẶP VÔ HẠN (KET LOOP)
                        # -------------------------------------------------------------
                        if g6_visited_history.count(next_pos) > 3:
                            logs.append(f"⚠️ {current_running_algo} phát hiện vòng lặp vô hạn! Dừng trận.")
                            final_path_str = "GAME OVER - Bị kẹt lặp vô hạn giữa các ô! ❌"
                            g6_game_active = False
                            
                            extra_m = {"ly_do": "Vong_Lap_Vo_Han"}
                            if hasattr(tracker, "latest_pure_cpu_time"): 
                                extra_m["execution_time"] = tracker.latest_pure_cpu_time
                            
                            # ĐỒNG BỘ: Ghi nhận trạng thái kẹt lặp và xuất CSV
                            handle_algorithm_finished(tracker, current_group_id, current_algo_name, {
                                "path": None, 
                                "reached": g6_visited_history, 
                                "metrics": extra_m
                            })
                            tracker.export_to_flat_csv()
                        else:
                            # ... (Logic di chuyển của Totoro và Quái Vật) ...
                            curr_r, curr_c = totoro_current_pos
                            next_r, next_c = next_pos
                            footprint_angle = 0
                            if next_c > curr_c: totoro_direction, footprint_angle = "RIGHT", 270
                            elif next_c < curr_c: totoro_direction, footprint_angle = "LEFT", 90
                            elif next_r > curr_r: totoro_direction, footprint_angle = "DOWN", 180
                            elif next_r < curr_r: totoro_direction, footprint_angle = "UP", 0
                            
                            path_found_list.append((curr_r, curr_c, footprint_angle))
                            totoro_current_pos = next_pos
                            g6_visited_history.append(totoro_current_pos)
                            logs.append(f"🤖 Totoro di chuyển đến ô: {totoro_current_pos}")
                            
                            # Quái vật tính toán đuổi theo
                            enemy_positions = [ (r, c) for r in range(MAZE_ROWS) for c in range(MAZE_COLS) if maze_data[r][c] == 8 ]
                            for enemy_pos in enemy_positions:
                                m_neighbors = maze.get_neighbors(enemy_pos)
                                best_move = enemy_pos
                                if m_neighbors:
                                    min_dist = float('inf')
                                    best_moves_list = []
                                    for n_node in m_neighbors:
                                        n_pos = extract_pure_coordinate(n_node) or n_node.get('pos') if isinstance(n_node, dict) else n_node
                                        if maze_data[n_pos[0]][n_pos[1]] == 0 or n_pos == totoro_current_pos:
                                            dist = abs(n_pos[0] - totoro_current_pos[0]) + abs(n_pos[1] - totoro_current_pos[1])
                                            if dist < min_dist:
                                                min_dist = dist
                                                best_moves_list = [n_pos]
                                            elif dist == min_dist:
                                                best_moves_list.append(n_pos)
                                    if best_moves_list:
                                        best_move = random.choice(best_moves_list)
                                    if best_move != enemy_pos:
                                        maze_data[enemy_pos[0]][enemy_pos[1]] = 0
                                        maze_data[best_move[0]][best_move[1]] = 8
                                        logs.append(f"💀 Quái vật đuổi theo sang ô: {best_move}")
                            
                            # -------------------------------------------------------------
                            # KỊCH BẢN 2: TOTORO VỀ ĐÍCH AN TOÀN (CHIẾN THẮNG)
                            # -------------------------------------------------------------
                            if totoro_current_pos == (extract_pure_coordinate(end_pos) or (15, 17)):
                                logs.append("🎉 THÀNH CÔNG: Totoro đã an toàn về đích!")
                                final_path_str = f"VICTORY - {current_running_algo} đã thắng quái vật! 🏆"
                                g6_game_active = False
                                
                                extra_m = {"outcome": "Victory"}
                                if hasattr(tracker, "latest_pure_cpu_time"): 
                                    extra_m["execution_time"] = tracker.latest_pure_cpu_time
                                
                                # ĐỒNG BỘ: Ghi nhận đường đi chiến thắng và xuất CSV
                                handle_algorithm_finished(tracker, current_group_id, current_algo_name, {
                                    "path": g6_visited_history, 
                                    "reached": g6_visited_history, 
                                    "metrics": extra_m
                                })
                                tracker.export_to_flat_csv()

                            # -------------------------------------------------------------
                            # KỊCH BẢN 3: BỊ QUÁI VẬT TÓM GỌN (THUA CUỘC)
                            # -------------------------------------------------------------
                            elif totoro_current_pos in enemy_positions or maze_data[totoro_current_pos[0]][totoro_current_pos[1]] == 8:
                                logs.append("💀 GAME OVER: Bạn đã bị Quái vật tóm gọn!")
                                final_path_str = "GAME OVER - Thua cuộc ❌"
                                g6_game_active = False
                                
                                extra_m = {"outcome": "Caught_By_Monster"}
                                if hasattr(tracker, "latest_pure_cpu_time"): 
                                    extra_m["execution_time"] = tracker.latest_pure_cpu_time
                                
                                # ĐỒNG BỘ: Ghi nhận thất bại và xuất CSV
                                handle_algorithm_finished(tracker, current_group_id, current_algo_name, {
                                    "path": None, 
                                    "reached": g6_visited_history, 
                                    "metrics": extra_m
                                })
                                tracker.export_to_flat_csv()
                                
                            # Nếu chưa kết thúc, tiếp tục gọi thuật toán tính frame tiếp theo
                            else:
                                selected_algo_run_func = ALGORITHM_REGISTRY.get(current_running_algo, MinimaxAlgorithm().run)
                                solver_mgr.start(selected_algo_run_func, maze, totoro_current_pos, end_pos, debug_mode=True)
                    
                    # -------------------------------------------------------------
                    # KỊCH BẢN 4: THUẬT TOÁN KHÔNG TÌM ĐƯỢC ĐƯỜNG ĐI AN TOÀN
                    # -------------------------------------------------------------
                    else:
                        if totoro_current_pos == (extract_pure_coordinate(end_pos) or (15, 17)):
                            final_path_str = f"VICTORY - {current_running_algo} bảo toàn mạng sống về đích! 🏆"
                        else:
                            final_path_str = "Không tìm thấy đường đi an toàn!"
                        g6_game_active = False

                        extra_m = {"outcome": "No_Safe_Path"}
                        if hasattr(tracker, "latest_pure_cpu_time"): 
                            extra_m["execution_time"] = tracker.latest_pure_cpu_time
                        
                        # ĐỒNG BỘ: Ghi nhận không tìm thấy đường đi và xuất CSV
                        handle_algorithm_finished(tracker, current_group_id, current_algo_name, {
                            "path": None, 
                            "reached": g6_visited_history, 
                            "metrics": extra_m
                        })
                        tracker.export_to_flat_csv()

            # =================================================================
            # XỬ LÝ ĐỒNG BỘ CHO TẤT CẢ CÁC NHÓM CÒN LẠI (NHÓM 1, 2, 3, 4, 5)
            # =================================================================
            else:
                csp_current_path.clear()
                reached_nodes = step_data.get("reached", [])
                raw_metrics = step_data.get("metrics", {}) # Đã chứa execution_time thực tế của CPU bên trong
                
                # BỐC CON SỐ THỜI GIAN THẬT ĐÃ ĐO NGẦM ĐÈ LÊN BIẾN LƯU EXCEL
                if hasattr(tracker, "latest_pure_cpu_time"):
                    raw_metrics["execution_time"] = tracker.latest_pure_cpu_time
                else:
                    raw_metrics["execution_time"] = 0.01 # Tránh lỗi nếu biến chưa khởi tạo
                    
                if path_found and len(path_found) > 0:
                    wall_errors = 0
                    for idx in range(1, len(path_found)):
                        p_prev = path_found[idx-1]
                        p_curr = path_found[idx]
                        if maze_data[p_curr[0]][p_curr[1]] == 1 or (abs(p_curr[0]-p_prev[0]) + abs(p_curr[1]-p_prev[1]) != 1):
                            wall_errors += 1
                    
                    if selected_group == "Nhóm 5" and wall_errors > 0:
                        logs.append(f"❌ THẤT BẠI: Thuật toán dừng lại với {wall_errors} lỗi chưa giải quyết.")
                        final_path_str = "THẤT BẠI: Không tìm thấy lời giải hợp lệ! ❌"
                        totoro_current_pos = extract_pure_coordinate(start_pos) or (1, 1)
                        totoro_move_path.clear()
                        path_found_list.clear()
                        
                        # Gọi hàm xử lý tập trung từ metrics.py: tự động bốc logs cho Pygame và ghi đè thời gian CPU sạch
                        handle_algorithm_finished(tracker, current_group_id, current_algo_name, {"path": None, "reached": reached_nodes, "metrics": raw_metrics, "logs": step_data.get("logs", [])})
                        tracker.export_to_flat_csv()
                    else:
                        logs.append("Thành công: Đã tìm thấy đường đi hoàn chỉnh!")
                        final_path_str = " -> ".join([str(p) for p in path_found])
                        totoro_current_pos = extract_pure_coordinate(start_pos) or (1, 1)
                        path_found_list.clear() 
                        totoro_move_path = list(path_found)
                        
                        # Truyền trọn vẹn step_data vào hàm bọc xử lý tập trung
                        handle_algorithm_finished(tracker, current_group_id, current_algo_name, step_data)
                        tracker.export_to_flat_csv()
                else:
                    logs.append("❌ THẤT BẠI: Thuật toán không tìm ra đường đi!")
                    final_path_str = "THẤT BẠI: Lời giải trống! ❌"
                    totoro_current_pos = extract_pure_coordinate(start_pos) or (1, 1)
                    totoro_move_path.clear()
                    path_found_list.clear()
                    
                    # Gọi hàm xử lý tập trung cho trường hợp không tìm thấy đường
                    handle_algorithm_finished(tracker, current_group_id, current_algo_name, {"path": None, "reached": reached_nodes, "metrics": raw_metrics, "logs": step_data.get("logs", [])})
                    tracker.export_to_flat_csv()
                    
            total_log_height = max(1, len(logs) * log_item_height)
            scroll_y = max(0, total_log_height - 560)
            
    # Cập nhật khung hình hoạt ảnh quái vật
    if selected_group == "Nhóm 6" and enemy_frames:
        enemy_anim_timer += dt
        if enemy_anim_timer >= ENEMY_ANIM_SPEED:
            enemy_anim_timer = 0
            enemy_current_frame = (enemy_current_frame + 1) % len(enemy_frames)

    # -----------------------------------------------------------------
    # PHẦN 3.3: VẼ GIAO DIỆN (RENDER)
    # -----------------------------------------------------------------
    screen.fill(cfg.COLOR_OUTER_FRAME)  
    pygame.draw.rect(screen, cfg.COLOR_BG_CANVAS, (0, 70, cfg.SCREEN_WIDTH - 300, 620))

    bg_maze_rect = pygame.Rect(maze_offset_x - 6, maze_offset_y - 6, MAZE_PIXEL_WIDTH + 12, MAZE_PIXEL_HEIGHT + 12)
    pygame.draw.rect(screen, (185, 175, 150), bg_maze_rect, border_radius=10)

    for r in range(MAZE_ROWS):
        for c in range(MAZE_COLS):
            cell_data = maze_data[r][c]
            rect = pygame.Rect(maze_offset_x + c * GRID_SIZE, maze_offset_y + r * GRID_SIZE, GRID_SIZE, GRID_SIZE)
            
            if cell_data == 1:
                pygame.draw.rect(screen, cfg.COLOR_WALL_MOSS, rect, border_radius=4)
                continue  
            
            pygame.draw.rect(screen, cfg.COLOR_FLOOR_STONE, rect)
            if csp_current_path and (r, c) in csp_current_path and (r, c) != extract_pure_coordinate(start_pos) and (r, c) != extract_pure_coordinate(end_pos):
                pygame.draw.rect(screen, (52, 152, 219), rect)
            
            # Ô MÀU CAM QUÉT DUYỆT CÂY XUẤT HIỆN LẠI TRÊN MÀN HÌNH CHỚP TẮT
            clean_scan = extract_pure_coordinate(scanning_pos)
            if clean_scan == (r, c):
                pygame.draw.rect(screen, (241, 196, 15), rect)
            
            elif cell_data == 4: pygame.draw.rect(screen, (160, 120, 90), rect)
            elif cell_data == 5: pygame.draw.rect(screen, (120, 120, 120), rect)
            elif cell_data == 6:
                if key_img: screen.blit(key_img, key_img.get_rect(center=rect.center).topleft)
            elif cell_data == 7:
                if not getattr(solver_mgr, "has_key", False):
                    if lock_img: screen.blit(lock_img, lock_img.get_rect(center=rect.center).topleft)
            elif selected_group == "Nhóm 6" and cell_data == 8:
                if enemy_frames:
                    curr_enemy_img = enemy_frames[enemy_current_frame]
                    screen.blit(curr_enemy_img, curr_enemy_img.get_rect(center=rect.center).topleft)
            
            pygame.draw.rect(screen, cfg.COLOR_GRID_LINE, rect, 1)
            
            if (r, c) == extract_pure_coordinate(start_pos) or cell_data == 2:
                if start_door_img: screen.blit(start_door_img, start_door_img.get_rect(center=rect.center).topleft)
            elif (r, c) == extract_pure_coordinate(end_pos) or cell_data == 3:
                if end_door_img: screen.blit(end_door_img, end_door_img.get_rect(center=rect.center).topleft)

            if (r, c) != extract_pure_coordinate(start_pos) and (r, c) != extract_pure_coordinate(end_pos):
                step_info = next((item for item in path_found_list if item[0] == r and item[1] == c), None)
                if step_info and (r, c) != totoro_current_pos:
                    if footprint_img:
                        rotated_footprint = pygame.transform.rotate(footprint_img, step_info[2])
                        screen.blit(rotated_footprint, rotated_footprint.get_rect(center=rect.center).topleft)
            
    # Di chuyển tĩnh dành riêng cho Nhóm 1-5
    if totoro_move_path and selected_group != "Nhóm 6":
        move_counter += 1
        if move_counter >= move_delay:
            next_raw_pos = totoro_move_path.pop(0)
            next_pos = extract_pure_coordinate(next_raw_pos) or next_raw_pos
            curr_r, curr_c = totoro_current_pos
            next_r, next_c = next_pos
            footprint_angle = 0
            if next_c > curr_c: totoro_direction, footprint_angle = "RIGHT", 270
            elif next_c < curr_c: totoro_direction, footprint_angle = "LEFT", 90
            elif next_r > curr_r: totoro_direction, footprint_angle = "DOWN", 180
            elif next_r < curr_r: totoro_direction, footprint_angle = "UP", 0
            path_found_list.append((curr_r, curr_c, footprint_angle))
            totoro_current_pos = next_pos
            move_counter = 0
                    
    active_frames = totoro_frames_ngang if totoro_direction in ["RIGHT", "LEFT"] else (totoro_frames_doc if totoro_frames_doc else totoro_frames_ngang)
    rect_current = pygame.Rect(maze_offset_x + totoro_current_pos[1]*GRID_SIZE, maze_offset_y + totoro_current_pos[0]*GRID_SIZE, GRID_SIZE, GRID_SIZE)
    if active_frames:
        current_frame_idx = (current_frame_idx + 1) % len(active_frames) if (totoro_move_path or selected_group == "Nhóm 6") else 0 
        totoro_img = active_frames[current_frame_idx]
        if totoro_direction == "LEFT": totoro_img = pygame.transform.flip(totoro_img, True, False)
        elif totoro_direction == "UP" and totoro_frames_doc: totoro_img = pygame.transform.flip(totoro_img, False, True)
        screen.blit(totoro_img, (rect_current.centerx - totoro_img.get_width()//2, rect_current.centery - totoro_img.get_height()//2))

    # Giao diện Sidebar & Log Box
    pygame.draw.rect(screen, cfg.COLOR_HEADER, (0, 0, cfg.SCREEN_WIDTH, 70))
    screen.blit(FONTS["LG"].render("Mê Cung Totoro - Thử Nghiệm Mô Hình Tìm Kiếm AI", True, cfg.COLOR_TEXT_LIGHT), (70, 20))

    log_box_width = 300 
    pygame.draw.rect(screen, cfg.COLOR_LOG_BOX, (cfg.SCREEN_WIDTH - log_box_width, 70, log_box_width, 620))
    pygame.draw.line(screen, (190, 195, 180), (cfg.SCREEN_WIDTH - log_box_width, 70), (cfg.SCREEN_WIDTH - log_box_width, 690), 2)
    screen.blit(FONTS["MD"].render("⚡ Tiến trình AI:", True, cfg.COLOR_TEXT_DARK), (cfg.SCREEN_WIDTH - log_box_width + 15, 88))

    total_log_height = max(1, len(logs) * log_item_height)
    scroll_area_h = 560
    bar_height = max(40, (scroll_area_h / max(scroll_area_h, total_log_height)) * scroll_area_h)
    
    if is_dragging_scrollbar:
        relative_y = my - 110 - (bar_height / 2)
        max_scroll_dist = scroll_area_h - bar_height
        if max_scroll_dist > 0:
            scroll_ratio = max(0.0, min(1.0, relative_y / max_scroll_dist))
            scroll_y = scroll_ratio * (total_log_height - scroll_area_h)

    bar_y = 110 + (scroll_y / (total_log_height - scroll_area_h) * (scroll_area_h - bar_height)) if total_log_height > scroll_area_h else 110
    scrollbar_color = (120, 120, 120) if is_dragging_scrollbar else (170, 170, 170)
    pygame.draw.rect(screen, scrollbar_color, (cfg.SCREEN_WIDTH - 12, bar_y, 8, bar_height), border_radius=4)

    clip_area = pygame.Rect(cfg.SCREEN_WIDTH - log_box_width + 5, 110, log_box_width - 15, 560)
    screen.set_clip(clip_area) 
    for i, entry in enumerate(logs):
        y_pos = 118 + (i * log_item_height) - scroll_y
        if 110 <= y_pos <= 670:
            screen.blit(FONTS["SM"].render(entry, True, (80, 90, 85)), (cfg.SCREEN_WIDTH - log_box_width + 10, y_pos))
    screen.set_clip(None)

    pygame.draw.rect(screen, cfg.COLOR_SIDEBAR, (0, 690, cfg.SCREEN_WIDTH, 110))
    screen.blit(FONTS["MD"].render("🚩 TRẠNG THÁI TRẬN ĐẤU (ADVERSARIAL MATCH):", True, (241, 196, 15)), (30, 708))
    draw_text_wrapped(screen, final_path_str, FONTS["SM"], (255, 225, 160), 30, 740, cfg.SCREEN_WIDTH - 60)

    for i in range(3): pygame.draw.rect(screen, cfg.COLOR_TEXT_LIGHT, (25, 27 + i*8, 22, 3), border_radius=1)

    target_sidebar_x = 0 if menu_open else -320
    sidebar_x += (target_sidebar_x - sidebar_x) * 0.25
    if sidebar_x > -320:
        pygame.draw.rect(screen, cfg.COLOR_SIDEBAR, (sidebar_x, 70, 320, 730))
        for i, (g_name, data) in enumerate(SCENARIO.items()):
            btn_rect = pygame.Rect(30, 90 + i * 105, 260, 35)
            pygame.draw.rect(screen, (100, 150, 100) if selected_group == g_name else cfg.COLOR_BUTTON, btn_rect.move(sidebar_x, 0), border_radius=5)
            screen.blit(FONTS["SM"].render(g_name, True, (255, 255, 255)), (sidebar_x + 40, 98 + i * 105))
            if selected_group == g_name:
                for j, algo in enumerate(data["algos"]):
                    sub_rect = pygame.Rect(40, 130 + i * 105 + j * 22, 240, 20)
                    pygame.draw.rect(screen, (220, 220, 220), sub_rect.move(sidebar_x, 0), border_radius=3)
                    screen.blit(FONTS["SM"].render(algo, True, (0, 0, 0)), (sidebar_x + 50, 132 + i * 105 + j * 22))

    pygame.display.flip()

pygame.quit()
sys.exit()