# =================================================================
# FILE: metrics.py
# CHỨC NĂNG: Đo lường thời gian, số node duyệt, độ dài đường đi
#            và xuất báo cáo dữ liệu phẳng ra file Excel (CSV).
# =================================================================

import time
import json
import csv

class SearchMetrics:
    def __init__(self):
        # Khởi tạo từ điển lưu trữ 6 nhóm - 18 thuật toán.
        self.data = {
            "G1_Uninformed": {"BFS": [], "DFS": [], "IDDFS": []},
            "G2_Informed": {"IDA_Star": [], "Greedy": [], "A_Star": []},
            "G3_LocalSearch": {"Simulated_Annealing": [], "Local_Beam": [], "Steepest_Hill_Climbing": []},
            "G4_ComplexEnv": {"Nondeterministic": [], "Sensorless": [], "Partial_Observability": []},
            "G5_CSP": {"Min_Conflicts": [], "Backtracking": [], "AC_3": []},
            "G6_Adversarial": {"Minimax": [], "Alpha_Beta": [], "Expectimax": []}
        }
        self.start_time = 0

    def start_timer(self):
        """Bắt đầu bấm giờ ngay trước khi thuật toán bắt đầu bước chạy đầu tiên."""
        self.start_time = time.perf_counter()

    def stop_timer_and_save(self, group_name, algo_name, path, reached, extra_metrics=None, max_runs=10):
        """
        Dừng bấm giờ, tính toán thời gian thực tế và nạp dữ liệu sạch vào hệ thống.
        """
        end_time = time.perf_counter()
        elapsed_time_ms = (end_time - self.start_time) * 1000  # Đo tổng thời gian (gồm cả đồ họa)
        
        # ƯU TIÊN SỐ 1: Bốc thời gian thực thi của CPU nếu thuật toán con có truyền lên
        if extra_metrics and "execution_time" in extra_metrics:
            elapsed_time_ms = extra_metrics["execution_time"]
            
        if group_name in self.data and algo_name in self.data[group_name]:
            runs_list = self.data[group_name][algo_name]
            
            # Gom số liệu cơ bản
            run_result = {
                "nodes_explored": len(reached) if reached else 0,
                "path_length": len(path) - 1 if path else 0,
                "execution_time": round(elapsed_time_ms, 6) # Đóng đinh thời gian thô của CPU
            }
            
            # Nạp các thông số mở rộng khác (do_sau_tim_thay...) trừ các trường core
            if extra_metrics:
                for key, val in extra_metrics.items():
                    if key not in ["steps", "length", "execution_time"]:
                        run_result[key] = val
            
            runs_list.append(run_result)
            if len(runs_list) > max_runs:
                runs_list.pop(0)
                
            for i, run in enumerate(runs_list):
                run["run_index"] = i + 1
                
            current_index = runs_list[-1]["run_index"]
            print(f"[Saved Run #{current_index}/{max_runs}] {group_name} -> {algo_name}: "
                  f"Nodes={run_result['nodes_explored']}, Path={run_result['path_length']}, Time={elapsed_time_ms:.6f}ms")
            
            return run_result
        return None

    def export_to_json(self, file_path="metrics_report.json"):
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=4)
            print(f"ĐÃ LƯU CẤU TRÚC GỐC VÀO: {file_path}")
        except Exception as e:
            print(f"Lỗi khi ghi file JSON: {e}")

    def export_to_flat_csv(self, file_path="metrics_comparisons.csv"):
        try:
            with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Run Index", "Group Name", "Algorithm", 
                    "Status", "Nodes Explored (Space)", "Path Length (Cost)", 
                    "Execution Time (ms)", "Extra Details"
                ])
                
                for group_name, algos in self.data.items():
                    for algo_name, runs in algos.items():
                        for run in runs:
                            status = "SUCCESS" if run.get("path_length", 0) > 0 else "FAILED"
                            
                            extra_info = []
                            for k, v in run.items():
                                if k not in ["run_index", "nodes_explored", "path_length", "execution_time"]:
                                    extra_info.append(f"{k}={v}")
                            extra_str = " | ".join(extra_info) if extra_info else "None"
                            
                            writer.writerow([
                                run.get("run_index"),
                                group_name,
                                algo_name,
                                status,
                                run.get("nodes_explored", 0),
                                run.get("path_length", 0),
                                run.get("execution_time", 0),
                                extra_str
                            ])
                            
            print(f"📈 ĐÃ XUẤT BẢNG SO SÁNH 18 THUẬT TOÁN RA FILE EXCEL/CSV: {file_path}")
        except Exception as e:
            print(f"Lỗi khi xuất bảng biểu CSV: {e}")


# =================================================================
# HÀM XỬ LÝ KHI KẾT THÚC GENERATOR (GỌI TRONG MAIN.PY)
# =================================================================

def handle_algorithm_finished(metrics_obj, group_name, algo_name, finished_msg):
    path = finished_msg.get("path")
    reached = finished_msg.get("reached")
    raw_metrics = finished_msg.get("metrics", {})
    
    # 1. Truyền toàn bộ raw_metrics chứa trường execution_time của CPU vào đây để ghi đè
    latest_run = metrics_obj.stop_timer_and_save(group_name, algo_name, path, reached, extra_metrics=raw_metrics)
    
    # 2. In log đóng khung ra Terminal
    if "logs" in finished_msg:
        for line in finished_msg["logs"]:
            print(line)
            
    if latest_run:
        print(f"--> Số liệu thô: Thời gian chạy thực tế = {latest_run['execution_time']:.6f} ms\n")