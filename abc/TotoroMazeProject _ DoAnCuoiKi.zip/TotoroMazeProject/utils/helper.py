# =================================================================
# FILE: helper.py
# CHỨC NĂNG: Cung cấp hàm toán học hỗ trợ tính toán Heuristic h(n)
# =================================================================

def heuristic_manhattan(pos_current, pos_goal):
    """
    [HEURISTIC CHÍNH CHO BẢN ĐỒ LƯỚI] Tính khoảng cách Manhattan.
    Công thức: h(n) = |x1 - x2| + |y1 - y2|
    
    Cách các nhóm bóc tách dùng:
    - Nhóm 3 (Local Search): Lấy trực tiếp giá trị này làm h(n) để chọn ô tiếp theo.
    - Nhóm 2 (Informed Search): Lấy giá trị này làm h(n) để cộng thành f(n) = g(n) + h(n).
    """
    r1, c1 = pos_current
    r2, c2 = pos_goal
    return abs(r1 - r2) + abs(c1 - c2)