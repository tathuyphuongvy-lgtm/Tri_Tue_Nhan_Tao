# =================================================================
# FILE: assets_loader.py
# CHỨC NĂNG: Tải và chuẩn hóa tài nguyên hình ảnh (Sprites/Assets)
# =================================================================
import pygame
import os

def load_animation_from_folder(folder_path, size):
    """Tự động quét folder, lọc ảnh, sắp xếp theo số và scale theo size yêu cầu"""
    try:
        filenames = sorted(
            [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))],
            key=lambda f: int(''.join(filter(str.isdigit, f)) or 0)
        )
    except FileNotFoundError:
        print(f"❌ Không tìm thấy thư mục: {folder_path}")
        return []

    frames = []
    for filename in filenames:
        image_path = os.path.join(folder_path, filename)
        image_surf = pygame.image.load(image_path).convert_alpha()
        image_surf = pygame.transform.scale(image_surf, (size, size))
        frames.append(image_surf)
    return frames

def load_game_assets(grid_size):
    """Hàm này trả về một dictionary chứa tất cả asset đã nạp đầy đủ cho đồ án"""
    
    # 🎯 ĐỔI VỊ TRÍ LÊN ĐẦU: Tính toán kích thước hầm hố cho Enemy (bự bằng 125% ô lưới)
    enemy_size = int(grid_size * 1.25)
    
    assets = {
        "totoro_doc": load_animation_from_folder("assets/totoro_doc", grid_size - 4),
        "totoro_ngang": load_animation_from_folder("assets/totoro_ngang", grid_size - 4),
        # 🎯 SỬA TẠI ĐÂY: Truyền đúng enemy_size vào thay vì grid_size - 4 để con enemy bự lên
        "enemy" : load_animation_from_folder("assets/enemy", enemy_size),
        "footprint": None,
        "start_door": None,
        "end_door": None,
        "key": None,   
        "lock": None   
    }
    
    # Nạp ảnh tĩnh
    try:
        footprint_raw = pygame.image.load("assets/footprint.png").convert_alpha()
        assets["footprint"] = pygame.transform.scale(footprint_raw, (int(grid_size * 0.5), int(grid_size * 0.5)))
        
        door_size = int(grid_size * 0.85)
        start_img = pygame.image.load("assets/start_door.png").convert_alpha()
        assets["start_door"] = pygame.transform.scale(start_img, (door_size, door_size))
        
        end_img = pygame.image.load("assets/end_door.png").convert_alpha()
        assets["end_door"] = pygame.transform.scale(end_img, (door_size, door_size))
        
        # -------------------------------------------------------------
        # KHẮC PHỤC THIẾU CODE: Nạp hình ảnh Chìa khóa (6) và Ổ khóa (7)
        # -------------------------------------------------------------
        # Scale kích thước vật phẩm bằng khoảng 75% ô lưới nhìn cho đẹp, không bị tràn viền
        item_size = int(grid_size * 0.75) 
        
        # Nạp ảnh chìa khóa vàng
        key_raw = pygame.image.load("assets/key.png").convert_alpha()
        assets["key"] = pygame.transform.scale(key_raw, (item_size, item_size))
        
        # Nạp ảnh ổ khóa đóng
        lock_raw = pygame.image.load("assets/lock.png").convert_alpha()
        assets["lock"] = pygame.transform.scale(lock_raw, (item_size, item_size))
    
    except Exception as e:
        print(f"❌ Lỗi nạp ảnh tĩnh (Kiểm tra lại file trong thư mục assets): {e}")
        
    return assets