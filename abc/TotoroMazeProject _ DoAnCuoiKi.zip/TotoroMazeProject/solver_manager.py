# =================================================================
# FILE: algorithms/solver_manager.py
# CHỨC NĂNG: Quản lý vòng đời chạy step-by-step của các thuật toán AI
# =================================================================

class SolverManager:
    def __init__(self):
        self.generator = None

    def start(self, algo_func, *args, **kwargs):
        """
        Khởi tạo generator từ hàm chạy của thuật toán.
        CHÚ Ý: Nếu generator cũ đang chạy (đặc biệt ở Nhóm 6), KHÔNG khởi tạo đè 
        để tránh làm mất trạng thái tính toán của frame hiện tại.
        """
        # Nếu đang có một thuật toán chạy dở dang, không khởi tạo lại
        if self.generator is not None:
            return
            
        self.generator = algo_func(*args, **kwargs)

    def is_running(self):
        """Kiểm tra xem hiện tại có thuật toán nào đang tính toán hay không"""
        return self.generator is not None

    def update(self):
        """
        Được gọi mỗi frame trong Game Loop của main.py.
        Trả về kết quả của bước hiện tại hoặc cấu trúc finished chuẩn mực.
        """
        if not self.generator:
            return None
        
        try:
            # Tiến tới bước tính toán (step) tiếp theo của thuật toán
            return next(self.generator)
        except StopIteration as e:
            result = e.value
            self.generator = None # Reset về None để sẵn sàng cho lượt tính toán tiếp theo
            
            # Nếu thuật toán có return một dict có cấu trúc finished chuẩn
            if result and isinstance(result, dict) and result.get("type") == "finished":
                return result
                
            # Fallback nếu hàm run() của bạn chỉ return về (path, visited) hoặc dict thường
            if isinstance(result, dict):
                return {
                    "type": "finished",
                    "path": result.get("path"),
                    "reached": result.get("reached") or result.get("visited"),
                    "metrics": result.get("metrics")
                }
                
            return {"type": "finished", "path": None, "metrics": None}