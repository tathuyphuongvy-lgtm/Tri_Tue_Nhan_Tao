# =================================================================
# FILE: maze_engine.py
# CHỨC NĂNG: Trái tim môi trường - Quản lý ma trận, trọng số và thực thể
# =================================================================

class Maze:
    """
    Class Maze cung cấp thông tin cấu trúc lưới, môi trường đồng nhất 
    cho toàn bộ 6 nhóm thuật toán trên cả 3 loại bản đồ.
    """
    
    def __init__(self, file_path):
        # 1. Đọc và khởi tạo ma trận dữ liệu từ file cấu hình .txt
        self.data = self.load_from_txt(file_path)
        
        # Phòng chống lỗi crash hệ thống (IndexError) nếu file map bị rỗng
        if not self.data or not self.data[0]:
            raise ValueError(f"Lỗi: Bản đồ tại {file_path} không có dữ liệu hợp lệ!")
            
        self.rows = len(self.data)
        self.cols = len(self.data[0])
        
        # 2. BẢNG TRỌNG SỐ (WEIGHTS): Dùng cho Nhóm 1, 2, 3 (Không gian trạng thái - Map: easy.txt)
        # Định nghĩa chi phí di chuyển: Đường trống(1), Đầm lầy(10), Núi cao(5)
        self.weights = {
            0: 1,           # Đường đi bình thường
            1: float('inf'),# Tường ngăn cách (Chi phí vô hạn)
            2: 1,           # Điểm xuất phát (Start)
            3: 1,           # Điểm đích (Goal)
            4: 10,          # Đầm lầy (Chi phí di chuyển rất cao)
            5: 5            # Vùng núi (Chi phí di chuyển trung bình)
        } 
        
        # 3. BẢNG GIÁ TRỊ ĐIỂM SỐ (VALUES): Dùng cho Nhóm 6 (Adversarial Search - Map: adversarial.txt)
        # Điểm số Heuristic để Totoro đưa ra quyết định săn Quà (3) và tránh né Kẻ địch (8)
        self.values = {
            0: 0,           # Ô trống không có phần thưởng/nguy hiểm
            1: -999,        # Tường (Hình phạt cực nặng nếu đâm vào)
            2: 0,           # Vị trí Start
            3: 100,         # Vị trí Goal -> thắng được cộng 100
            8: -500         # Ô chứa Quái vật/Enemy (Lượng hóa điểm phạt để thuật toán trừ điểm)
        }

    def load_from_txt(self, file_path):
        """
        [HÀM ĐỌC MAP] Chuyển đổi tệp cấu hình text thành ma trận số nguyên 2 chiều (Matrix).
        Hỗ trợ phân tách dữ liệu bằng cả dấu phẩy ',' hoặc khoảng trắng.
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                # Đọc từng dòng, thay thế dấu phẩy bằng khoảng trắng và chuyển đổi sang kiểu int
                return [[int(x) for x in line.replace(',', ' ').split()] for line in f if line.strip()]
        except Exception as e:
            print(f"Lỗi hệ thống khi đọc file map {file_path}: {e}")
            return []

    def is_valid(self, r, c):
        """
        Kiểm tra xem một tọa độ có nằm trong lưới và không phải tường đá (1) hay không.
        Đây là điều kiện cơ bản nhất về mặt cấu trúc vật lý của mê cung.
        """
        return 0 <= r < self.rows and 0 <= c < self.cols and self.data[r][c] != 1

    # -----------------------------------------------------------------
    # [KHẮC PHỤC LOGIC TƯỜNG/Ô ĐẶC BIỆT CHO THUẬT TOÁN NÂNG CAO]
    # -----------------------------------------------------------------
    def is_safe_for_normal_search(self, r, c):
        """
        [NHÓM 1, 2, 3]: Kiểm tra tính an toàn cho thuật toán cơ bản.
        Các thuật toán tìm đường thông thường buộc phải coi Ô Cấm (7) và Kẻ địch (8) là chướng ngại vật.
        """
        if not self.is_valid(r, c): 
            return False
        return self.data[r][c] not in (7, 8)

    def can_agent_enter(self, r,  c, has_key=False):
        """
        [NHÓM 4, 5 (CSP)]: Kiểm tra điều kiện thỏa mãn ràng buộc để đi vào ô.
        Ô Cửa Khóa (7) đóng vai trò là một rào cản vật lý, chỉ cho phép nhân vật 
        đi xuyên qua khi và chỉ khi điều kiện ràng buộc được thỏa mãn (has_key == True).
        (Thuật toán bắt buộc phải giải bài toán thỏa mãn điều kiện nhặt Chìa khóa (6) trước 
        thì mới mở được ràng buộc đi qua Cửa (7) để về đích)"
        """
        if not self.is_valid(r, c): 
            return False
            
        cell_type = self.data[r][c]
        if cell_type == 7:      # Gặp ô Cửa Khóa
            return has_key      # Mở cửa nếu đã nhặt được chìa khóa, ngược lại chặn đứng
            
        return True

    def get_neighbors(self, pos):
        """
        [HÀM CẦU NỐI DỮ LIỆU] Mở rộng các ô lân cận (4 hướng: Lên, Xuống, Trái, Phải).
        Trả về danh sách đầy đủ thông tin (Trọng số, Giá trị, Phân loại) phục vụ cho từng nhóm thuật toán.
        
        Ứng dụng cấu trúc dữ liệu trả về theo Nhóm:
        - Nhóm 1, 2, 3 (Uninformed/Informed): Sử dụng 'weight' để tính toán chi phí đường đi.
        - Nhóm 4, 5 (CSP / Ràng buộc):        Sử dụng 'type' để check điều kiện logic (6: Chìa khóa, 7: Ô khóa).
        - Nhóm 6 (Minimax / Adversarial):     Sử dụng kết hợp cả 'value' (để lượng hóa điểm phạt) 
                                              và 'type' (để nhận diện thực thể Kẻ địch số 8).
        """
        r, c = pos
        neighbors = []
        
        # Thứ tự duyệt ưu tiên chuẩn: Lên (Up), Xuống (Down), Trái (Left), Phải (Right)
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if self.is_valid(nr, nc):
                cell_type = self.data[nr][nc]
                
                # Đóng gói dữ liệu đa năng, đồng bộ cấu trúc cho toàn bộ 18 thuật toán con kế thừa
                info = {
                    "pos": (nr, nc),
                    "weight": self.weights.get(cell_type, 1), # Chi phí bước đi (Map 1, 2, 3)
                    "value": self.values.get(cell_type, 0),   # Điểm số Heuristic (Map 6)
                    "type": cell_type                         # ID gốc để nhận diện thực thể:
                                                              # + Map 4, 5: 6 (Chìa khóa), 7 (Cửa khóa)
                                                              # + Map 6: 8 (Kẻ địch)
                }
                neighbors.append(info)
                
        return neighbors

    def get_start_goal(self, start_val=2, goal_val=3):
        """
        [HÀM ĐỊNH VỊ THỰC THỂ] Quét toàn bộ ma trận để tìm tọa độ của Start (2) và Goal (3).
        Đảm bảo vị trí xuất phát và đích đến đồng nhất trên mọi bản đồ khi nạp vào giao diện.
        """
        start, goal = None, None
        for r in range(self.rows):
            for c in range(self.cols):
                if self.data[r][c] == start_val: 
                    start = (r, c)
                elif self.data[r][c] == goal_val: 
                    goal = (r, c)
        return start, goal