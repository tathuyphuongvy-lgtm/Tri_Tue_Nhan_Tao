# =================================================================
# FILE: algorithms/gr2_informed/greedy_Vy.py
# CHỨC NĂNG: Thuật toán Greedy Best-First Search - Đã đồng bộ
# =================================================================
import heapq
from algorithms.algorithm import PathfindingAlgorithm

class GreedyAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Greedy")

    def heuristic(self, pos, end_pos):
        return abs(pos[0] - end_pos[0]) + abs(pos[1] - end_pos[1])

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        counter = 0
        # pq lưu: (h_val, counter, current_node, path)
        pq = [(self.heuristic(start_pos, end_pos), counter, start_pos, [start_pos])]
        visited = {start_pos}
        reached_nodes = []
        step = 0

        while pq:
            step += 1
            h_curr, _, current_node, path = heapq.heappop(pq)
            reached_nodes.append(current_node)
            
            parent = path[-2] if len(path) > 1 else None
            neighbors = maze.get_neighbors(current_node)
            
            # --- TỔNG HỢP LOG ---
            log_content = [
                "==================================================",
                f"ALGORITHM: GREEDY",
                "--------------------------------------------------",
                f"Current Node : {current_node} (h={h_curr})",
                f"Parent Node  : {parent if parent else 'None'}",
                f"Action taken : {self.get_action_name(parent, current_node) if parent else 'Start'}",
                "",
                "EXPAND:"
            ]
            for n_info in neighbors:
                n_pos = n_info["pos"]
                log_content.append(f"  -> Con: {n_pos} | h(n)={self.heuristic(n_pos, end_pos)}")
            
            # Frontier
            frontier_nodes = [item[2] for item in pq]
            log_content.extend(["", f"FRONTIER (Total: {len(frontier_nodes)} nodes):"])
            log_content.extend(self.split_list_to_lines(frontier_nodes))
            
            # Reached
            log_content.extend(["", f"REACHED (Total: {len(reached_nodes)} nodes):"])
            log_content.extend(self.split_list_to_lines(reached_nodes[-10:]))

            yield self.yield_log(step, current_node, log_content)

            # Kiểm tra đích
            if current_node == tuple(end_pos):
                return self.yield_finished(
                    curr=current_node,
                    path=path,
                    reached=reached_nodes,
                    metrics={"steps": step, "length": len(path) - 1},
                    ly_do=None
                )

            for neighbor in neighbors:
                n_pos = neighbor["pos"]
                if n_pos not in visited:
                    visited.add(n_pos)
                    counter += 1
                    h_val = self.heuristic(n_pos, end_pos)
                    heapq.heappush(pq, (h_val, counter, n_pos, path + [n_pos]))

        return self.yield_finished(
            curr=start_pos,
            path=None,
            reached=reached_nodes,
            metrics={"steps": step, "length": 0},
            ly_do="Không tìm thấy đường đi!"
        )