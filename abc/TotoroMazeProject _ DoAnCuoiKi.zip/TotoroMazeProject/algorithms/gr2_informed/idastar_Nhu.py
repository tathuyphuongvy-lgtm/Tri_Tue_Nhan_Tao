# =================================================================
# FILE: algorithms/gr2_informed/idastar_Nhu.py
# CHỨC NĂNG: Thuật toán tìm kiếm IDA* (Iterative Deepening A*)
# =================================================================

from algorithms.algorithm import PathfindingAlgorithm
from utils.helper import heuristic_manhattan

class IDAStarAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="IDA_Star")

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        """Hàm hỗ trợ bẻ dòng để Pygame không bị ngộp khi Log quá dài"""
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        """
        Thực thi thuật toán IDA* dưới dạng generator tương thích SolverManager.
        """
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        # Khởi tạo ngưỡng cắt tỉa ban đầu
        threshold = heuristic_manhattan(start, end)
        step_counter = 0      
        process_steps = []    

        while True:
            # Mỗi chu kỳ duyệt mới, reset lại stack đường đi bắt đầu từ Start
            path_stack = [start]       
            g_scores = {start: 0}      
            parent_dict = {start: None} 
            
            # Kích hoạt hàm đệ quy tìm kiếm DFS dưới ngưỡng I
            sub_search = self._search(
                maze, start, end, g_scores, parent_dict, path_stack, threshold, step_counter, process_steps
            )
            
            found = False
            next_threshold = float('inf') 

            # Lặp qua dữ liệu trả về từ máy phát (generator) đệ quy
            for signal in sub_search:
                if signal["type"] == "log":
                    yield signal 
                elif signal["type"] == "result":
                    found, next_threshold, step_counter = signal["data"]

            # TRƯỜNG HỢP 1: THÀNH CÔNG - Tìm thấy đường đi hoàn chỉnh
            if found:
                final_path = self.reconstruct_path(parent_dict, end) 
                
                # Gọi hàm lớp cha để đóng gói logs và metrics chuẩn Excel
                return self.yield_finished(
                    curr=end,
                    path=final_path,
                    reached=process_steps,
                    metrics={"steps": step_counter, "length": len(final_path) - 1}
                )

            # TRƯỜNG HỢP 2: THẤT BẠI - Đã quét sạch map không còn đường đi
            if next_threshold == float('inf'):
                return self.yield_finished(
                    curr=None,
                    path=None,
                    reached=process_steps,
                    metrics={"steps": step_counter, "length": 0},
                    ly_do="Đã duyệt hết không gian trạng thái khả thi"
                )

            # TRƯỜNG HỢP 3: CẬP NHẬT NGƯỠNG MỚI KHI FRONTIER TẦNG CŨ RỖNG
            old_threshold = threshold
            threshold = next_threshold  
            step_counter += 1
            
            log_update = [
                f" Ngưỡng I    : {old_threshold} -> ĐÃ DUYỆT HẾT VÀ TRỐNG RỖNG FRONTIER!",
                f"--> CẬP NHẬT NGƯỠNG I MỚI: {threshold}",
                "--------------------------------------------------",
                "Hệ thống tự động quay về điểm Start và bắt đầu chu kỳ duyệt DFS mới",
                "với không gian tìm kiếm rộng hơn."
            ]
            yield self.yield_log(step_counter, start, log_update)

    def _search(self, maze, curr, end_pos, g_scores, parent_dict, path_stack, threshold, step_counter, process_steps):
        """Hàm đệ quy DFS của IDA* chuẩn Graph Search - Tương thích luồng SolverManager."""
        curr_g = g_scores[curr]
        curr_f = curr_g + heuristic_manhattan(curr, end_pos)

        # 1. BIỆN PHÁP CẮT TỈA (PRUNING)
        if curr_f > threshold:
            yield {"type": "result", "data": (False, curr_f, step_counter)}
            return

        # 2. KIỂM TRA ĐÍCH
        if curr == end_pos:
            yield {"type": "result", "data": (True, threshold, step_counter)}
            return

        # 3. ĐƯA NODE VÀO REACHED (Danh sách các node đã chính thức lấy ra xét duyệt)
        step_counter += 1
        if curr not in process_steps:
            process_steps.append(curr)

        # 4. SINH CÁC NODE CON KHẢ THI (EXPAND)
        neighbors = maze.get_neighbors(curr)
        expand_list = []   
        local_frontier = {}
        
        # Biến tracking ngưỡng vượt cục bộ ngay trong lúc expand để không bị sót node lọc trùng
        min_cutoff_in_expand = float('inf')

        for n_data in neighbors:
            n_pos = n_data["pos"]
            n_weight = n_data["weight"]
            
            n_g = curr_g + n_weight
            n_h = heuristic_manhattan(n_pos, end_pos)
            n_f = n_g + n_h

            # TRƯỜNG HỢP Ô CON VƯỢT NGƯỠNG I: Ghi nhận giá trị f(n) để làm ngưỡng mới rồi bỏ qua
            if n_f > threshold:
                if n_f < min_cutoff_in_expand:
                    min_cutoff_in_expand = n_f
                continue
                
            # TRƯỜNG HỢP Ô CON NẰM TRONG NGƯỠNG I: Tiến hành lọc trùng trạng thái
            if n_pos in path_stack:
                continue

            if n_pos in process_steps:
                if n_f >= (g_scores.get(n_pos, float('inf')) + heuristic_manhattan(n_pos, end_pos)):
                    continue

            if n_pos in local_frontier:
                if n_f < local_frontier[n_pos]:
                    local_frontier[n_pos] = n_f
                    g_scores[n_pos] = n_g
                    parent_dict[n_pos] = curr
            else:
                local_frontier[n_pos] = n_f
                g_scores[n_pos] = n_g
                parent_dict[n_pos] = curr

        # Đóng gói danh sách hiển thị Log Pygame
        for pos, f_val in local_frontier.items():
            action = self.get_action_name(curr, pos)
            expand_list.append(f"  -> Con: {pos} | Action: {action} | f(n): {f_val}")

        # Đồng bộ hóa định dạng hiển thị cho Frontier (mảng tọa độ thuần túy)
        frontier_nodes = list(local_frontier.keys())

        # Xuất cấu trúc log đóng khung chuẩn chỉnh
        log_content = [
            f"ALGORITHM: IDA*",
            f"-------------------------------------------------",
            f" Ngưỡng I    : {threshold}",
            f"Current Node : {curr}",
            f"Parent Node  : {parent_dict[curr]}",
            f"Action taken : {self.get_action_name(parent_dict[curr], curr)}",
            "",
            "EXPAND (Ô hợp lệ):"
        ] + (expand_list if expand_list else ["  -> (Chạm ngưỡng hoặc nhánh cụt)"]) + [
            "",
            f"FRONTIER (Total: {len(frontier_nodes)} nodes):"
        ] + self.split_list_to_lines(frontier_nodes, max_per_line=4) + [
            "",
            f"REACHED (Total: {len(process_steps)} nodes):"
        ] + self.split_list_to_lines(process_steps, max_per_line=4)

        yield self.yield_log(step_counter, curr, log_content)

        # Thiết lập min_next_threshold ban đầu bằng giá trị thu được ngay lúc expand
        min_next_threshold = min_cutoff_in_expand

        # 5. TIẾN HÀNH ĐI SÂU DFS
        for n_pos in frontier_nodes:
            path_stack.append(n_pos)

            sub_search = self._search(maze, n_pos, end_pos, g_scores, parent_dict, path_stack, threshold, step_counter, process_steps)
            
            for signal in sub_search:
                if signal["type"] == "log":
                    yield signal
                elif signal["type"] == "result":
                    sub_found, sub_threshold, step_counter = signal["data"]

            if sub_found:
                yield {"type": "result", "data": (True, threshold, step_counter)}
                return
            
            if sub_threshold < min_next_threshold:
                min_next_threshold = sub_threshold

            path_stack.pop() # Backtracking

        yield {"type": "result", "data": (False, min_next_threshold, step_counter)}