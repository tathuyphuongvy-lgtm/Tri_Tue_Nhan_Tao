# =================================================================
# FILE: algorithms/gr2_informed/astar_Khuong.py
# CHỨC NĂNG: Cài đặt thuật toán A* (A-Star Search)
# =================================================================
import heapq
from algorithms.algorithm import PathfindingAlgorithm

class AStarAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="A*")

    def heuristic(self, p1, p2):
        # Manhattan distance
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        """Hàm hỗ trợ bẻ dòng để Pygame không bị lỗi render text khi UI Log quá dài"""
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        # Priority Queue: (f_score, g_score, current_node, path)
        h_start = self.heuristic(start, end)
        frontier = [(h_start, 0, start, [start])]
        
        g_scores = {start: 0}
        reached_history = []
        step_count = 0
        
        while frontier:
            f, g, curr, path = heapq.heappop(frontier)
            step_count += 1
            
            if curr not in reached_history:
                reached_history.append(curr)
                
            if g > g_scores.get(curr, float('inf')):
                continue
                
            # --- KIỂM TRA ĐÍCH ---
            if curr == end:
                # Đồng bộ cơ chế bốc dữ liệu xuất file Excel thông qua hàm của lớp cha
                return self.yield_finished(
                    curr=end,
                    path=path,
                    reached=reached_history,
                    metrics={"steps": step_count, "length": len(path) - 1}
                )

            parent = path[-2] if len(path) > 1 else None
            h_curr = self.heuristic(curr, end)
            
            valid_neighbors = []
            neighbors_info = maze_obj.get_neighbors(curr)
            
            for n_info in neighbors_info:
                n_pos = n_info["pos"]
                cost = n_info.get("weight", 1)
                tentative_g = g + cost
                
                if tentative_g < g_scores.get(n_pos, float('inf')):
                    g_scores[n_pos] = tentative_g
                    h_n = self.heuristic(n_pos, end)
                    f_n = tentative_g + h_n
                    valid_neighbors.append((n_pos, tentative_g, h_n, f_n))
                    heapq.heappush(frontier, (f_n, tentative_g, n_pos, path + [n_pos]))
            
            # --- TẠO LOG UI ĐỒNG BỘ ---
            log_lines = [
                f"ALGORITHM: A*",
                f"-------------------------------------------------",
                f"Current Node : {curr}",
                f"Parent Node  : {parent if parent else 'None'}",
                f"Action taken : {self.get_action_name(parent, curr)}",
                "",
                "Current Cost:",
                f"  g = {g} | h = {h_curr} | f = {f}",
                "",
                "EXPAND (Ô hợp lệ):"
            ]
            
            if valid_neighbors:
                for n_pos, ng, nh, nf in valid_neighbors:
                    action = self.get_action_name(curr, n_pos)
                    log_lines.append(f"  -> Con: {n_pos} | Action: {action} | f={nf}")
            else:
                log_lines.append("  -> (Không sinh thêm node hợp lệ)")
                
            frontier_nodes = [item[2] for item in frontier]
            log_lines.extend([
                "",
                f"FRONTIER (Total: {len(frontier)} nodes):"
            ])
            log_lines.extend(self.split_list_to_lines(frontier_nodes))
            
            # ĐỒNG BỘ: Thêm hiển thị danh sách REACHED lên Log Box tương tự các thuật toán khác
            log_lines.extend([
                "",
                f"REACHED (Total: {len(reached_history)} nodes):"
            ])
            log_lines.extend(self.split_list_to_lines(reached_history))
            
            # Sử dụng yield_log chuẩn từ lớp cha, đảm bảo truyền đúng trường "curr" để Pygame vẽ ô cam quét duyệt
            yield self.yield_log(step_count, curr, log_lines)

        # --- TRƯỜNG HỢP KHÔNG TÌM THẤY ĐƯỜNG ĐI ---
        return self.yield_finished(
            curr=None,
            path=None,
            reached=reached_history,
            metrics={"steps": step_count, "length": 0},
            ly_do="Không tìm thấy lối thoát hợp lệ"
        )