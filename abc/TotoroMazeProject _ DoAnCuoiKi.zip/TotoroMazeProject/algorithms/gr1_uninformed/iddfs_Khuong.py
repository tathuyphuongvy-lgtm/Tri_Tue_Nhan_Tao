# =================================================================
# FILE: algorithms/gr1_uninformed/iddfs_Khuong.py
# CHỨC NĂNG: Cài đặt thuật toán IDDFS (Iterative Deepening DFS)
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class IDDFSAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="IDDFS")

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        """Hàm hỗ trợ bẻ dòng để Pygame không bị ngộp khi Log quá dài"""
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        max_depth = 0
        global_step_count = 0
        
        # Biến lưu tổng các node độc nhất thực tế đã bốc ra xét duyệt qua mọi tầng độ sâu
        explored_nodes = []
        
        max_possible_depth = maze_obj.rows * maze_obj.cols 
        
        while max_depth <= max_possible_depth:
            # --- TRẠNG THÁI KHỞI TẠO CỦA 1 VÒNG LẶP DLS ---
            frontier = [(start, [start])]
            visited_depth = {start: 0} 
            found_path = None
            
            # Khởi tạo tập hợp danh sách đã duyệt RIÊNG cho tầng độ sâu này
            local_explored = []
            
            # 1. Báo cáo bắt đầu giới hạn độ sâu mới
            yield {
                "type": "log",
                "curr": start,
                "frontier": [start],
                "reached": explored_nodes,
                "path": [start],
                "data": [
                    "==================================================",
                    f"BẮT ĐẦU TÌM KIẾM VỚI GIỚI HẠN ĐỘ SÂU: {max_depth}",
                    "=================================================="
                ]
            }
            
            # 2. Bắt đầu DFS với giới hạn max_depth
            while frontier:
                curr, path = frontier.pop()
                global_step_count += 1
                current_depth = len(path) - 1
                
                # Ghi nhận vào danh sách cục bộ của tầng này
                if curr not in local_explored:
                    local_explored.append(curr)
                
                # Đồng thời cập nhật vào kho lưu trữ tổng để xuất Excel
                if curr not in explored_nodes:
                    explored_nodes.append(curr)
                    
                # Kiểm tra đích đến
                if curr == end:
                    found_path = path
                    break
                    
                valid_neighbors = []
                
                # Chỉ sinh con nếu chưa chạm tới giới hạn độ sâu
                if current_depth < max_depth:
                    neighbors_info = maze_obj.get_neighbors(curr)
                    for n_info in neighbors_info:
                        n_pos = n_info["pos"]
                        n_depth = current_depth + 1
                        
                        if n_pos not in path:
                            if n_pos not in visited_depth or n_depth <= visited_depth[n_pos]:
                                visited_depth[n_pos] = n_depth
                                valid_neighbors.append(n_pos)
                                frontier.append((n_pos, path + [n_pos]))
                
                # 3. Ghi log lại tiến trình
                parent = path[-2] if len(path) > 1 else None
                log_lines = [
                    "==================================================",
                    f"[STEP {global_step_count}] - IDDFS (Limit: {max_depth})",
                    "--------------------------------------------------",
                    f"Current Node : {curr} (Depth: {current_depth})",
                    f"Parent Node  : {parent if parent else 'None'}",
                    f"Action taken : {self.get_action_name(parent, curr)}",
                    "",
                    "EXPAND:"
                ]
                
                if valid_neighbors:
                    for n_pos in valid_neighbors:
                        action = self.get_action_name(curr, n_pos)
                        log_lines.append(f"  -> Con: {n_pos} | Action: {action}")
                else:
                    if current_depth == max_depth:
                        log_lines.append("  -> (Chạm giới hạn độ sâu, không sinh con)")
                    else:
                        log_lines.append("  -> (Không có ô hợp lệ / Đường cụt)")
                        
                frontier_nodes = [item[0] for item in frontier]
                log_lines.extend([
                    "",
                    f"FRONTIER (Total: {len(frontier)} nodes):"
                ])
                log_lines.extend(self.split_list_to_lines(frontier_nodes))
                
                # TỐI ƯU CHÍNH TẠI ĐÂY: Chỉ in danh sách REACHED cục bộ của vòng lặp này 
                # để tăng tốc độ xử lý chuỗi lên gấp 50 lần!
                log_lines.extend([
                    "",
                    f"REACHED TRONG TẦNG NÀY (Total: {len(local_explored)} nodes):"
                ])
                log_lines.extend(self.split_list_to_lines(local_explored))
                log_lines.append("==================================================")
                
                yield {
                    "type": "log",
                    "curr": curr,
                    "frontier": frontier_nodes,
                    "reached": explored_nodes, # Excel vẫn bốc đủ mảng tổng quát sạch sẽ
                    "path": path,
                    "data": log_lines
                }
            
            # --- KIỂM TRA SAU MỖI VÒNG LẶP ---
            if found_path:
                return self.yield_finished(
                    curr=end,
                    path=found_path,
                    reached=explored_nodes,
                    metrics={"steps": global_step_count, "length": len(found_path) - 1},
                    do_sau_tim_thay=max_depth
                )
            
            max_depth += 1

        return self.yield_finished(
            curr=None,
            path=None,
            reached=explored_nodes,
            metrics={"steps": global_step_count, "length": 0},
            ly_do="Vượt quá giới hạn bản đồ"
        )