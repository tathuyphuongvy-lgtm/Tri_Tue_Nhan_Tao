# =================================================================
# FILE: algorithms/gr1_uninformed/dfs_Vy.py
# CHỨC NĂNG: Thuật toán DFS (Đã bổ sung EXPAND & đồng bộ log)
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class DFSAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="DFS")

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        stack = [(start_pos, [start_pos])]
        visited = {start_pos}
        reached_nodes = []
        step = 0

        yield self.yield_log(step, start_pos, ["Bắt đầu tìm kiếm bằng DFS..."])
        
        while stack:
            step += 1
            current_node, path = stack.pop()
            reached_nodes.append(current_node)
            
            parent = path[-2] if len(path) > 1 else None
            neighbors = maze.get_neighbors(current_node)
            
            # --- TỔNG HỢP LOG ---
            log_content = [
                "==================================================",
                f"ALGORITHM: DFS",
                "--------------------------------------------------",
                f"Current Node : {current_node}",
                f"Parent Node  : {parent if parent else 'None'}",
                f"Action taken : {self.get_action_name(parent, current_node) if parent else 'Start'}",
                "",
                "EXPAND:"
            ]
            
            # Liệt kê các ô con (Neighbors)
            for neighbor in neighbors:
                n_pos = neighbor["pos"]
                action = self.get_action_name(current_node, n_pos)
                log_content.append(f"  -> Con: {n_pos} | Action: {action}")
            
            # Frontier
            frontier_nodes = [s[0] for s in stack]
            log_content.extend(["", f"FRONTIER (Total: {len(frontier_nodes)} nodes):"])
            log_content.extend(self.split_list_to_lines(frontier_nodes))
            
            # Reached
            log_content.extend(["", f"REACHED TRONG TẦNG NÀY (Total: {len(reached_nodes)} nodes):"])
            log_content.extend(self.split_list_to_lines(reached_nodes[-10:]))

            yield self.yield_log(step, current_node, log_content)

            # Kiểm tra đích
            if current_node == tuple(end_pos):
                return self.yield_finished(
                    curr=current_node,
                    path=path,
                    reached=reached_nodes,
                    metrics={"steps": step, "length": len(path) - 1},
                )

            # Thêm láng giềng vào stack
            for neighbor in reversed(neighbors):
                n_pos = neighbor["pos"]
                if n_pos not in visited:
                    visited.add(n_pos)
                    stack.append((n_pos, path + [n_pos]))

        return self.yield_finished(
            curr=start_pos,
            path=None,
            reached=reached_nodes,
            metrics={"steps": step, "length": 0},
            ly_do="Không tìm thấy đường đi!"
        )