# =================================================================
# FILE: algorithms/gr1_uninformed/bfs_Nhu.py
# CHỨC NĂNG: Cài đặt thuật toán BFS dạng từng bước chuẩn xác
# =================================================================
import collections
from algorithms.algorithm import PathfindingAlgorithm

class BFSAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="BFS")

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        # Hàng đợi (Queue) cho BFS: FIFO
        frontier = collections.deque([start])
        frontier_set = {start}
        
        # Đánh dấu các ô đã duyệt
        reached = set()
        reached_history = []
        
        # Lưu vết đường đi
        parent = {start: None}
        step_count = 1
        
        while frontier:
            curr = frontier.popleft()
            frontier_set.remove(curr)
            reached.add(curr)
            
            if curr not in reached_history:
                reached_history.append(curr)
            
            # --- KIỂM TRA ĐÍCH ---
            if curr == end:
                path = self.reconstruct_path(parent, end)
                
                # Gọi hàm lớp cha để tự động đóng gói logs và metrics chuẩn Excel
                return self.yield_finished(
                    curr=end,
                    path=path,
                    reached=reached_history,
                    metrics={"steps": step_count, "length": len(path) - 1}
                )
            
            # --- MỞ RỘNG CÁC Ô LÂN CẬN ---
            raw_neighbors = maze_obj.get_neighbors(curr)
            valid_neighbors = [
                n['pos'] for n in raw_neighbors 
                if n['pos'] not in reached and n['pos'] not in frontier_set
            ]
            
            for neighbor in valid_neighbors:
                parent[neighbor] = curr
                frontier.append(neighbor)
                frontier_set.add(neighbor)
            
            # --- GỬI LOG TRẠNG THÁI TỪNG BƯỚC ---
            if debug_mode:
                curr_parent = parent.get(curr)
                content = self.generate_log_content(
                    curr=curr, 
                    parent=curr_parent, 
                    valid_neighbors=valid_neighbors, 
                    frontier=list(frontier), 
                    reached=reached_history
                )
                yield self.yield_log(step_count, curr, content)
            
            step_count += 1
            
        # --- TRƯỜNG HỢP KHÔNG TÌM THẤY ĐƯỜNG ĐI ---
        return self.yield_finished(
            curr=None,
            path=None,
            reached=reached_history,
            metrics={"steps": step_count, "length": 0},
            ly_do="Không tìm thấy lối thoát hợp lệ"
        )

    def generate_log_content(self, curr, parent, valid_neighbors, frontier, reached):
        """Tạo nội dung log, giữ đúng thứ tự thời gian và tự động bẻ dòng khi quá dài"""
        def split_list_to_lines(nodes_list, max_per_line=4):
            if not nodes_list: return ["  [Trống]"]
            lines = []
            str_nodes = [str(node) for node in nodes_list]
            for i in range(0, len(str_nodes), max_per_line):
                chunk = str_nodes[i : i + max_per_line]
                chunk_str = ", ".join(chunk)
                if i + max_per_line < len(str_nodes): chunk_str += ","
                lines.append(f"  {chunk_str}")
            return lines

        log_lines = [
            f"ALGORITHM: BFS",
            f"-------------------------------------------------",
            f"Current Node : {curr}",
            f"Parent Node  : {parent if parent else 'None'}",
            f"Action taken : {self.get_action_name(parent, curr)}",
            "",
            "EXPAND (Ô hợp lệ):"
        ]
        
        if valid_neighbors:
            for n in valid_neighbors:
                action = self.get_action_name(curr, n)
                log_lines.append(f"  -> Con: {n} (Cha: {curr}) | Action: {action}")
        else:
            log_lines.append("  -> (Không sinh thêm node con mới chưa duyệt)")
            
        log_lines.append("")
        log_lines.append(f"FRONTIER (Total: {len(frontier)} nodes):")
        log_lines.extend(split_list_to_lines(frontier, max_per_line=4))

        log_lines.append("")
        log_lines.append(f"REACHED (Total: {len(reached)} nodes):")
        log_lines.extend(split_list_to_lines(reached, max_per_line=4))
        return log_lines