# =================================================================
# FILE: algorithms/gr6_adversarial/alpha_beta_Vy.py
# CHỨC NĂNG: Alpha-Beta đối kháng (Log trình bày thoáng, xuống dòng)
# =================================================================

from algorithms.algorithm import PathfindingAlgorithm

class AlphaBetaAlgorithm(PathfindingAlgorithm):
    def __init__(self, max_depth=4):
        super().__init__(name="Alpha_Beta")
        self.max_depth = max_depth
        self.step_counter = 0

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        self.step_counter += 1
        current_pos = tuple(start_pos)
        monster_positions = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] == 8]

        # 1. Kiểm tra kết thúc
        if current_pos == tuple(end_pos):
            return self.yield_finished(current_pos, path=[current_pos], reached=[current_pos], 
                                     metrics={"steps": self.step_counter}, ly_do="Đã tới đích!")
        if current_pos in monster_positions:
            return self.yield_finished(current_pos, None, [current_pos], 
                                     metrics={"steps": self.step_counter}, ly_do="Bị quái vật bắt!")

        # 2. Tìm nước đi tốt nhất
        neighbors = maze.get_neighbors(current_pos)
        if not neighbors:
            return self.yield_finished(current_pos, None, [current_pos], 
                                     metrics={"steps": self.step_counter}, ly_do="Bế tắc!")

        best_value = float('-inf')
        best_move = None
        alpha, beta = float('-inf'), float('inf')
        
        # Log xuống dòng cho dễ đọc
        log_details = [
            f"Lượt #{self.step_counter} | Agent: {current_pos}",
            f"Alpha: {alpha} | Beta: {beta}",
            "------------------------------------------"
        ]

        for next_node in neighbors:
            score = self._alphabeta(maze, next_node["pos"], monster_positions, tuple(end_pos), 1, False, alpha, beta)
            
            # Xuống dòng bằng cách chia nhỏ log
            log_details.append(f"-> Thử {next_node['pos']}:")
            log_details.append(f"   Score: {score:.1f} | Alpha: {alpha:.1f} | Beta: {beta:.1f}")
            
            if score > best_value:
                best_value = score
                best_move = next_node["pos"]
            
            alpha = max(alpha, best_value)
            
            if beta <= alpha:
                log_details.append(f"Cắt tỉa: Beta({beta:.1f}) <= Alpha({alpha:.1f})")
                break 

        log_details.append("------------------------------------------")
        log_details.append(f"==> QUYẾT ĐỊNH: {best_move} (Score={best_value:.1f})")
        yield self.yield_log(self.step_counter, current_pos, log_details)
        
        return self.yield_finished([current_pos, best_move], path=[current_pos, best_move], reached=[current_pos, best_move],
                                 metrics={"steps": self.step_counter, "length": 1, "best_score": round(best_value, 1)})

    def _alphabeta(self, maze, agent_pos, monster_positions, end_pos, depth, is_maximizing, alpha, beta):
        # (Logic giữ nguyên)
        if agent_pos in monster_positions: return -500
        if agent_pos == end_pos: return 100
        if depth >= self.max_depth:
            dist_goal = abs(agent_pos[0] - end_pos[0]) + abs(agent_pos[1] - end_pos[1])
            min_dist_m = min([abs(agent_pos[0]-m[0]) + abs(agent_pos[1]-m[1]) for m in monster_positions] + [float('inf')])
            return (-2.0 * dist_goal) + (1.5 * min_dist_m)
        
        if is_maximizing:
            max_eval = float('-inf')
            for n in maze.get_neighbors(agent_pos):
                val = self._alphabeta(maze, n["pos"], monster_positions, end_pos, depth + 1, False, alpha, beta)
                max_eval = max(max_eval, val)
                alpha = max(alpha, val)
                if beta <= alpha: break 
            return max_eval
        else:
            min_eval = float('inf')
            for m_pos in monster_positions:
                m_neigh = maze.get_neighbors(m_pos)
                if not m_neigh: continue
                for n in m_neigh:
                    val = self._alphabeta(maze, agent_pos, [n["pos"]], end_pos, depth + 1, True, alpha, beta)
                    min_eval = min(min_eval, val)
                    beta = min(beta, val)
                    if beta <= alpha: break
            return min_eval