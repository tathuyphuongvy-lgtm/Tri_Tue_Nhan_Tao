# =================================================================
# FILE: algorithms/minimax_turn_based.py
# CHỨC NĂNG: Thuật toán Minimax đối kháng theo lượt (Nhóm 6) - Đã đồng bộ
# =================================================================

import random
from algorithms.algorithm import PathfindingAlgorithm

class MinimaxAlgorithm(PathfindingAlgorithm):
    def __init__(self, max_depth=4):
        super().__init__(name="Minimax")
        self.max_depth = max_depth
        self.step_counter = 0
        self.visited_count = {} 

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        self.step_counter += 1
        current_pos = tuple(start_pos)
        self.visited_count[current_pos] = self.visited_count.get(current_pos, 0) + 1

        # 1. Tìm vị trí Quái vật (ID 8)
        monster_positions = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] == 8]

        # 2. Kiểm tra kết thúc
        if current_pos == tuple(end_pos):
            return self.yield_finished(current_pos, path=[current_pos], reached=[current_pos], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Đã tới đích!")
        if current_pos in monster_positions:
            return self.yield_finished(current_pos, path=None, reached=[current_pos], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Bị quái vật bắt!")

        # 3. Tìm nước đi tốt nhất
        neighbors = maze.get_neighbors(current_pos)
        if not neighbors:
            return self.yield_finished(current_pos, path=None, reached=[current_pos], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Bế tắc!")

        best_value = float('-inf')
        best_move = None
        log_details = [f"Lượt #{self.step_counter} | Agent: {current_pos} | Quái vật: {monster_positions}"]

        for next_node in neighbors:
            val = self._minimax(maze, next_node["pos"], monster_positions, tuple(end_pos), 1, False)
            log_details.append(f"-> Hướng {next_node['pos']}: Dự đoán Score = {val:.1f}")
            if val > best_value:
                best_value = val
                best_move = next_node["pos"]

        # 4. Gửi log ra UI
        log_details.append(f"==> QUYẾT ĐỊNH: Di chuyển tới {best_move}")
        yield self.yield_log(self.step_counter, current_pos, log_details)

        # 5. Trả về kết quả bước đi cho main.py
        return self.yield_finished([current_pos, best_move], path=[current_pos, best_move], reached=[current_pos, best_move],
                                 metrics={"steps": self.step_counter, "length": 1})

    def _minimax(self, maze, agent_pos, monster_positions, end_pos, depth, is_maximizing):
        # Trạng thái lá
        if agent_pos in monster_positions: return -500
        if agent_pos == end_pos: return 100
        if depth >= self.max_depth:
            dist_goal = abs(agent_pos[0] - end_pos[0]) + abs(agent_pos[1] - end_pos[1])
            min_dist_m = min([abs(agent_pos[0]-m[0]) + abs(agent_pos[1]-m[1]) for m in monster_positions] + [float('inf')])
            return (-2.0 * dist_goal) + (1.5 * min_dist_m) - (25 * self.visited_count.get(agent_pos, 0))

        # Đệ quy
        if is_maximizing:
            neighbors = maze.get_neighbors(agent_pos)
            if not neighbors: return -500
            return max([self._minimax(maze, n["pos"], monster_positions, end_pos, depth + 1, False) for n in neighbors])
        else:
            # Quái vật đi về phía Agent (MIN)
            next_monsters = []
            for m_pos in monster_positions:
                m_neigh = maze.get_neighbors(m_pos)
                if not m_neigh: next_monsters.append(m_pos)
                else:
                    best_m = min(m_neigh, key=lambda n: abs(n["pos"][0]-agent_pos[0]) + abs(n["pos"][1]-agent_pos[1]))
                    next_monsters.append(best_m["pos"])
            return self._minimax(maze, agent_pos, next_monsters, end_pos, depth + 1, True)