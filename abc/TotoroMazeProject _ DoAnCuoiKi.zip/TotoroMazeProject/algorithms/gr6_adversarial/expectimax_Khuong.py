# =================================================================
# FILE: algorithms/gr6_adversarial/expectimax.py
# CHỨC NĂNG: Thuật toán Expectimax Turn-based (Log chuẩn, chạy trơn tru)
# =================================================================

import math
import random
from algorithms.algorithm import PathfindingAlgorithm

class ExpectimaxAlgorithm(PathfindingAlgorithm):
    def __init__(self, max_depth=3):
        super().__init__(name="Expectimax")
        self.max_depth = max_depth
        self.step_counter = 0
        self.visited_count = {} 

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        self.step_counter += 1
        curr = tuple(start_pos)
        self.visited_count[curr] = self.visited_count.get(curr, 0) + 1
        
        ghost_positions = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] == 8]

        # 1. Kiểm tra kết thúc game
        if curr == tuple(end_pos):
            return self.yield_finished(curr, path=[curr], reached=[curr], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Đã tới đích!")
        if curr in ghost_positions:
            return self.yield_finished(curr, path=None, reached=[curr], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Bị ma bắt!")

        # 2. Tìm nước đi tốt nhất
        valid_moves = self.get_valid_moves(maze, curr)
        if not valid_moves:
            return self.yield_finished(curr, path=None, reached=[curr], 
                                     metrics={"steps": self.step_counter, "length": 0}, ly_do="Bế tắc!")

        best_value = -math.inf
        best_move = None
        log_lines = [f"Lượt #{self.step_counter} | Expectimax (Depth: {self.max_depth})"]

        for move in valid_moves:
            val = self.expectimax(maze, move, ghost_positions, tuple(end_pos), 1, False)
            # Log mang đặc trưng Expectimax
            log_lines.append(f"-> Hướng {move}: Exp.Value = {val:.1f}")
            
            if val > best_value:
                best_value = val
                best_move = move

        # 3. Gửi log ra UI (Sạch, không khung thừa)
        log_lines.append(f"==> QUYẾT ĐỊNH: Di chuyển tới {best_move} (Exp.Val={best_value:.1f})")
        yield self.yield_log(self.step_counter, curr, log_lines)

        # 4. Trả về kết quả bước đi (Chuẩn Minimax-style để main.py nhận diện di chuyển)
        return self.yield_finished([curr, best_move], path=[curr, best_move], reached=[curr, best_move],
                                 metrics={"steps": self.step_counter, "length": 1, "exp_value": round(best_value, 1)})

    def expectimax(self, maze, totoro_pos, ghost_pos_list, goal_pos, depth, is_max):
        # Trạng thái lá
        if totoro_pos in ghost_pos_list: return -500
        if totoro_pos == goal_pos: return 100
        if depth >= self.max_depth:
            return self.evaluate_state(totoro_pos, goal_pos, ghost_pos_list)

        if is_max: # Totoro (Maximize)
            moves = self.get_valid_moves(maze, totoro_pos)
            if not moves: return -500
            return max([self.expectimax(maze, m, ghost_pos_list, goal_pos, depth + 1, False) for m in moves])
        else: # Ma (Chance Node - Trung bình cộng các hướng)
            total_val = 0
            for g_pos in ghost_pos_list:
                m_neigh = self.get_valid_moves(maze, g_pos)
                if not m_neigh: 
                    total_val += self.expectimax(maze, totoro_pos, [g_pos], goal_pos, depth + 1, True)
                else:
                    # Tính giá trị kỳ vọng (Expected Value)
                    val_sum = sum([self.expectimax(maze, totoro_pos, [n], goal_pos, depth + 1, True) for n in m_neigh])
                    total_val += val_sum / len(m_neigh)
            return total_val / max(1, len(ghost_pos_list))

    def evaluate_state(self, totoro_pos, goal_pos, ghost_pos_list):
        dist_goal = abs(totoro_pos[0] - goal_pos[0]) + abs(totoro_pos[1] - goal_pos[1])
        min_dist_g = min([abs(totoro_pos[0]-g[0]) + abs(totoro_pos[1]-g[1]) for g in ghost_pos_list] + [float('inf')])
        score = (-2.0 * dist_goal) + (1.5 * min_dist_g) - (self.visited_count.get(totoro_pos, 0) * 100)
        return score

    def get_valid_moves(self, maze, pos):
        neighbors = maze.get_neighbors(pos)
        return [n["pos"] for n in neighbors]