# =================================================================
# FILE: algorithms/gr3_local/steepest_hill_climbing.py
# CHỨC NĂNG: Cài đặt thuật toán Steepest Ascent Hill-Climbing (Đã tối ưu)
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class SteepestHillClimbingAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Steepest_Hill_Climbing")

    def heuristic(self, p1, p2):
        return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        curr = start
        path = [start]
        reached = [start]
        step_count = 0
        
        while True:
            step_count += 1
            curr_h = self.heuristic(curr, end)
            
            # --- KIỂM TRA ĐÍCH ĐẾN ---
            if curr == end:
                return self.yield_finished(
                    curr=end,
                    path=path,
                    reached=reached,
                    metrics={"steps": step_count, "length": len(path) - 1}
                )
            
            # Lấy danh sách hàng xóm
            neighbors_info = maze_obj.get_neighbors(curr)
            best_neighbor = None
            best_h = float('inf')
            
            # Log nội dung hiện tại
            log_lines = [
                f"ALGORITHM: STEEPEST HILL-CLIMBING",
                f"-------------------------------------------------",
                f"Current Node : {curr} | h(n) = {curr_h}",
                "EVALUATE NEIGHBORS:"
            ]
            
            for n_info in neighbors_info:
                n_pos = n_info["pos"]
                if n_pos not in reached:
                    h_val = self.heuristic(n_pos, end)
                    log_lines.append(f"  -> Con: {n_pos} | h(n) = {h_val}")
                    
                    if h_val < best_h:
                        best_h = h_val
                        best_neighbor = n_pos
            
            # --- ĐIỀU KIỆN DỪNG (LOCAL OPTIMUM) ---
            if best_neighbor is None or best_h >= curr_h:
                log_lines.extend([
                    "",
                    "ĐẠT ĐỈNH ĐỊA PHƯƠNG (LOCAL OPTIMUM) ⚠",
                    f"-> Không có ô con nào tốt hơn (h={curr_h}). Dừng lại!"
                ])
                yield self.yield_log(step_count, curr, log_lines)
                
                return self.yield_finished(
                    curr=curr,
                    path=None,
                    reached=reached,
                    metrics={"steps": step_count, "length": 0},
                    ly_do="Bế tắc tại đỉnh địa phương"
                )
            
            # --- LEO ĐỒI ---
            log_lines.append(f"CHỌN DI CHUYỂN: -> {best_neighbor}")
            yield self.yield_log(step_count, curr, log_lines)
            
            curr = best_neighbor
            reached.append(curr)
            path.append(curr)