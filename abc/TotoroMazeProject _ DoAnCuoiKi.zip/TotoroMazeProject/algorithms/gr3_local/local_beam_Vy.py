# =================================================================
# FILE: algorithms/gr3_local/local_beam_Vy.py
# CHỨC NĂNG: Thuật toán Local Beam Search (Nhóm 3 - Chuẩn Local Search)
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class LocalBeamSearch(PathfindingAlgorithm):
    def __init__(self, k=3):
        super().__init__(name="Local_Beam")
        self.k = k

    def heuristic(self, pos, end_pos):
        return abs(pos[0] - end_pos[0]) + abs(pos[1] - end_pos[1])

    def split_list_to_lines(self, nodes_list, max_per_line=3):
        """Hàm bẻ dòng hiển thị danh sách kèm h(n)"""
        if not nodes_list: return ["  [Trống]"]
        lines = []
        for i in range(0, len(nodes_list), max_per_line):
            chunk = nodes_list[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(nodes_list): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        # Lưu ý: Nhóm 3 không dùng Reached hay Frontier theo yêu cầu
        k_states = [(tuple(start_pos), [tuple(start_pos)])]
        history = {tuple(start_pos)} 
        step = 0

        while k_states and step < 1000:
            step += 1
            next_candidates = []
            
            # 1. Kiểm tra đích
            for current_node, path in k_states:
                if current_node == tuple(end_pos):
                    return self.yield_finished(
                        curr=current_node,
                        path=path,
                        reached=[], # Nhóm 3 không dùng Reached
                        metrics={"steps": step, "length": len(path) - 1},
                        ly_do=None
                    )

            # 2. Sinh tập ứng viên (Expand)
            for current_node, path in k_states:
                for neighbor in maze.get_neighbors(current_node):
                    n_pos = neighbor["pos"]
                    if n_pos not in history:
                        history.add(n_pos)
                        h_val = self.heuristic(n_pos, end_pos)
                        next_candidates.append((n_pos, path + [n_pos], h_val))

            # 3. Chuẩn bị dữ liệu Log
            # Danh sách tất cả ứng viên với h(n)
            expand_text = [f"{s[0]}[h={s[2]}]" for s in next_candidates]
            
            # Sắp xếp và chọn Top K
            next_candidates.sort(key=lambda x: x[2])
            top_k = next_candidates[:self.k]
            top_k_text = [f"{s[0]}[h={s[2]}]" for s in top_k]

            # 4. Tạo Log hiển thị
            log_content = [
                "==================================================",
                f"ALGORITHM: LOCAL BEAM (k={self.k})",
                "--------------------------------------------------",
                f"K-STATES (Đang xét {len(k_states)} trạng thái):"
            ]
            for s in k_states:
                log_content.append(f"  -> {s[0]} | h(n)={self.heuristic(s[0], end_pos)}")
            
            log_content.extend(["", "EXPAND:"])
            log_content.extend(self.split_list_to_lines(expand_text))
            
            log_content.extend(["", f"CHỌN K TỐT NHẤT:"])
            log_content.extend(self.split_list_to_lines(top_k_text))

            yield self.yield_log(step, k_states[0][0], log_content)

            # 5. Cập nhật K-states cho vòng lặp sau
            if not next_candidates:
                break
            k_states = [(s[0], s[1]) for s in top_k]

        return self.yield_finished(
            curr=start_pos,
            path=None,
            reached=[], 
            metrics={"steps": step, "length": 0},
            ly_do="Bế tắc: Không tìm thấy đường đi!"
        )