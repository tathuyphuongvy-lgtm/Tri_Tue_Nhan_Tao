# =================================================================
# FILE: algorithms/gr3_local/simulated_annealing.py
# CHỨC NĂNG: Thuật toán Simulated Annealing (Mô phỏng luyện kim)
# =================================================================

import math
import random
from algorithms.algorithm import PathfindingAlgorithm
from utils.helper import heuristic_manhattan

class SimulatedAnnealing(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Simulated_Annealing")

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        """
        Thực thi thuật toán Simulated Annealing đã lược bỏ Frontier/Reached dư thừa.
        """
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        T = 9000000000.0
        T_min = 0.25
        alpha = 0.98
        
        current_state = start
        step_counter = 0
        
        # Mảng lưu vết đường đi thực tế
        actual_path = [start]
        process_steps = [start]

        while T > T_min:
            step_counter += 1
            curr_h = heuristic_manhattan(current_state, end)
            
            # --- ĐIỀU KIỆN DỪNG THÀNH CÔNG ---
            if current_state == end:
                return self.yield_finished(
                    curr=end,
                    path=actual_path,
                    reached=process_steps,
                    metrics={"steps": step_counter, "length": len(actual_path) - 1}
                )

            neighbors = maze.get_neighbors(current_state)
            valid_neighbors = [n["pos"] for n in neighbors]

            if not valid_neighbors:
                return self.yield_finished(
                    curr=current_state,
                    path=None,
                    reached=process_steps,
                    metrics={"steps": step_counter, "length": 0},
                    ly_do="Rơi vào ô cô lập, không có hàng xóm hợp lệ"
                )

            next_state = random.choice(valid_neighbors)
            next_h = heuristic_manhattan(next_state, end)

            delta_E = next_h - curr_h
            accepted = False
            reason = ""

            if delta_E < 0:
                accepted = True
                reason = "OK (Heuristic nhỏ hơn)"
            else:
                probability = math.exp(-delta_E / T)
                if random.random() < probability:
                    accepted = True
                    reason = f"OK (P={probability:.4f} chấp nhận)"
                else:
                    accepted = False
                    reason = f"Bỏ qua (P={probability:.4f} từ chối)"

            # --- LOG CONTENT (Đã lược bỏ Frontier/Reached) ---
            log_content = [
                f"ALGORITHM: Simulated Annealing",
                f"-------------------------------------------------",
                f" Nhiệt độ T   : {T:.2f}", 
                f" Current State : {current_state}  | h(n): {curr_h}",
                f" Next State    : {next_state}  | h(n): {next_h}",
                f" Delta E       : {delta_E} ",
                f" Quyết định    : {reason}"
            ]
            
            yield self.yield_log(step_counter, current_state, log_content)

            # --- CƠ CHẾ DỊCH CHUYỂN VÀ LƯU VẾT ĐƯỜNG ĐI ---
            if accepted:
                current_state = next_state
                
                if current_state not in process_steps:
                    process_steps.append(current_state)
                
                # Cắt tỉa đường đi vòng
                if current_state in actual_path:
                    idx = actual_path.index(current_state)
                    actual_path = actual_path[:idx + 1]
                else:
                    actual_path.append(current_state)

            T = T * alpha

        # --- TRƯỜNG HỢP THẤT BẠI ---
        return self.yield_finished(
            curr=current_state,
            path=None,
            reached=process_steps,
            metrics={"steps": step_counter, "length": 0},
            ly_do="Nhiệt độ đã nguội lạnh nhưng chưa tìm thấy đích"
        )