# =================================================================
# FILE: algorithms/algorithm.py
# CHỨC NĂNG: Lớp cơ sở (Base Class) cho 18 thuật toán tìm kiếm.
# =================================================================

class PathfindingAlgorithm:
    def __init__(self, name="Unknown Algorithm"):
        self.name = name

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        """Mọi thuật toán con PHẢI cài đặt hàm này theo dạng generator (yield)."""
        raise NotImplementedError(f"Thuật toán {self.name} chưa cài đặt hàm run()!")

    # ---------------------------------------------------------
    # CƠ CHẾ ĐÓNG GÓI LOG CHUẨN (Dùng chung cho 18 thuật toán)
    # ---------------------------------------------------------
    def format_log(self, step, content_list):
        """Đóng khung nội dung log theo định dạng chuẩn từng bước."""
        header = f"=== STEP {step} ==="
        footer = "-" * len(header)
        return [header] + content_list + [footer]

    def yield_log(self, step, curr, content_list):
        """Hàm helper để thuật toán con gọi nhanh khi yield log từng bước."""
        return {
            "type": "log", 
            "data": self.format_log(step, content_list), 
            "curr": curr
        }

    def yield_finished(self, curr, path, reached, metrics=None, **kwargs):
        """
        Hàm helper CHUẨN HOÁ khi thuật toán kết thúc (Thành công hoặc Thất bại).
        Tự động tạo log dạng chuỗi cho UI Pygame và gom số liệu thô cho Excel.
        """
        log_lines = []
        log_lines.append("==================================================")
        log_lines.append(f"KẾT QUẢ CUỐI CÙNG - ALGORITHM: {self.name.upper()}")
        log_lines.append("--------------------------------------------------")
        
        # 1. Kiểm tra trạng thái và tạo nội dung text log hiển thị trực quan
        if path:
            log_lines.append("Trạng thái       : THÀNH CÔNG (Found Solution)")
            if kwargs:
                for key, val in kwargs.items():
                    if key != "execution_time":
                        display_key = key.replace("_", " ").title()
                        log_lines.append(f"{display_key:<17}: {val}")
            
            log_lines.append(f"Tổng số ô duyệt  : {len(reached)} nodes")
            log_lines.append(f"Độ dài đường đi  : {len(path) - 1} bước")
            log_lines.append("Đường đi (Path)  :")
            
            path_str = " -> ".join([str(p) for p in path])
            log_lines.append(path_str if len(path_str) <= 100 else f"{path_str[:100]}...")
        else:
            log_lines.append("Trạng thái       : THẤT BẠI (No Solution)")
            if kwargs:
                for key, val in kwargs.items():
                    if key != "execution_time":
                        display_key = key.replace("_", " ").title()
                        log_lines.append(f"{display_key:<17}: {val}")
            log_lines.append(f"Tổng số ô duyệt  : {len(reached)} nodes")
            log_lines.append("Đường đi (Path)  : Không tìm thấy đường đi hợp lệ.")
            
        log_lines.append("==================================================")
        
        # 2. Chuẩn hoá phần số liệu thô (Dùng để xuất file CSV / Excel)
        if metrics is None:
            metrics = {
                "steps": len(reached) if reached else 0,
                "length": len(path) - 1 if path else 0
            }
        
        # Bổ sung các dữ liệu phụ từ kwargs
        if kwargs:
            for key, val in kwargs.items():
                if key not in ["steps", "length"]:
                    metrics[key] = val

        return {
            "type": "finished",
            "curr": curr,
            "path": path,
            "reached": reached,
            "metrics": metrics, 
            "logs": log_lines   
        }

    # ---------------------------------------------------------
    # TIỆN ÍCH TÌM KIẾM (Dùng chung)
    # ---------------------------------------------------------
    def reconstruct_path(self, parent_dict, end_pos):
        path = []
        curr = end_pos
        while curr is not None:
            path.append(curr)
            curr = parent_dict.get(curr)
        path.reverse()
        return path

    def get_action_name(self, current_pos, next_pos):
        """Chuyển đổi tọa độ thành hướng đi (U, D, L, R)."""
        if not current_pos or not next_pos: return "Start"
        r1, c1 = current_pos
        r2, c2 = next_pos
        if r2 < r1: return "U"
        if r2 > r1: return "D"
        if c2 < c1: return "L"
        if c2 > c1: return "R"
        return "?"

    # ---------------------------------------------------------
    # HÀM MÓC NỐI (HOOKS) - Các nhóm thuật toán ghi đè khi cần
    # ---------------------------------------------------------
    def is_consistent(self, pos, maze):
        """Dành riêng cho Nhóm 4, 5 (CSP/Ràng buộc)."""
        return True

    def evaluate_node(self, info, maze):
        """Dành riêng cho Nhóm 6 (Minimax/Adversarial)."""
        return info.get("value", 0)