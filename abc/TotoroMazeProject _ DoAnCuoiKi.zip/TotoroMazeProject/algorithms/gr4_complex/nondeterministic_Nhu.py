# =================================================================
# FILE: algorithms/gr4_complex/nondeterministic_Nhu.py
# CHỨC NĂNG: Thuật toán tìm kiếm trong môi trường không xác định (AND-OR Graph Search)
# =================================================================
import random
from algorithms.algorithm import PathfindingAlgorithm

class Nondeterministic(PathfindingAlgorithm):
    def __init__(self):
        super().__init__("Nondeterministic")

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        self.maze = maze
        self.end_pos = end_pos
        self.step_counter = 0
        self.closed_set = set()
        
        # 1. Xây dựng cây kế hoạch (Conditional Plan)
        generator = self.and_or_search_generator(start_pos, [])
        full_plan = None
        while True:
            try:
                status = next(generator)
                if isinstance(status, dict) and status.get("type") == "log":
                    yield status
            except StopIteration as e:
                full_plan = e.value
                break

        if not full_plan:
            return self.yield_finished(
                curr=start_pos, path=None, reached=[],
                metrics={"steps": self.step_counter, "length": 0},
                ly_do="Không tìm thấy kế hoạch an toàn (Conditional Plan)"
            )

        # 2. Thực thi kế hoạch (Simulated Execution)
        simulated_path = [start_pos]
        curr_state = start_pos
        plan_ptr = full_plan
        
        while curr_state != end_pos and self.step_counter < 300:
            if not plan_ptr or curr_state not in plan_ptr: break
            
            # Mô phỏng môi trường trượt ngẫu nhiên
            possible_next = plan_ptr[curr_state]["results"]
            curr_state = random.choice(possible_next)
            simulated_path.append(curr_state)
            
            # Cập nhật con trỏ kế hoạch
            sub_plans = plan_ptr[curr_state].get("sub_plans", {})
            plan_ptr = sub_plans.get(curr_state, full_plan)
                
        return self.yield_finished(
            curr=curr_state,
            path=simulated_path,
            reached=simulated_path, # Tận dụng chính path làm reached để main.py có dữ liệu
            metrics={"steps": self.step_counter, "length": len(simulated_path) - 1}
        )

    def and_or_search_generator(self, state, path_stack):
        if state == self.end_pos: return {}
        if state in path_stack or state in self.closed_set: return None

        path_stack.append(state)
        self.closed_set.add(state)
        
        for n_info in self.maze.get_neighbors(state):
            next_pos = n_info["pos"]
            action = self.get_action_name(state, next_pos)
            possible_results = self.get_nondeterministic_results(state, next_pos)

            self.step_counter += 1
            log_content = [
                f"ALGORITHM: AND-OR Graph Search",
                f"-------------------------------------------------",
                f"[OR]  Tại: {state} | Action: {action}",
                f"[AND] Nhánh kết quả: {possible_results}"
            ]
            yield self.yield_log(self.step_counter, state, log_content)

            plan_for_action = {}
            is_viable = True

            for outcome in possible_results:
                sub_gen = self.and_or_search_generator(outcome, path_stack)
                sub_plan = None
                while True:
                    try:
                        val = next(sub_gen)
                        yield val
                    except StopIteration as e:
                        sub_plan = e.value
                        break
                if sub_plan is None:
                    is_viable = False
                    break
                plan_for_action[outcome] = sub_plan

            if is_viable:
                path_stack.pop()
                return {state: {"action": action, "results": possible_results, "sub_plans": plan_for_action}}

        path_stack.pop()
        self.closed_set.discard(state)
        return None

    def get_nondeterministic_results(self, current_pos, intended_pos):
        results = [intended_pos]
        # Tạo thêm 1 ô nhiễu (nondeterministic)
        for n in self.maze.get_neighbors(intended_pos):
            if n["pos"] != current_pos and self.maze.data[n["pos"][0]][n["pos"][1]] != 1:
                results.append(n["pos"])
                break
        return list(set(results))