# =================================================================
# FILE: algorithms/gr4_complex/partial_observability.py
# CHỨC NĂNG: Cài đặt thuật toán Partial Observability (Quan sát 1 phần)
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class PartialObservabilityAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Partial_Observability")

    def simulate_observation(self, pos, maze_obj):
        """Mô phỏng cảm biến nhìn thấy tường xung quanh"""
        neighbors = maze_obj.get_neighbors(pos)
        valid_dirs = len(neighbors)
        if valid_dirs == 1: return "Nhìn thấy ngõ cụt (3 mặt là tường)."
        if valid_dirs == 2: return "Có thể nhìn thấy tường ở hai bên (hành lang)."
        if valid_dirs == 3: return "Có thể nhìn thấy tường ở một phía (ngã ba)."
        return "Khu vực trống trải, không có tường sát cạnh."

    def filter_belief_state(self, belief_state, actual_pos, maze_obj):
        """Lọc các trạng thái không khớp với quan sát thực tế"""
        actual_obs_count = len(maze_obj.get_neighbors(actual_pos))
        new_belief = []
        for state in belief_state:
            if len(maze_obj.get_neighbors(state)) == actual_obs_count:
                new_belief.append(state)
        if actual_pos not in new_belief:
            new_belief.append(actual_pos)
        return new_belief

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        """Hàm hỗ trợ bẻ dòng để Pygame không bị ngộp khi Log quá dài"""
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        curr = start
        path = [start]
        reached = [start]
        step_count = 0
        
        belief_state = [start]
        for n in maze_obj.get_neighbors(start):
            belief_state.append(n["pos"])
            
        while True:
            step_count += 1
            
            # --- KIỂM TRA ĐÍCH ĐẾN ---
            if curr == end:
                log_lines = [
                    "==================================================",
                    "KẾT QUẢ CUỐI CÙNG - PARTIAL OBSERVABILITY",
                    "--------------------------------------------------",
                    "Trạng thái       : THÀNH CÔNG (Tới đích)",
                    f"Độ dài đường đi  : {len(path) - 1} bước",
                    "=================================================="
                ]
                return self.yield_finished(
                    curr=curr,
                    path=path,
                    reached=reached,
                    metrics={"steps": step_count, "length": len(path) - 1},
                    logs=log_lines
                )

            observation_msg = self.simulate_observation(curr, maze_obj)
            belief_before = list(belief_state)
            belief_state = self.filter_belief_state(belief_state, curr, maze_obj)
            
            log_lines = [
                f"[ACTION #{step_count}] - ALGORITHM: Partial Observability",
                "--------------------------------------------------",
                "Observation:",
                f"  {observation_msg}",
                "",
                "BELIEF STATE (Trước khi cập nhật):"
            ]
            log_lines.extend(self.split_list_to_lines(belief_before))
            log_lines.extend(["", "BELIEF STATE (Sau khi cập nhật):"])
            log_lines.extend(self.split_list_to_lines(belief_state))
            
            neighbors = [n["pos"] for n in maze_obj.get_neighbors(curr)]
            valid_moves = [n for n in neighbors if n not in reached]
            
            # Yield log chuẩn hóa với Frontier và Reached để main.py vẽ lên UI
            yield self.yield_log(step_count, curr, log_lines)
            
            # Tìm đường tiếp theo (Heuristic cơ bản về đích)
            if valid_moves:
                valid_moves.sort(key=lambda p: abs(p[0]-end[0]) + abs(p[1]-end[1]))
                curr = valid_moves[0]
                reached.append(curr)
                path.append(curr)
                
                # Cập nhật Belief State cho bước tiếp theo
                new_belief = []
                for b_state in belief_state:
                    for n in maze_obj.get_neighbors(b_state):
                        if n["pos"] not in new_belief:
                            new_belief.append(n["pos"])
                belief_state = new_belief
            else:
                # Bế tắc
                return self.yield_finished(
                    curr=curr,
                    path=None,
                    reached=reached,
                    metrics={"steps": step_count, "length": 0},
                    ly_do="Bị kẹt trong khu vực sương mù"
                )