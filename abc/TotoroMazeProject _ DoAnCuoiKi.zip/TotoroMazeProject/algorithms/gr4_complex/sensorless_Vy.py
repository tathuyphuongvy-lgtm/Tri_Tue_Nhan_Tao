import collections
from algorithms.algorithm import PathfindingAlgorithm

class SensorlessAlgorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__("Sensorless")

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        initial_belief = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] != 1]
        queue = collections.deque([(initial_belief, [])])
        visited = {frozenset(initial_belief)}
        
        step_count = 0
        MAX_STEPS = 1000
        
        while queue and step_count < MAX_STEPS:
            belief_state, actions = queue.popleft()
            step_count += 1
            
            last_action = actions[-1] if actions else "Start"
            preview = [str(p) for p in belief_state[:10]]
            if len(belief_state) > 10:
                preview.append(f"... (còn {len(belief_state)-10} node)")
            
            log_lines = [f"[STEP {step_count}] - ACTION: {last_action}", f"Trạng thái nghi ngờ: {len(belief_state)}", "DANH SÁCH:"] + preview
            yield self.yield_log(step_count, belief_state[0], log_lines)

            # KIỂM TRA ĐÍCH (HỘI TỤ) - ĐÃ SỬA METRICS
            if len(belief_state) == 1 and belief_state[0] == tuple(end_pos):
                return self.yield_finished(belief_state[0], actions, belief_state, 
                                         {"steps": step_count, "length": len(actions)}, 
                                         ly_do=None)

            # MỞ RỘNG BFS
            for action_code in ["U", "D", "L", "R"]:
                new_belief_set = set()
                for pos in belief_state:
                    neighbors = maze.get_neighbors(pos)
                    moved = False
                    for n in neighbors:
                        if self.get_action_name(pos, n["pos"]) == action_code:
                            new_belief_set.add(n["pos"])
                            moved = True
                            break
                    if not moved: new_belief_set.add(pos)
                
                new_belief = list(new_belief_set)
                belief_fs = frozenset(new_belief)
                if belief_fs not in visited:
                    visited.add(belief_fs)
                    queue.append((new_belief, actions + [action_code]))

        # KẾT THÚC BẾ TẮC - ĐÃ SỬA METRICS
        return self.yield_finished(start_pos, None, [], 
                                 {"steps": step_count, "length": 0}, 
                                 ly_do="Bế tắc: Không hội tụ được!")