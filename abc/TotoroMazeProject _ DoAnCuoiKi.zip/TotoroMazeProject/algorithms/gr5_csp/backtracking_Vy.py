# =================================================================
# FILE: algorithms/gr5_csp/backtracking_Vy.py
# CHỨC NĂNG: CSP Backtracking - Đã cập nhật ly_do tiếng Việt
# =================================================================
import collections
from algorithms.algorithm import PathfindingAlgorithm

class Backtracking(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Backtracking")

    def bfs_path_gen(self, maze, start, goal, step):
        queue = collections.deque([(start, [start])])
        visited = {start}
        while queue:
            curr, path = queue.popleft()
            
            # Log dò đường
            log_data = self.format_log(step, [f"Dò tới {goal}", f"Ô: {curr}"])
            yield {"type": "log", "data": log_data, "curr": curr, "step": step}
            step += 1
            
            if curr == goal:
                yield {"type": "path", "path": path, "step": step}
                return
            for node in maze.get_neighbors(curr):
                n_pos = node["pos"]
                if maze.is_valid(n_pos[0], n_pos[1]) and n_pos not in visited:
                    visited.add(n_pos)
                    queue.append((n_pos, path + [n_pos]))
        yield {"type": "path", "path": [], "step": step}

    def run(self, maze, start_pos, end_pos, debug_mode=False):
        keys = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] == 6]
        doors = [(r, c) for r in range(maze.rows) for c in range(maze.cols) if maze.data[r][c] == 7]
        items = keys + doors
        valid_sequence = []
        step = 0

        def backtrack(current_seq):
            nonlocal step
            if len(current_seq) == len(items):
                valid_sequence[:] = current_seq
                yield True
                return

            for item in items:
                if item not in current_seq:
                    if item in doors and not any(k in current_seq for k in keys):
                        continue
                    
                    step += 1
                    yield self.yield_log(step, item, [f"Thử: {item}", f"Seq: {current_seq + [item]}"])
                    
                    current_seq.append(item)
                    found = yield from backtrack(current_seq)
                    if found:
                        yield True
                        return
                    current_seq.pop()
                    
                    step += 1
                    yield self.yield_log(step, item, ["BACKTRACKING..."])
            yield False

        # --- CHẠY CSP ---
        found = False
        for res in backtrack([]):
            if res is True: found = True
            elif isinstance(res, dict): yield res 

        if found:
            yield self.yield_log(step, start_pos, [">>> CSP THÀNH CÔNG! BẮT ĐẦU DI CHUYỂN..."])
            step += 1
            
            full_path = []
            current_node = start_pos
            waypoints = valid_sequence + [end_pos]
            reached = []
            
            for wp in waypoints:
                segment = []
                for res in self.bfs_path_gen(maze, current_node, wp, step):
                    if res.get("type") == "log":
                        yield self.yield_log(res["step"], res["curr"], res["data"])
                        step = res["step"]
                    elif res.get("type") == "path":
                        segment = res["path"]
                        step = res["step"]
                
                if not segment: break
                full_path.extend(segment[1:] if full_path else segment)
                current_node = wp
                reached.extend(segment)
            
            # Trả về thành công
            return self.yield_finished(current_node, list(full_path), reached, 
                                     {"steps": step, "length": len(full_path)}, ly_do=None)
        
        # Trả về thất bại
        return self.yield_finished(start_pos, None, [], 
                                 {"steps": step, "length": 0}, ly_do="Không tìm được trình tự vật phẩm hợp lệ!")