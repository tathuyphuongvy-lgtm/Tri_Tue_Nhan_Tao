# =================================================================
# FILE: algorithms/gr5_csp/min_conflicts_Nhu.py
# CHỨC NĂNG: Thuật toán Min-Conflicts CSP chuẩn + Đồng bộ đường xanh
# =================================================================
import random
from algorithms.algorithm import PathfindingAlgorithm

class MinConflicts(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="Min_Conflicts")

    def _generate_complete_assignment(self, maze, start_pos, end_pos):
        """Khởi tạo một đường đi ngẫu nhiên ban đầu (Assignment)"""
        unvisited_items = []
        for r in range(maze.rows):
            for c in range(maze.cols):
                if maze.data[r][c] in (6, 7):
                    unvisited_items.append((r, c))
        waypoints = [start_pos] + unvisited_items + [end_pos]
        full_path = [start_pos]
        for i in range(len(waypoints) - 1):
            curr_r, curr_c = waypoints[i]
            target_r, target_c = waypoints[i+1]
            while curr_c != target_c:
                curr_c += 1 if target_c > curr_c else -1
                if (curr_r, curr_c) != full_path[-1]: full_path.append((curr_r, curr_c))
            while curr_r != target_r:
                curr_r += 1 if target_r > curr_r else -1
                if (curr_r, curr_c) != full_path[-1]: full_path.append((curr_r, curr_c))
        return full_path

    def _count_conflicts(self, path, maze):
        """Đếm lỗi: Ô đè lên tường HOẶC ô sau nhảy cóc không kề cạnh ô trước"""
        conflict_indices = []
        for i in range(1, len(path) - 1):
            r, c = path[i]
            if maze.data[r][c] == 1:
                conflict_indices.append(i)
                continue
            prev_r, prev_c = path[i-1]
            if abs(r - prev_r) + abs(c - prev_c) != 1:
                conflict_indices.append(i)
        return len(conflict_indices), conflict_indices

    def run(self, maze, start_pos, end_pos, max_steps=1000, debug_mode=False):
        step = 0
        path = self._generate_complete_assignment(maze, start_pos, end_pos)
        
        while step < max_steps:
            step += 1
            num_conflicts, conflict_indices = self._count_conflicts(path, maze)
            
            # --- TRƯỜNG HỢP THÀNH CÔNG ---
            if num_conflicts == 0:
                return self.yield_finished(
                    curr=path[-1],
                    path=path,
                    reached=path, # Trong CSP, toàn bộ assignment là không gian đã duyệt
                    metrics={"steps": step, "length": len(path) - 1}
                )

            var_idx = random.choice(conflict_indices)
            curr_pos = path[var_idx]
            
            prev_pos = path[var_idx - 1]
            candidates = [curr_pos] + [n["pos"] for n in maze.get_neighbors(prev_pos) if maze.data[n["pos"][0]][n["pos"][1]] != 1]
            
            best_candidate = curr_pos
            min_c = num_conflicts
            
            for candidate in candidates:
                temp_path = list(path)
                temp_path[var_idx] = candidate
                c_count, _ = self._count_conflicts(temp_path, maze)
                
                # Tạo log cập nhật trạng thái tìm kiếm
                log_data = self.yield_log(step, candidate, [
                    f"=== MIN-CONFLICTS CSP ===",
                    f"• Tổng lỗi toàn cục: {num_conflicts}",
                    f"• Sửa Index {var_idx}: {curr_pos} -> {candidate}",
                    f"• Lỗi dự kiến sau khi đổi: {c_count}"
                ])
                log_data["csp_path"] = list(temp_path)
                yield log_data

                if c_count < min_c:
                    min_c = c_count
                    best_candidate = candidate

            path[var_idx] = best_candidate
            
            # Gửi log bước hoàn thành
            step_final_log = self.yield_log(step, best_candidate, [
                f"--- HOÀN THÀNH STEP {step} ---",
                f"Số lỗi còn lại: {min_c}"
            ])
            step_final_log["csp_path"] = list(path)
            yield step_final_log

        # --- TRƯỜNG HỢP THẤT BẠI ---
        return self.yield_finished(
            curr=path[-1],
            path=None,
            reached=path,
            metrics={"steps": step, "length": 0},
            ly_do="Đạt giới hạn bước lặp (Max Steps) mà vẫn chưa loại bỏ hết xung đột"
        )