# =================================================================
# FILE: algorithms/gr5_csp/ac3.py
# CHỨC NĂNG: Cài đặt thuật toán Arc Consistency 3 (AC-3) - Đã đồng bộ
# =================================================================
from algorithms.algorithm import PathfindingAlgorithm

class AC3Algorithm(PathfindingAlgorithm):
    def __init__(self):
        super().__init__(name="AC_3")

    def get_domain(self, pos, maze_obj):
        domains = []
        neighbors = maze_obj.get_neighbors(pos)
        for n in neighbors:
            n_pos = n["pos"]
            if n_pos[0] < pos[0]: domains.append('U')
            elif n_pos[0] > pos[0]: domains.append('D')
            elif n_pos[1] < pos[1]: domains.append('L')
            elif n_pos[1] > pos[1]: domains.append('R')
        return domains if domains else ['Trống']

    def pos_from_dir(self, pos, direction):
        if direction == 'U': return (pos[0]-1, pos[1])
        if direction == 'D': return (pos[0]+1, pos[1])
        if direction == 'L': return (pos[0], pos[1]-1)
        if direction == 'R': return (pos[0], pos[1]+1)
        return pos

    def split_list_to_lines(self, nodes_list, max_per_line=4):
        if not nodes_list: return ["  [Trống]"]
        lines = []
        str_nodes = [str(node) for node in nodes_list]
        for i in range(0, len(str_nodes), max_per_line):
            chunk = str_nodes[i : i + max_per_line]
            chunk_str = ", ".join(chunk)
            if i + max_per_line < len(str_nodes): chunk_str += ","
            lines.append(f"  {chunk_str}")
        return lines

    def run(self, maze_obj, start_pos, end_pos, debug_mode=False):
        start = tuple(start_pos)
        end = tuple(end_pos)
        
        curr = start
        path = [start]
        reached = [start]
        step_count = 0
        
        arc_queue = [(curr, n["pos"]) for n in maze_obj.get_neighbors(curr)]
        
        while True:
            step_count += 1
            
            # --- KIỂM TRA ĐÍCH ---
            if curr == end:
                return self.yield_finished(
                    curr=end,
                    path=path,
                    reached=reached,
                    metrics={"steps": step_count, "length": len(path) - 1},
                    logs=["AC-3: Đã đến đích thành công!"]
                )
            
            # --- XỬ LÝ AC-3 ---
            if not arc_queue:
                return self.yield_finished(
                    curr=curr,
                    path=None,
                    reached=reached,
                    metrics={"steps": step_count, "length": 0},
                    ly_do="Bế tắc (Arc Queue rỗng)"
                )

            x1, x2 = arc_queue.pop(0)
            domain_x1_before = self.get_domain(x1, maze_obj)
            domain_x2_before = self.get_domain(x2, maze_obj)
            
            removed_values = []
            domain_x1_after = []
            
            for d in domain_x1_before:
                target_pos = self.pos_from_dir(x1, d)
                if target_pos in reached and target_pos != x2:
                    removed_values.append(d)
                else:
                    domain_x1_after.append(d)
            if not domain_x1_after: domain_x1_after = ['Trống']

            # --- LOG CONTENT ĐỒNG BỘ ---
            log_lines = [
                f"[STEP {step_count}] - ALGORITHM: AC-3",
                "-------------------------------------------------",
                f"Current Arc: ({x1}, {x2})",
                f"REVISE: {', '.join(removed_values) if removed_values else 'Không có giá trị nào bị loại'}",
                f"REACHED (Total: {len(reached)}):"
            ]
            log_lines.extend(self.split_list_to_lines(reached))
            
            yield self.yield_log(step_count, curr, log_lines)
            
            # --- DI CHUYỂN ---
            neighbors = [n["pos"] for n in maze_obj.get_neighbors(curr)]
            valid_moves = [n for n in neighbors if n not in reached]
            
            if valid_moves:
                curr = valid_moves[0]
                reached.append(curr)
                path.append(curr)
                for n in maze_obj.get_neighbors(curr):
                    if n["pos"] not in reached:
                        arc_queue.append((curr, n["pos"]))
            else:
                if len(path) > 1:
                    path.pop()
                    curr = path[-1]
                else:
                    return self.yield_finished(
                        curr=curr, path=None, reached=reached,
                        metrics={"steps": step_count, "length": 0},
                        ly_do="AC-3: Không còn nước đi hợp lệ!"
                    )